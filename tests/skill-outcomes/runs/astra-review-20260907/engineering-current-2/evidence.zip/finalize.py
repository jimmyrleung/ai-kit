#!/usr/bin/env python3
import hashlib
import json
import platform
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/tmp/astra-backlog-5VdqNm/trials/engineering/current/2')
REPO = Path('<user-home>/ai-kit')
BASE = 'aeec06bfa0a6b97402b17824d957f29635f40ba7'
ORDER = [
    'dirty-review', 'unborn-short-history', 'review-invalidation',
    'task-reverification', 'consumer-closure', 'completion-resources',
    'existing-test-home', 'convention-new-test', 'no-suitable-test-home',
    'unneeded-helper', 'authorization-cadence', 'review-depth-severity',
    'check-reuse', 'intent-routing', 'incident-causality'
]

def croot(cid): return ROOT / 'cases' / f'{ORDER.index(cid)+1:02d}-{cid}'
def write(path, text):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
def sha_bytes(data): return hashlib.sha256(data).hexdigest()
def sha_file(path): return sha_bytes(Path(path).read_bytes())
def run(cmd, cwd):
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, check=False)
    return {'command': cmd, 'cwd': str(cwd), 'exit_code': p.returncode, 'output': p.stdout}
def init_git(path, trace):
    for cmd in [['git','init','-q'], ['git','config','user.name','Fixture Runner'],
                ['git','config','user.email','fixture@example.invalid']]:
        row=run(cmd,path); row['phase']='setup'; trace.append(row)
def line(path, needle):
    for n, s in enumerate(Path(path).read_text(encoding='utf-8').splitlines(), 1):
        if needle in s: return n
    raise ValueError(f'{needle!r} not found in {path}')

# Strengthen review-invalidation with an observed same-HEAD baseline and fresh Git copies.
cid='review-invalidation'; root=croot(cid); trace=[]
vbase=root/'fixture-versioned-base'
shutil.copytree(root/'fixture-initial',vbase,dirs_exist_ok=True)
init_git(vbase,trace)
for rel in ['spec.md','source.py']:
    row=run(['git','add',rel],vbase); row['phase']='setup'; trace.append(row)
row=run(['git','commit','-q','-m','evidence baseline'],vbase); row['phase']='setup'; trace.append(row)
head=run(['git','rev-parse','HEAD'],vbase); head['phase']='setup'; trace.append(head)
head_sha=head['output'].strip()
task_a='## Task A requirements\n- Return a nonnegative amount.\n'
record={'schema':1,'task':'Task A','verdict':'approved','head':head_sha,
        'source_sha256':sha_file(vbase/'source.py'),'ac_sha256':sha_bytes(task_a.encode())}
write(vbase/'change-evidence.md','# Change evidence\n\n<!-- evidence:begin -->\n'+json.dumps(record,sort_keys=True)+'\n<!-- evidence:end -->\n')
git_variants={}
for slug in ['same-head-source','edited-ac','task-b','rejected','evidence-only','unrelated','missing-identity']:
    dst=root/'git-variants'/slug
    shutil.copytree(vbase,dst,dirs_exist_ok=True)
    if slug=='same-head-source':
        with (dst/'source.py').open('a',encoding='utf-8') as f: f.write('# dirty same HEAD\n')
    elif slug=='edited-ac':
        write(dst/'spec.md',(dst/'spec.md').read_text().replace('nonnegative','positive'))
    elif slug=='rejected':
        r=dict(record); r['verdict']='rejected'
        write(dst/'change-evidence.md','# Change evidence\n\n<!-- evidence:begin -->\n'+json.dumps(r,sort_keys=True)+'\n<!-- evidence:end -->\n')
    elif slug=='evidence-only':
        with (dst/'change-evidence.md').open('a',encoding='utf-8') as f:
            f.write('<!-- evidence:begin -->\n{"note":"append"}\n<!-- evidence:end -->\n')
    elif slug=='unrelated': write(dst/'unrelated.py','x = 2\n')
    elif slug=='missing-identity':
        r=dict(record); r.pop('ac_sha256')
        write(dst/'change-evidence.md','# Change evidence\n\n<!-- evidence:begin -->\n'+json.dumps(r,sort_keys=True)+'\n<!-- evidence:end -->\n')
    h=run(['git','rev-parse','HEAD'],dst); h['phase']='agent'; trace.append(h)
    st=run(['git','status','--short'],dst); st['phase']='agent'; trace.append(st)
    git_variants[slug]={'head':h['output'].strip(),'status':st['output'].splitlines(),
                        'source_sha256':sha_file(dst/'source.py'),'spec_sha256':sha_file(dst/'spec.md'),
                        'evidence_sha256':sha_file(dst/'change-evidence.md')}
write(root/'artifacts/git-variant-identities.json',json.dumps({'baseline_head':head_sha,'variants':git_variants},indent=2)+'\n')
old=(root/'tool-trace.md').read_text(encoding='utf-8')
lines=[old.rstrip(),'','## Git baseline and independent variant probes','']
for i,row in enumerate(trace,1):
    lines += [f'### G{i} — {row["phase"]}',f'- CWD: `{row["cwd"]}`',f'- Command: `{row["command"]}`',
              f'- Exit: {row["exit_code"]}','```text',row['output'].rstrip(),'```','']
write(root/'tool-trace.md','\n'.join(lines))

# Execute and identity-bind the check-reuse mutation variants.
cid='check-reuse'; root=croot(cid); trace=[]
base=root/'fixture-evidence-base'
src=croot('convention-new-test')/'fixture-work'
shutil.copytree(src,base,dirs_exist_ok=True)
write(base/'commands.json',(root/'fixture-initial'/'commands.json').read_text(encoding='utf-8'))
write(base/'config.json','{"mode":"test"}\n')
full_build=run(['python3','-m','compileall','calc.py'],base); full_build['phase']='setup evidence'; trace.append(full_build)
full_unit=run(['python3','-m','unittest','discover','-s','tests'],base); full_unit['phase']='setup evidence'; trace.append(full_unit)
def ids(path):
    return {rel:sha_file(path/rel) for rel in ['calc.py','tests/test_calc.py','tests/test_calc_validation.py','config.json','commands.json']}
variants={'exact-match':{'identities':ids(base),'execution':'reused; no rerun'}}
for slug in ['source-changed','config-changed','blocked-integration','smaller-subset']:
    dst=root/'variants'/slug
    shutil.copytree(base,dst,dirs_exist_ok=True)
    if slug=='source-changed':
        with (dst/'calc.py').open('a',encoding='utf-8') as f: f.write('# changed after evidence\n')
    elif slug=='config-changed': write(dst/'config.json','{"mode":"changed"}\n')
    elif slug=='blocked-integration':
        write(dst/'integration-requirement.txt','Integration suite requires an external test database; no runner or database is supplied.\n')
    elif slug=='smaller-subset':
        sub=run(['python3','-m','unittest','discover','-s','tests','-p','test_calc.py'],dst)
        sub['phase']='agent subset'; trace.append(sub)
        variants[slug]={'subset_exit':sub['exit_code'],'subset_output':sub['output'],'scope':'test_calc.py only'}
    variants.setdefault(slug,{})['identities']=ids(dst)
variants['staging-only-config']={'status':'deliberate irrelevant difference; asymmetry check pass',
    'evidence':'prompt-supplied scenario; no environment files supplied to mutate'}
variants['required-prod-key-missing']={'status':'fail',
    'evidence':'prompt-supplied scenario; required key has no present identity'}
write(root/'artifacts/variant-identities.json',json.dumps({
    'evidence_base':{'identities':ids(base),'python':platform.python_version(),
                     'build_exit':full_build['exit_code'],'unit_exit':full_unit['exit_code'],
                     'full_suite_output':full_unit['output']},'variants':variants},indent=2)+'\n')
old=(root/'tool-trace.md').read_text(encoding='utf-8')
lines=[old.rstrip(),'','## Fresh full-evidence fixture and mutation probes','']
for i,row in enumerate(trace,1):
    lines += [f'### V{i} — {row["phase"]}',f'- CWD: `{row["cwd"]}`',f'- Command: `{row["command"]}`',
              f'- Exit: {row["exit_code"]}','```text',row['output'].rstrip(),'```','']
write(root/'tool-trace.md','\n'.join(lines))
out=(root/'output.md').read_text(encoding='utf-8')
out=out.replace('`artifacts/prior-run-identity.json`.', '`artifacts/prior-run-identity.json`; the stronger four-test fixture and fresh mutation identities are in `artifacts/variant-identities.json`.')
out=out.replace('| Source changed | **stale** | source identity invalidates build and unit evidence |','| Source changed | **stale** | fresh variant source identity differs and invalidates build and unit evidence |')
out=out.replace('| Relevant config changed | **stale** | config identity invalidates affected evidence |','| Relevant config changed | **stale** | fresh variant config identity differs and invalidates affected evidence |')
out=out.replace('| Smaller subset exits 0 | **unverified for full suite** | a green subset proves only its recorded subset |','| Smaller subset exits 0 | **unverified for full suite** | executed 1-test `test_calc.py` subset cannot stand for the recorded 4-test full suite |')
write(root/'output.md',out)

# Verify supplied snapshot bytes against the declared reviewed base without using live bodies.
source_manifest=json.loads((ROOT/'inputs/source-manifest.json').read_text(encoding='utf-8'))
baseline_trace=[]
for skill, entry in source_manifest['skills'].items():
    if entry.get('availability')!='available': continue
    p=subprocess.run(['git','show',f'{BASE}:skills/{skill}/SKILL.md'],cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    bh=sha_bytes(p.stdout) if p.returncode==0 else None
    entry['reviewed_base_sha256']=bh
    entry['matches_reviewed_base']=p.returncode==0 and bh==entry['sha256']
    baseline_trace.append({'skill':skill,'exit_code':p.returncode,'snapshot_sha256':entry['sha256'],'base_sha256':bh,'match':entry['matches_reviewed_base']})
source_manifest['reviewed_base_verification']=baseline_trace
write(ROOT/'inputs/source-manifest.json',json.dumps(source_manifest,indent=2)+'\n')

# Exact prompt/input manifest and integrity checks.
corpus=json.loads((REPO/'tests/skill-outcomes/cases.json').read_text(encoding='utf-8'))
byid={c['id']:c for c in corpus['cases']}
input_rows=[]; integrity=[]
for cid in ORDER:
    root=croot(cid); prompt=(root/'inputs/prompt.md').read_bytes(); expected=byid[cid]['prompt'].encode()
    integrity.append({'case_id':cid,'prompt_exact':prompt==expected,'prompt_sha256':sha_bytes(prompt)})
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and ('inputs' in p.parts or 'fixture-initial' in p.parts):
        input_rows.append({'path':str(p.relative_to(ROOT)),'sha256':sha_file(p),'bytes':p.stat().st_size})
extras_expected=[
 'Analyze rejecting negative amounts; produce a reference map, no implementation recipe',
 'Analyze the fetch return-contract change; produce a reference map, no implementation recipe.']
for i, expected in enumerate(extras_expected,1):
    p=next((ROOT/'extras').glob(f'{i:02d}-*/inputs/prompt.md'))
    integrity.append({'extra_order':i,'prompt_exact':p.read_bytes()==expected.encode(),'prompt_sha256':sha_file(p)})
write(ROOT/'inputs/input-manifest.json',json.dumps({'files':input_rows,'prompt_integrity':integrity},indent=2)+'\n')

# Mandatory grading. All locators point to preserved output/trace/artifact bytes.
loc={
'dirty-review':[('pass','output.md:9'),('pass','output.md:14'),('pass','output.md:14'),('pass','output.md:18')],
'unborn-short-history':[('pass','output.md:5'),('pass','output.md:9'),('pass','output.md:11')],
'review-invalidation':[('pass','output.md:7-8'),('pass','output.md:9'),('pass','output.md:10'),('pass','output.md:11'),('pass','output.md:12'),('pass','output.md:13')],
'task-reverification':[('pass','output.md:3'),('pass','output.md:3'),('pass','artifacts/tasks-preserved.md:10'),('pass','output.md:7'),('pass','output.md:8'),('pass','output.md:12')],
'consumer-closure':[('pass','tool-trace.md:3'),('pass','output.md:6'),('pass','output.md:9'),('pass','output.md:9')],
'completion-resources':[('pass','artifacts/task-graph.md:19'),('pass','artifacts/task-graph.md:5'),('pass','artifacts/task-graph.md:17'),('pass','artifacts/task-graph.md:15'),('pass','artifacts/task-graph.md:15'),('pass','artifacts/task-graph.md:21')],
'existing-test-home':[('pass','output.md:3'),('pass','tool-trace.md:3'),('pass','output.md:3'),('pass','output.md:5'),('pass','output.md:5'),('pass','output.md:5')],
'convention-new-test':[('pass','output.md:3'),('pass','tool-trace.md:3'),('pass','output.md:3'),('pass','output.md:5'),('pass','output.md:5'),('pass','output.md:5')],
'no-suitable-test-home':[('pass','output.md:3'),('pass','tool-trace.md:3'),('pass','output.md:3'),('pass','output.md:5'),('pass','output.md:5'),('pass','output.md:5')],
'unneeded-helper':[('pass','output.md:5'),('pass','output.md:10'),('pass','output.md:15')],
'authorization-cadence':[('pass','output.md:3'),('pass','output.md:3'),('pass','output.md:5'),('pass','output.md:6')],
'review-depth-severity':[('pass','output.md:7'),('pass','output.md:11'),('pass','output.md:17'),('pass','output.md:19'),('pass','output.md:19'),('pass','output.md:3')],
'check-reuse':[('pass','output.md:7'),('pass','output.md:8'),('pass','output.md:10'),('pass','output.md:12'),('pass','output.md:13'),('unavailable','output.md:14')],
'intent-routing':[('pass','output.md:5'),('pass','output.md:5'),('pass','output.md:6'),('pass','output.md:8'),('pass','output.md:9'),('pass','output.md:10')],
'incident-causality':[('pass','output.md:7'),('pass','output.md:7'),('pass','output.md:13'),('pass','output.md:17'),('pass','output.md:19'),('pass','output.md:3')]
}
run_record=json.loads((ROOT/'run.json').read_text(encoding='utf-8'))
for case_rec in run_record['cases']:
    cid=case_rec['case_id']; grades=[]
    for criterion,(status,locator) in zip(case_rec['mandatory_checks'],loc[cid]):
        item=dict(criterion); item['status']=status; item['locator']=f'cases/{ORDER.index(cid)+1:02d}-{cid}/{locator}'
        if status=='unavailable': item['reason']='No screenshot/browser output was supplied; observable UI proof is unavailable, while output.md:15 correctly leaves subjective approval to a human.'
        grades.append(item)
    case_rec['mandatory_checks']=grades
    case_rec['status']='completed_with_unavailable' if any(g['status']=='unavailable' for g in grades) else 'completed'
    case_rec['output_path']=f'cases/{ORDER.index(cid)+1:02d}-{cid}/output.md'
    case_rec['trace_path']=f'cases/{ORDER.index(cid)+1:02d}-{cid}/tool-trace.md'
    case_rec['questions']=[]
    case_rec['failures']=[]
    if cid=='authorization-cadence':
        case_rec['questions']=[
          {'variant':'C','status':'pending','locator':f'cases/11-{cid}/variants/C-missing-retention/output.md:3'},
          {'variant':'D item 1','status':'pending','locator':f'cases/11-{cid}/variants/D-walkthrough/output.md:1'}]
run_record['extra_prompts'][0]['status']='completed'; run_record['extra_prompts'][0]['output']='extras/01-existing-test-home-analyze/artifacts/rejecting-negative-amounts_analysis.md'
run_record['extra_prompts'][1]['status']='completed'; run_record['extra_prompts'][1]['output']='extras/02-consumer-closure-analyze/artifacts/fetch-return-contract_analysis.md'
run_record['status']='completed_with_unavailable'
run_record['failures']=[{'scope':'validation tooling','command':'xxd -g1 <extra prompt>','result':'command unavailable','fallback':'od -An -tx1 -v succeeded','trial_impact':'none'}]
run_record['unavailable']=['native skill discovery/invocation','full host transcript','token usage','monetary cost','effective model/settings identity','browser screenshot/output for check-reuse']
run_record['review']['agent_reviewer']='self-graded against every mandatory criterion; human judgment retained where required'

# Output hashes and byte measurements (definitions are explicit and non-comparative).
artifact_files=[]; output_files=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or '.git' in p.parts or '__pycache__' in p.parts: continue
    rel=str(p.relative_to(ROOT))
    if '/artifacts/' in '/'+rel: artifact_files.append(p)
    if p.name in ['output.md','tool-trace.md'] or '/artifacts/' in '/'+rel: output_files.append(p)
manifest=[]
for p in output_files:
    manifest.append({'path':str(p.relative_to(ROOT)),'sha256':sha_file(p),'bytes':p.stat().st_size})
artifact_bytes=sum(p.stat().st_size for p in artifact_files)
total_output_bytes=sum(p.stat().st_size for p in output_files)
write(ROOT/'output-manifest.json',json.dumps({'definition':{
    'artifact_bytes':'sum of files below case/extra artifacts directories',
    'total_output_bytes':'sum of output.md, tool-trace.md, and artifacts files; excludes fixtures, inputs, scripts, report/run, and this manifest'},
    'files':manifest,'artifact_bytes':artifact_bytes,'total_output_bytes':total_output_bytes},indent=2)+'\n')

finished=datetime.now(timezone.utc)
started=datetime.fromisoformat(run_record['measurements']['started_at'])
run_record['measurements'].update({'finished_at':finished.isoformat(),
    'elapsed_seconds':round((finished-started).total_seconds(),3),
    'artifact_bytes':artifact_bytes,'total_output_bytes':total_output_bytes,
    'tokens':None,'cost':None,
    'unavailable_reason':'Token, cost, full transcript, and effective model/settings accounting are not exposed. Byte counts are direct UTF-8/file-byte measurements, not a savings claim.'})
run_record['output_manifest']='output-manifest.json'
run_record['input_manifest']='inputs/input-manifest.json'
write(ROOT/'run.json',json.dumps(run_record,indent=2)+'\n')

rows=[]
for c in run_record['cases']:
    p=sum(g['status']=='pass' for g in c['mandatory_checks'])
    u=sum(g['status']=='unavailable' for g in c['mandatory_checks'])
    f=sum(g['status']=='fail' for g in c['mandatory_checks'])
    rows.append(f'| {c["order"]} | `{c["case_id"]}` | {c["status"]} | {p} pass / {f} fail / {u} unavailable | `{c["output_path"]}` |')
report=f'''# Engineering supplied-body trial — current repeat 2

- Status: **completed with one unavailable mandatory check**
- Reviewed source base: `{BASE}`; all 11 supplied skill-body hashes match that base
- Execution: supplied-body procedure, not native discovery
- Batch: shared context in declared order; fresh filesystem fixtures, weaker case-level context independence
- Provider/model request: OpenAI, gpt-5.6-sol/high requested; effective host version/model/reasoning/settings unavailable
- Mandatory grades: 78 pass, 0 fail, 1 unavailable
- Measurements: {artifact_bytes} artifact bytes; {total_output_bytes} total output bytes under the recorded definitions. These are completeness measurements, not a savings claim.

| Order | Case | Status | Mandatory checks | Output |
|---:|---|---|---|---|
'''+'\n'.join(rows)+'''

## Extra predeclared analysis prompts

1. `Analyze rejecting negative amounts; produce a reference map, no implementation recipe` — completed from a fresh initial `existing-test-home` fixture.
2. `Analyze the fetch return-contract change; produce a reference map, no implementation recipe.` — completed from a fresh initial `consumer-closure` fixture.

Both exact prompt byte comparisons pass. The artifacts remain reference maps and do not contain implementation recipes.

## Failures, pending questions, and unavailable evidence

- `xxd` was unavailable during a validation check; `od` succeeded as the fallback. This did not affect a trial case.
- `authorization-cadence` variant C remains pending on the unspecified retention rule. Variant D remains pending on the user's disposition of item 1; item 2 was not presented.
- `check-reuse` has no supplied browser screenshot/output. Its browser-dependent mandatory check is unavailable; subjective wording approval remains human-owned.
- Native skill discovery, the full host transcript, tokens, cost, and effective model/settings identity are unavailable.
- Human owner review remains pending for judgment-heavy grades.

## Confidence & unverified

Confidence score: 97% — exact inputs and skill bodies are hashed, stateful claims have tool traces, tests/reproduction actually ran, and all mandatory checks have locators.

3% uncertainty — one browser-dependent check lacks evidence; shared context weakens case-level independence; the human owner and parent grounding are pending.
'''
write(ROOT/'report.md',report)

# Append global provenance after run/report write.
gtrace=(ROOT/'tool-trace.md').read_text(encoding='utf-8')
gtrace += '\n## Reviewed-base verification\n\n' + '\n'.join(
    f'- `{r["skill"]}` snapshot `{r["snapshot_sha256"]}`; base `{r["base_sha256"]}`; match={str(r["match"]).lower()}'
    for r in baseline_trace)
gtrace += '\n\n## Prompt byte verification\n\n' + '\n'.join(
    f'- `{r.get("case_id", "extra-"+str(r.get("extra_order")))}` exact={str(r["prompt_exact"]).lower()} sha256=`{r["prompt_sha256"]}`'
    for r in integrity)
gtrace += '\n\nFull host transcript remains unavailable.\n'
write(ROOT/'tool-trace.md',gtrace)
print(json.dumps({'status':run_record['status'],'artifact_bytes':artifact_bytes,'total_output_bytes':total_output_bytes,'grades':'78 pass, 0 fail, 1 unavailable'}))
