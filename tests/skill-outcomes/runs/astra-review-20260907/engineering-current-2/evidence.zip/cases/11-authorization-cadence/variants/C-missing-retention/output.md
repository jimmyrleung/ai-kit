Status: pending clarification.

Blocking question: Which records or data must be retained, for how long, and which deletion exceptions apply? This rule changes the scope and risk map, so it is not inferred.
