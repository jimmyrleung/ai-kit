Item 1: Should name matching be case-sensitive or case-insensitive?

Recommendation: case-insensitive, confidence 80%, because users usually expect names to match regardless of capitalization. Decision is pending; only item 1 is presented this turn.
