# Check reuse matrix

The initial build and complete discovered unit suite actually ran with exit 0. Their source, test, config, command, Python, platform, and suite-scope identities are recorded in `artifacts/prior-run-identity.json`; the stronger four-test fixture and fresh mutation identities are in `artifacts/variant-identities.json`.

| Independent state | Result | Reason |
|---|---|---|
| All identities match | **reusable pass** | executed, complete evidence and every recorded identity match |
| Source changed | **stale** | fresh variant source identity differs and invalidates build and unit evidence |
| Relevant config changed | **stale** | fresh variant config identity differs and invalidates affected evidence |
| Integration suite blocked | **blocked** | absence of an executable environment cannot become pass |
| Smaller subset exits 0 | **unverified for full suite** | executed 1-test `test_calc.py` subset cannot stand for the recorded 4-test full suite |
| Deliberate staging-only config difference | **pass for asymmetry check** | difference is documented and irrelevant to the required key; syntax alone does not fail it |
| Required production key absent | **fail** | production readiness requires the key and no deliberate irrelevance can satisfy it |
| Browser screenshot absent from fixture | **unavailable** | no actual screenshot/output exists to inspect; observable button AC remains unverified |
| Subjective wording preference | **pending human judgment** | even a screenshot could show the words, not approve their tone |

No build/unit rerun is needed in the exact-match row. Every mutation is evaluated from an independent identity set.

## Confidence & unverified

Confidence: 97% — matching evidence was executed and identity-bound; invalidation rules are explicit.

3% uncertainty — integration and browser evidence were not supplied, so those rows cannot become passes.
