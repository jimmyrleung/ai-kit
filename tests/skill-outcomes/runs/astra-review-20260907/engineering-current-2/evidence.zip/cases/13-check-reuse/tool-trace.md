# Available tool trace

## 1. setup evidence

- Started: 2026-09-07T10:43:44.789568+00:00
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/13-check-reuse/fixture-work`
- Command: `['python3', '-m', 'compileall', 'calc.py']`
- Exit: 0

```text
Compiling 'calc.py'...
```

## 2. setup evidence

- Started: 2026-09-07T10:43:44.874271+00:00
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/13-check-reuse/fixture-work`
- Command: `['python3', '-m', 'unittest', 'discover', '-s', 'tests']`
- Exit: 0

```text
.
----------------------------------------------------------------------
Ran 1 test in 0.000s

OK
```

## Fresh full-evidence fixture and mutation probes

### V1 — setup evidence
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/13-check-reuse/fixture-evidence-base`
- Command: `['python3', '-m', 'compileall', 'calc.py']`
- Exit: 0
```text

```

### V2 — setup evidence
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/13-check-reuse/fixture-evidence-base`
- Command: `['python3', '-m', 'unittest', 'discover', '-s', 'tests']`
- Exit: 0
```text
....
----------------------------------------------------------------------
Ran 4 tests in 0.000s

OK
```

### V3 — agent subset
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/13-check-reuse/variants/smaller-subset`
- Command: `['python3', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_calc.py']`
- Exit: 0
```text
.
----------------------------------------------------------------------
Ran 1 test in 0.000s

OK
```
