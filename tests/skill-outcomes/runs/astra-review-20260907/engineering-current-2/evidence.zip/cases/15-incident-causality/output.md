# Incident causality variants

Effective fixture policy: active P1 uses streamlined confidence threshold **70**; normal non-P1 threshold is 90. No deployment is authorized.

## A — source/config suggestion only

`race.py:1-3` contains a check-then-write race candidate, but `incident.log:1-2` has no key trace or evidence that this branch executed. Root-cause hop: **ASSUMED**. Status: candidate cause, confidence 48%, below the P1 threshold. No fix is proposed. Confirm/refute with a correlated per-key trace capturing request id, exact key, build/config identity, both branch decisions, and write outcomes during the incident window; include a known duplicate positive control.

Reversible mitigation proposal, not executed: pause automated retries for the affected operation; monitor duplicate applications and request-loss/latency; rollback by restoring retries if loss or latency breaches the incident baseline. This limits exposure without claiming remediation.

## B — deterministic local defect

Executed `source.fee(-1)` returned `-0.02` (trace exit 0). Expected contract forbids negative fees, so the local divergence at `source.py:1-2` is **VERIFIED** (Data Validation), confidence 98%. Minimal local fix: reject negative input at this function and add negative/zero/positive tests. This proves a fixture defect, not that the defect caused the production P1.

## C — supplied synthetic causal runtime

`artifacts/variant-c-synthetic-runtime.txt` is explicitly synthetic. Within that fixture it binds request `req-42`, key `key-7`, config, build, two absent checks, and two completed applies, while refuting the timeout-only hypothesis. The check-then-write race is a bounded **VERIFIED fixture cause**, confidence 75%, which clears the authorized P1 threshold 70. It does not establish live-system truth.

Streamlined artifact-review lane: root cause + proposed fix only, gate 70. Review result: Approved with notes at 75% for the synthetic fixture. Minimal remediation design remains separate: make check-and-apply atomic at `race.py:2-3`, with a concurrency reproduction. Reversible mitigation: serialize the affected key path behind a flag; monitor duplicates, throughput, and latency; rollback the flag if latency exceeds the stated incident threshold. Neither action was deployed.

## Confidence & unverified

Confidence: 96% — A preserves uncertainty, B is executed, and C's synthetic provenance plus threshold are explicit.

4% uncertainty — no live production traces, deployment state, impact population, or mitigation thresholds were supplied; live cause and remediation remain unverified.
