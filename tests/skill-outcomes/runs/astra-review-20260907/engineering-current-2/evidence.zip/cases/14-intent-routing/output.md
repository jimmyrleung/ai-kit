# Independent routing results

| Variant | Route/result |
|---|---|
| A | **Recommend:** `analyze-work search` — confidence 96% — recommend-only feature mapping; do not execute. Old completed billing docs are unrelated. |
| B | **Recommend:** `implement-task search` — confidence 97% — the reviewed task and local authorization satisfy prerequisites, so implementation can continue when invoked. Triage itself does not execute. |
| C | **Recommend:** `analyze-work search` — confidence 95% — current new-feature intent outranks the unrelated incident's rejected review. |
| D | **Recommend:** `review-implementation <prefix>` — confidence 96% — content-hash staleness prevents advancement until a fresh review covers current bytes. |
| E | **Recommend:** `walkthrough-implementation` — confidence 99% — the user explicitly requested the implementation tour; the tour proceeds one dependency-ordered step per turn. |
| F | **Pause at deployment authorization** — confidence 99% — repository completion does not authorize deployment; keep deployment pending and request authority only at that boundary. |

An unrequested walkthrough may be offered near commit but is not automatically started. No route auto-deploys.

## Confidence & unverified

Confidence: 97% — each route follows current intent and stated artifact validity.

3% uncertainty — variants B, D, and F omit concrete prefix names, so argument placeholders remain unresolved.
