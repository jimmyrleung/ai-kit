# Implementation result

Extended the suitable existing `tests/test_calc.py`; no new test module was created.

`calc.py` now rejects only `amount < 0`. The executed build command `python3 -m py_compile calc.py` exited 0. The executed suite `python3 -m unittest discover -s tests -v` exited 0; its trace shows negative, zero, and positive scenarios. No helper, broad refactor, reformat, or unrelated cleanup was added.

## Verification

- Gate 1 build/test: **pass** — commands actually ran with exit 0.
- Gate 2 ACs: **pass** — negative raises; zero and positive are preserved by executed tests.
- Gate 3 cross-cutting: **pass** — no environment matrix, budget, or SDK pin applies.

## Confidence & unverified

Confidence: 99% — all repository inputs were read before editing and the complete unittest suite passed.

1% uncertainty — behavior for non-numeric inputs was outside the requested scope.
