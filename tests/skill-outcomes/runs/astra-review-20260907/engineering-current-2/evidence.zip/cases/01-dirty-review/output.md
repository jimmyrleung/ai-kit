# Dirty review result

Base: fixture-base `9c7ee27d8f138ca45c7e0cf279712fcecffe0a0a`. Current HEAD is recorded in the tool trace. Review scope is Task A only.

## Layer coverage

| Transition | Evidence | Task A content inspected |
|---|---|---|
| fixture-base → HEAD | `tool-trace.md`, command 9 | committed guard in `calc.py` |
| HEAD → index | command 10 | staged `calc.py` docstring and `old.md` → `new.md` rename |
| index → working tree | command 11 | unstaged `calc.py` explanatory note |
| filesystem outside index | command 12 | untracked `fresh.txt`; `unrelated.txt` identified separately as Task B |

The rename records both paths: `old.md` → `new.md`. `unrelated.txt` is excluded because `tasks.md` assigns it to Task B. `legacy.txt` is excluded because it predates fixture-base. Each transition is inspected exactly once, so staged content is not double-counted as an unstaged diff.

## Evidence coverage

The supplied review stamp shape (`short SHA +dirty`) is insufficient for this state: it cannot identify which staged, unstaged, or untracked bytes were reviewed. `artifacts/current-byte-identities.json` records SHA-256 for every current scoped and excluded file. Review evidence covers current content only if it binds the Task A file set and these byte identities; until such a content-bound record is written, status is **unverified**.

## Confidence & unverified

Confidence: 98% — all four Git layers and current bytes were directly inspected.

2% uncertainty — rename similarity is Git's presentation choice, but old/new ownership is independently explicit in `tasks.md`.
