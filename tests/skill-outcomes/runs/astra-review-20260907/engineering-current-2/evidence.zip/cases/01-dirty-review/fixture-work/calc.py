def fee(amount):
    """Return a two-percent fee."""
    if amount < 0:
        raise ValueError("negative amount")
    return amount * 0.02

# pending explanatory note
