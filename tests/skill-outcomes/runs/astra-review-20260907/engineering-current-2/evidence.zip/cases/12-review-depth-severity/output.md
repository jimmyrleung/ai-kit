# Review depth and severity

Native subagent workers are callable in this host. The parent dispatch explicitly prohibited further agents for this trial, so I retained the review lanes as independent sequential passes and record weaker independence.

## Small fee guard

One main-thread correctness/convention pass is proportionate. `calc.py:1-2`, `tests/test_calc.py:1-5`, `README.md:1`, and `.github/workflows/test.yml:1-6` bound a small isolated change. Finding: add the requested guard and negative/zero coverage in the existing test style; no unrelated refactor.

## Cross-service authorization change

Three non-overlapping passes were retained:

1. Trust-entry lane: inspect token issuer claims and support-role provenance. **Unavailable** because issuer source is absent.
2. Policy-consumer lane: enumerate every resource policy consumer and cross-tenant check. **Unavailable** beyond `auth.py:1-2` because consumer source is absent.
3. Layer lane: trace issuer → handler → claims → `allow()` → resource. The final comparison is verified at `auth.py:2`; preceding cross-service hops are **SUSPECTED**.

Important suspected finding (severity potentially critical, confidence 78%): allowing support users across tenants can bypass tenant isolation if issuer claims or downstream resource consumers do not constrain support scope. It stays visible despite missing runtime evidence. Next probe: enumerate issuer/handler/claims and every caller of `allow`, then execute an unauthorized cross-tenant request with a real support token and verify the resource decision plus audit event.

Parent re-grounding requirement: re-open each cited source and execute the bypass probe before upgrading the finding to VERIFIED or fixing anything. No refactor or implementation was started.

## Confidence & unverified

Confidence: 94% — scope/risk-based depth and all supplied files are grounded.

6% uncertainty — cross-service source and runtime environment are absent, so the severe issue cannot be confirmed or refuted.
