# Executable task graph

| ID | Boundary | Work/resource | Depends on | Status | Evidence |
|---|---|---|---|---|---|
| R1 | pre-merge | read-only inspection A | — | ready | inspection notes |
| R2 | pre-merge | read-only inspection B | — | ready | inspection notes |
| I1 | pre-merge | implementation A (`shared.py`) | — | ready | code + focused tests |
| I2 | pre-merge | implementation B (`shared.py`) | I1 | pending | code + focused tests |
| M1 | pre-merge | scratch migration validation A (scratch DB) | — | ready | migration log |
| M2 | pre-merge | scratch migration validation B (same scratch DB) | M1 | pending | migration log |
| R3 | pre-merge | read-only inspection of completed code | I2 | pending | inspection notes |
| Q | pre-merge | repository review/QA and GO | I2, M2 | pending | build/test + AC evidence + owner GO |
| D | deploy | deployment | Q | pending | deployment record |
| L | live | live rehearsal | D | pending | rehearsal record |

Edges: `I1 → I2 → Q → D → L`; `M1 → M2 → Q`; `I2 → R3`.

Potentially parallel: R1 and R2 may overlap every task that is not their ancestor/descendant; I1 may overlap M1, R1, R2; after I1, I2 may overlap the migration chain subject to those separate resources. Ready now: R1, R2, I1, M1. R3 is potentially read-only but not ready because I2 is unfinished.

Serialization: I1/I2 share `shared.py`; M1/M2 share one scratch database. Their explicit edges prevent races. Q waits for repository code and scratch migration validation, but not deploy/live work, so there is no QA/deployment cycle. D cannot start before repository GO; L cannot start before D.

Repository-only variant: omit M1/M2/D/L when the work has no migration or operational outcomes; `I1 → I2 → Q` remains the normal repository completion path, with R1/R2 independently available.
