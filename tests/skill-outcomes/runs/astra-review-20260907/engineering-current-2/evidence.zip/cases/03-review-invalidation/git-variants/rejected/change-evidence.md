# Change evidence

<!-- evidence:begin -->
{"ac_sha256": "34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30", "head": "373789b78a9b2b569449988a5dd2bba209ad9c87", "schema": 1, "source_sha256": "9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9", "task": "Task A", "verdict": "rejected"}
<!-- evidence:end -->
