# Available tool trace

## Git baseline and independent variant probes

### G1 — setup
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/fixture-versioned-base`
- Command: `['git', 'init', '-q']`
- Exit: 0
```text

```

### G2 — setup
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/fixture-versioned-base`
- Command: `['git', 'config', 'user.name', 'Fixture Runner']`
- Exit: 0
```text

```

### G3 — setup
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/fixture-versioned-base`
- Command: `['git', 'config', 'user.email', 'fixture@example.invalid']`
- Exit: 0
```text

```

### G4 — setup
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/fixture-versioned-base`
- Command: `['git', 'add', 'spec.md']`
- Exit: 0
```text

```

### G5 — setup
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/fixture-versioned-base`
- Command: `['git', 'add', 'source.py']`
- Exit: 0
```text

```

### G6 — setup
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/fixture-versioned-base`
- Command: `['git', 'commit', '-q', '-m', 'evidence baseline']`
- Exit: 0
```text

```

### G7 — setup
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/fixture-versioned-base`
- Command: `['git', 'rev-parse', 'HEAD']`
- Exit: 0
```text
373789b78a9b2b569449988a5dd2bba209ad9c87
```

### G8 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/same-head-source`
- Command: `['git', 'rev-parse', 'HEAD']`
- Exit: 0
```text
373789b78a9b2b569449988a5dd2bba209ad9c87
```

### G9 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/same-head-source`
- Command: `['git', 'status', '--short']`
- Exit: 0
```text
 M source.py
?? change-evidence.md
```

### G10 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/edited-ac`
- Command: `['git', 'rev-parse', 'HEAD']`
- Exit: 0
```text
373789b78a9b2b569449988a5dd2bba209ad9c87
```

### G11 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/edited-ac`
- Command: `['git', 'status', '--short']`
- Exit: 0
```text
 M spec.md
?? change-evidence.md
```

### G12 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/task-b`
- Command: `['git', 'rev-parse', 'HEAD']`
- Exit: 0
```text
373789b78a9b2b569449988a5dd2bba209ad9c87
```

### G13 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/task-b`
- Command: `['git', 'status', '--short']`
- Exit: 0
```text
?? change-evidence.md
```

### G14 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/rejected`
- Command: `['git', 'rev-parse', 'HEAD']`
- Exit: 0
```text
373789b78a9b2b569449988a5dd2bba209ad9c87
```

### G15 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/rejected`
- Command: `['git', 'status', '--short']`
- Exit: 0
```text
?? change-evidence.md
```

### G16 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/evidence-only`
- Command: `['git', 'rev-parse', 'HEAD']`
- Exit: 0
```text
373789b78a9b2b569449988a5dd2bba209ad9c87
```

### G17 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/evidence-only`
- Command: `['git', 'status', '--short']`
- Exit: 0
```text
?? change-evidence.md
```

### G18 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/unrelated`
- Command: `['git', 'rev-parse', 'HEAD']`
- Exit: 0
```text
373789b78a9b2b569449988a5dd2bba209ad9c87
```

### G19 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/unrelated`
- Command: `['git', 'status', '--short']`
- Exit: 0
```text
?? change-evidence.md
?? unrelated.py
```

### G20 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/missing-identity`
- Command: `['git', 'rev-parse', 'HEAD']`
- Exit: 0
```text
373789b78a9b2b569449988a5dd2bba209ad9c87
```

### G21 — agent
- CWD: `/tmp/astra-backlog-5VdqNm/trials/engineering/current/2/cases/03-review-invalidation/git-variants/missing-identity`
- Command: `['git', 'status', '--short']`
- Exit: 0
```text
?? change-evidence.md
```
