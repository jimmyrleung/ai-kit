# Spec
## Task A requirements
- Return a positive amount.
## Task B requirements
- Add a receipt.
