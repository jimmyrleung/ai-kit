def amount():
    return 1
# dirty
