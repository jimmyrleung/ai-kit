# Evidence invalidation matrix

Initial identities: `source.py` `9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9`; exact Task A section `34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30`. Each mutation starts from a fresh copy.

| Independent mutation | Result | Reason |
|---|---|---|
| same-HEAD dirty source edit | **stale** | source byte identity differs although HEAD is unchanged |
| edited reviewed AC | **stale** | Task A requirement-section identity differs |
| Task B requested | **unverified** | Task-A-only record has no Task B scope identity |
| rejected verdict | **stale** | a rejected record cannot advance |
| evidence-only append | **reusable** | append is wholly inside exact evidence delimiters; scoped source and AC bytes match |
| unrelated file edit | **reusable** | edited file is outside recorded Task A scope; scoped identities match |
| missing identity field | **unverified** | required content identity is absent and cannot be inferred from HEAD |

Evidence-only content is excluded only between the literal `<!-- evidence:begin -->` and `<!-- evidence:end -->` delimiters. Other document bytes remain identity-bearing.

## Confidence & unverified

Confidence: 98% — classifications compare explicit scope and byte identities.

2% uncertainty — the version-1 record format is synthetic for this fixture; no external schema was substituted.
