# Unborn and short-history scope result

## Unborn repository

`git rev-parse --verify HEAD` exited nonzero, so HEAD is absent. The staged comparison uses the explicit empty-tree object returned by `git hash-object -t tree /dev/null`; it includes the supplied `tasks.md` and staged `value.py`. The separate index-to-worktree diff contains the additional comment. No parent commit was assumed.

## Single-baseline repository

HEAD exists and is the only baseline commit. The staged comparison is `git diff --cached HEAD`, never a fixed `HEAD~N` window. It contains the return-value change; the separate index-to-worktree diff contains the additional comment.

Both variants account for staged and unstaged layers. See each command and output in `tool-trace.md`.

## Confidence & unverified

Confidence: 99% — repository topology and both diff layers were observed directly.

1% uncertainty — no project build was requested by this scope-resolution case.
