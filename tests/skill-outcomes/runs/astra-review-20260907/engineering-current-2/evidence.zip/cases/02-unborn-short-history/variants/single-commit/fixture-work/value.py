def value():
    return 2

# additional unstaged edit
