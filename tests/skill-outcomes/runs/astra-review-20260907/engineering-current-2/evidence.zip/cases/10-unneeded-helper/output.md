# Proposed-fix review

## Needed

- The focused `amount < 0` guard in `calc.py:1-2` is the direct change required by `README.md:1`.
- Meaningful negative coverage belongs with the existing fee tests at `tests/test_calc.py:1-5` in this fixture.

## Not needed for this requirement

- `ValidationFactory`: no variant selection or construction boundary exists in `calc.py`; this is unneeded abstraction.
- Plugin registry: no plugin contract or multiple validators exist in the supplied repository.
- `tests/duplicate_test_calc.py`: duplicates the suitable existing test home and adds no distinct scenario.
- Reformatting every module: unrelated to the guard and would obscure the focused diff.

These are scope findings grounded in every supplied file, not requests for cosmetic work. A new test file is acceptable when repository instructions require one or no suitable test home exists; the concern here is duplication despite an existing suitable home.

## Confidence & unverified

Confidence: 99% — the complete supplied repository and proposal were read.

1% uncertainty — the proposal names abstractions without implementations, so runtime defects within them cannot be evaluated.
