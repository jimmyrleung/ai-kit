# Tasks
### Task 1
Files: value.py
#### Testing requirements
- [ ] Existing test green
#### Acceptance criteria
- [ ] AC-1: returns 2
#### Verify — old run
- [x] AC #9 old generated evidence
## Verify — 2026-09-07 (run 1)
- [x] Gate 1 — build/test: pass (supplied successful runner result; not executed in this trial)
- [x] Gate 2 — AC checklist (1 item)
  - [x] AC-1: returns 2 — pass (supplied runner result)
- [x] Gate 3 — cross-cutting: pass (no budget or SDK pin)

## Verify — 2026-09-07 (run 2)
- [x] Gate 1 — build/test: pass (supplied successful runner result; not executed in this trial)
- [x] Gate 2 — AC checklist (1 item)
  - [x] AC-1: returns 2 — pass (supplied runner result)
- [x] Gate 3 — cross-cutting: pass (no budget or SDK pin)

### Task 2
#### Acceptance criteria
- [ ] AC-2: returns 3
