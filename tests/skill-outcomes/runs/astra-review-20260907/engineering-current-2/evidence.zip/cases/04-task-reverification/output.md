# Task reverification result

`artifacts/tasks-preserved.md` keeps the old evidence and appends two delimited `## Verify` runs inside Task 1, before Task 2. Both fresh runs extract exactly one AC: `tasks.md:7` (`AC-1`). The testing checkbox at line 5, old generated `AC #9` at line 9, and Task 2's `AC-2` at line 12 are excluded.

## Scope-resolution variants

- Numbered item: Task 1 begins at `numbered.md:2` and ends before item 2 at line 5; AC source is `numbered.md:4` (`AC-1`) only.
- Reviewed fix without tasks doc: task id `BUG-1`; tasks-doc stand-in `investigation.md`; expected-behavior AC source `investigation.md:3`; designated fix AC sources `fix-techspec.md:3` and `fix-techspec.md:4`.

## Exact QA handoffs

- Task-doc run: `prefix=tasks`, `task_id=Task 1`, `tasks_doc_path=tasks.md`, `artifact_path=tasks.md#Task-1`, `gates_to_run=build,ac,cross-cutting`, `mode=full`, `confidence_gate=90`, `gate_plan_pre_written=true`; AC source `tasks.md:7`.
- Numbered run: same gate settings, `task_id=Task 1`, `tasks_doc_path=numbered.md`, `artifact_path=numbered.md#item-1`; AC source `numbered.md:4`.
- Fix run: `prefix=BUG-1`, `task_id=BUG-1`, `tasks_doc_path=investigation.md`, `artifact_path=investigation.md`, same gate settings; AC sources `investigation.md:3`, `fix-techspec.md:3`, `fix-techspec.md:4`.
- Prefix QA is a separate later call and derives broader prefix scope; it is not implied by these per-task handoffs.

The green runner evidence is explicitly supplied synthetic evidence. No execution claim is made.

## Confidence & unverified

Confidence: 98% — heading/item boundaries and source lines were read directly.

2% uncertainty — the supplied successful runner lacks command identity, so only parsing and preservation are established.
