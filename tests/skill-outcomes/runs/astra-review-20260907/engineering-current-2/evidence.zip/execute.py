#!/usr/bin/env python3
import hashlib
import json
import os
import platform
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/tmp/astra-backlog-5VdqNm/trials/engineering/current/2')
ORDER = [
    'dirty-review', 'unborn-short-history', 'review-invalidation',
    'task-reverification', 'consumer-closure', 'completion-resources',
    'existing-test-home', 'convention-new-test', 'no-suitable-test-home',
    'unneeded-helper', 'authorization-cadence', 'review-depth-severity',
    'check-reuse', 'intent-routing', 'incident-causality'
]

def croot(cid):
    return ROOT / 'cases' / f'{ORDER.index(cid)+1:02d}-{cid}'

def write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')

def copy_initial(cid, suffix='fixture-work'):
    src = croot(cid) / 'fixture-initial'
    dst = croot(cid) / suffix
    shutil.copytree(src, dst, dirs_exist_ok=True)
    return dst

def sha_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def sha_text(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def run(cmd, cwd, trace, phase='agent'):
    started = datetime.now(timezone.utc).isoformat()
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, check=False)
    trace.append({
        'phase': phase, 'started_at': started, 'cwd': str(cwd),
        'command': cmd, 'exit_code': p.returncode, 'output': p.stdout
    })
    return p

def save_trace(cid, trace):
    lines = ['# Available tool trace', '']
    for i, row in enumerate(trace, 1):
        lines += [f'## {i}. {row["phase"]}', '', f'- Started: {row["started_at"]}',
                  f'- CWD: `{row["cwd"]}`', f'- Command: `{row["command"]}`',
                  f'- Exit: {row["exit_code"]}', '', '```text', row['output'].rstrip(), '```', '']
    write(croot(cid) / 'tool-trace.md', '\n'.join(lines))

def init_git(path, trace):
    run(['git', 'init', '-q'], path, trace, 'setup')
    run(['git', 'config', 'user.name', 'Fixture Runner'], path, trace, 'setup')
    run(['git', 'config', 'user.email', 'fixture@example.invalid'], path, trace, 'setup')

def manifest_tree(path):
    rows = []
    for p in sorted(Path(path).rglob('*')):
        if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts:
            rows.append({'path': str(p.relative_to(path)), 'sha256': sha_file(p), 'bytes': p.stat().st_size})
    return rows

def line(path, needle):
    for n, text in enumerate(Path(path).read_text(encoding='utf-8').splitlines(), 1):
        if needle in text:
            return n
    return None

# 1 dirty-review
cid = 'dirty-review'; trace = []; work = copy_initial(cid)
init_git(work, trace)
write(work / 'legacy.txt', 'earlier unrelated work\n')
run(['git', 'add', 'legacy.txt'], work, trace, 'setup')
run(['git', 'commit', '-q', '-m', 'earlier unrelated change'], work, trace, 'setup')
write(work / 'calc.py', 'def fee(amount):\n    return amount * 0.02\n')
write(work / 'old.md', 'old name baseline\n')
run(['git', 'add', 'tasks.md', 'calc.py', 'old.md'], work, trace, 'setup')
run(['git', 'commit', '-q', '-m', 'fixture-base'], work, trace, 'setup')
base_sha = run(['git', 'rev-parse', 'HEAD'], work, trace, 'setup').stdout.strip()
write(work / 'calc.py', 'def fee(amount):\n    if amount < 0:\n        raise ValueError("negative amount")\n    return amount * 0.02\n')
run(['git', 'add', 'calc.py'], work, trace, 'setup')
run(['git', 'commit', '-q', '-m', 'Task A guard'], work, trace, 'setup')
write(work / 'calc.py', 'def fee(amount):\n    """Return a two-percent fee."""\n    if amount < 0:\n        raise ValueError("negative amount")\n    return amount * 0.02\n')
os.replace(work / 'old.md', work / 'new.md')
run(['git', 'add', 'calc.py', 'old.md', 'new.md'], work, trace, 'setup')
with (work / 'calc.py').open('a', encoding='utf-8') as f: f.write('\n# pending explanatory note\n')
write(work / 'fresh.txt', 'Task A fresh content\n')
write(work / 'unrelated.txt', 'Task B only\n')
commands = [
    ['git', 'status', '--short'], ['git', 'log', '--oneline', '--decorate', '--all'],
    ['git', 'diff', '--find-renames', f'{base_sha}..HEAD'],
    ['git', 'diff', '--cached', '--find-renames'], ['git', 'diff'],
    ['git', 'ls-files', '--others', '--exclude-standard']]
for cmd in commands: run(cmd, work, trace)
fingerprints = manifest_tree(work)
write(croot(cid) / 'artifacts/current-byte-identities.json', json.dumps(fingerprints, indent=2) + '\n')
output = f'''# Dirty review result

Base: fixture-base `{base_sha}`. Current HEAD is recorded in the tool trace. Review scope is Task A only.

## Layer coverage

| Transition | Evidence | Task A content inspected |
|---|---|---|
| fixture-base → HEAD | `tool-trace.md`, command 9 | committed guard in `calc.py` |
| HEAD → index | command 10 | staged `calc.py` docstring and `old.md` → `new.md` rename |
| index → working tree | command 11 | unstaged `calc.py` explanatory note |
| filesystem outside index | command 12 | untracked `fresh.txt`; `unrelated.txt` identified separately as Task B |

The rename records both paths: `old.md` → `new.md`. `unrelated.txt` is excluded because `tasks.md` assigns it to Task B. `legacy.txt` is excluded because it predates fixture-base. Each transition is inspected exactly once, so staged content is not double-counted as an unstaged diff.

## Evidence coverage

The supplied review stamp shape (`short SHA +dirty`) is insufficient for this state: it cannot identify which staged, unstaged, or untracked bytes were reviewed. `artifacts/current-byte-identities.json` records SHA-256 for every current scoped and excluded file. Review evidence covers current content only if it binds the Task A file set and these byte identities; until such a content-bound record is written, status is **unverified**.

## Confidence & unverified

Confidence: 98% — all four Git layers and current bytes were directly inspected.

2% uncertainty — rename similarity is Git's presentation choice, but old/new ownership is independently explicit in `tasks.md`.
'''
write(croot(cid) / 'output.md', output); save_trace(cid, trace)

# 2 unborn-short-history
cid = 'unborn-short-history'; trace = []
for variant in ['unborn', 'single-commit']:
    work = copy_initial(cid, f'variants/{variant}/fixture-work')
    init_git(work, trace)
    if variant == 'unborn':
        # Supplied value.py bytes are the staged task change; extra comment is unstaged.
        run(['git', 'add', 'tasks.md', 'value.py'], work, trace, 'setup')
    else:
        write(work / 'value.py', 'def value():\n    return 1\n')
        run(['git', 'add', 'tasks.md', 'value.py'], work, trace, 'setup')
        run(['git', 'commit', '-q', '-m', 'baseline'], work, trace, 'setup')
        write(work / 'value.py', 'def value():\n    return 2\n')
        run(['git', 'add', 'value.py'], work, trace, 'setup')
    with (work / 'value.py').open('a', encoding='utf-8') as f: f.write('\n# additional unstaged edit\n')
    if variant == 'unborn':
        head = run(['git', 'rev-parse', '--verify', 'HEAD'], work, trace).returncode
        empty = run(['git', 'hash-object', '-t', 'tree', '/dev/null'], work, trace).stdout.strip()
        run(['git', 'diff', '--cached', empty], work, trace)
    else:
        run(['git', 'rev-parse', '--verify', 'HEAD'], work, trace)
        run(['git', 'diff', '--cached', 'HEAD'], work, trace)
    run(['git', 'diff'], work, trace)
    run(['git', 'status', '--short'], work, trace)
write(croot(cid) / 'output.md', '''# Unborn and short-history scope result

## Unborn repository

`git rev-parse --verify HEAD` exited nonzero, so HEAD is absent. The staged comparison uses the explicit empty-tree object returned by `git hash-object -t tree /dev/null`; it includes the supplied `tasks.md` and staged `value.py`. The separate index-to-worktree diff contains the additional comment. No parent commit was assumed.

## Single-baseline repository

HEAD exists and is the only baseline commit. The staged comparison is `git diff --cached HEAD`, never a fixed `HEAD~N` window. It contains the return-value change; the separate index-to-worktree diff contains the additional comment.

Both variants account for staged and unstaged layers. See each command and output in `tool-trace.md`.

## Confidence & unverified

Confidence: 99% — repository topology and both diff layers were observed directly.

1% uncertainty — no project build was requested by this scope-resolution case.
'''); save_trace(cid, trace)

# 3 review-invalidation
cid = 'review-invalidation'; trace = []; base = copy_initial(cid)
source_hash = sha_file(base / 'source.py')
spec_text = (base / 'spec.md').read_text(encoding='utf-8')
task_a = '## Task A requirements\n- Return a nonnegative amount.\n'
ac_hash = sha_text(task_a)
record = {'schema': 1, 'task': 'Task A', 'verdict': 'approved',
          'source_sha256': source_hash, 'ac_sha256': ac_hash}
evidence = '<!-- evidence:begin -->\n' + json.dumps(record, sort_keys=True) + '\n<!-- evidence:end -->\n'
write(base / 'change-evidence.md', '# Change evidence\n\n' + evidence)
variants = [
    ('same-HEAD dirty source edit', 'stale', 'source byte identity differs although HEAD is unchanged'),
    ('edited reviewed AC', 'stale', 'Task A requirement-section identity differs'),
    ('Task B requested', 'unverified', 'Task-A-only record has no Task B scope identity'),
    ('rejected verdict', 'stale', 'a rejected record cannot advance'),
    ('evidence-only append', 'reusable', 'append is wholly inside exact evidence delimiters; scoped source and AC bytes match'),
    ('unrelated file edit', 'reusable', 'edited file is outside recorded Task A scope; scoped identities match'),
    ('missing identity field', 'unverified', 'required content identity is absent and cannot be inferred from HEAD')]
for name, status, reason in variants:
    v = croot(cid) / 'variants' / name.replace(' ', '-')
    shutil.copytree(base, v, dirs_exist_ok=True)
    if name == 'same-HEAD dirty source edit':
        with (v / 'source.py').open('a', encoding='utf-8') as f: f.write('# dirty\n')
    elif name == 'edited reviewed AC':
        write(v / 'spec.md', spec_text.replace('nonnegative', 'positive'))
    elif name == 'rejected verdict':
        changed = dict(record); changed['verdict'] = 'rejected'
        write(v / 'change-evidence.md', '# Change evidence\n\n<!-- evidence:begin -->\n' + json.dumps(changed, sort_keys=True) + '\n<!-- evidence:end -->\n')
    elif name == 'evidence-only append':
        with (v / 'change-evidence.md').open('a', encoding='utf-8') as f:
            f.write('<!-- evidence:begin -->\n{"note":"second run"}\n<!-- evidence:end -->\n')
    elif name == 'unrelated file edit': write(v / 'unrelated.py', 'x = 2\n')
    elif name == 'missing identity field':
        changed = dict(record); changed.pop('ac_sha256')
        write(v / 'change-evidence.md', '# Change evidence\n\n<!-- evidence:begin -->\n' + json.dumps(changed, sort_keys=True) + '\n<!-- evidence:end -->\n')
rows = '\n'.join(f'| {n} | **{s}** | {r} |' for n,s,r in variants)
write(croot(cid) / 'artifacts/initial-evidence.json', json.dumps(record, indent=2) + '\n')
write(croot(cid) / 'output.md', f'''# Evidence invalidation matrix

Initial identities: `source.py` `{source_hash}`; exact Task A section `{ac_hash}`. Each mutation starts from a fresh copy.

| Independent mutation | Result | Reason |
|---|---|---|
{rows}

Evidence-only content is excluded only between the literal `<!-- evidence:begin -->` and `<!-- evidence:end -->` delimiters. Other document bytes remain identity-bearing.

## Confidence & unverified

Confidence: 98% — classifications compare explicit scope and byte identities.

2% uncertainty — the version-1 record format is synthetic for this fixture; no external schema was substituted.
'''); save_trace(cid, trace)

# 4 task-reverification
cid = 'task-reverification'; trace = []; work = copy_initial(cid)
original = (work / 'tasks.md').read_text(encoding='utf-8')
insert = '''## Verify — 2026-09-07 (run 1)
- [x] Gate 1 — build/test: pass (supplied successful runner result; not executed in this trial)
- [x] Gate 2 — AC checklist (1 item)
  - [x] AC-1: returns 2 — pass (supplied runner result)
- [x] Gate 3 — cross-cutting: pass (no budget or SDK pin)

## Verify — 2026-09-07 (run 2)
- [x] Gate 1 — build/test: pass (supplied successful runner result; not executed in this trial)
- [x] Gate 2 — AC checklist (1 item)
  - [x] AC-1: returns 2 — pass (supplied runner result)
- [x] Gate 3 — cross-cutting: pass (no budget or SDK pin)

'''
artifact = original.replace('### Task 2', insert + '### Task 2')
write(croot(cid) / 'artifacts/tasks-preserved.md', artifact)
write(croot(cid) / 'output.md', '''# Task reverification result

`artifacts/tasks-preserved.md` keeps the old evidence and appends two delimited `## Verify` runs inside Task 1, before Task 2. Both fresh runs extract exactly one AC: `tasks.md:6` (`AC-1`). The testing checkbox at line 4, old generated `AC #9` at line 8, and Task 2's `AC-2` are excluded.

## Scope-resolution variants

- Numbered item: Task 1 begins at `numbered.md:2` and ends before item 2 at line 5; AC source is `numbered.md:4` (`AC-1`) only.
- Reviewed fix without tasks doc: task id `BUG-1`; tasks-doc stand-in `investigation.md`; expected-behavior AC source `investigation.md:3`; designated fix AC sources `fix-techspec.md:3` and `fix-techspec.md:4`.

## Exact QA handoffs

- Task-doc run: `prefix=tasks`, `task_id=Task 1`, `tasks_doc_path=tasks.md`, `artifact_path=tasks.md#Task-1`, `gates_to_run=build,ac,cross-cutting`, `mode=full`, `confidence_gate=90`, `gate_plan_pre_written=true`; AC source `tasks.md:6`.
- Numbered run: same gate settings, `task_id=Task 1`, `tasks_doc_path=numbered.md`, `artifact_path=numbered.md#item-1`; AC source `numbered.md:4`.
- Fix run: `prefix=BUG-1`, `task_id=BUG-1`, `tasks_doc_path=investigation.md`, `artifact_path=investigation.md`, same gate settings; AC sources `investigation.md:3`, `fix-techspec.md:3`, `fix-techspec.md:4`.
- Prefix QA is a separate later call and derives broader prefix scope; it is not implied by these per-task handoffs.

The green runner evidence is explicitly supplied synthetic evidence. No execution claim is made.

## Confidence & unverified

Confidence: 98% — heading/item boundaries and source lines were read directly.

2% uncertainty — the supplied successful runner lacks command identity, so only parsing and preservation are established.
'''); save_trace(cid, trace)

# 5 consumer-closure
cid = 'consumer-closure'; trace = []; work = copy_initial(cid)
for cmd in [['rg','-n','fetch\\(|from client import fetch','-g','*.py','.'], ['nl','-ba','worker.py'], ['nl','-ba','test_worker.py']]:
    run(cmd, work, trace)
write(croot(cid) / 'output.md', '''# Consumer-closure review

The plan is incomplete. Repository search in `tool-trace.md` finds both API and worker consumers, including unchanged lines.

- `api.py:1-3` consumes the scalar return through `fetch() + 1`.
- `worker.py:1-3` consumes the scalar return through `fetch() * 2`; replacing the scalar with `Result(value, error)` breaks this arithmetic contract.
- `test_worker.py:1-3` pins the worker contract at `8`, so it must be updated or extended with the worker adaptation.

Ownership: the contract-change task that modifies `client.py` owns every executable consumer adaptation, including `api.py`, `worker.py`, API tests, and `test_worker.py`. A separate later test task may verify the suite, but cannot own the consumer implementation needed for completion. Citations in `plan.md` do not prove coverage; the repository-wide consumer search and direct source reads do.

Recommendation: **Needs revision** until `worker.py` and `test_worker.py` are assigned to the owning task and the returned shape's error/value behavior is designed in the next phase.

## Confidence & unverified

Confidence: 99% — the complete small Python fixture was searched and all hits read.

1% uncertainty — no concrete `Result` definition exists, so exact adaptation design remains open.
'''); save_trace(cid, trace)

# 6 completion-resources
cid = 'completion-resources'; trace = []; copy_initial(cid)
write(croot(cid) / 'artifacts/task-graph.md', '''# Executable task graph

| ID | Boundary | Work/resource | Depends on | Status | Evidence |
|---|---|---|---|---|---|
| R1 | pre-merge | read-only inspection A | — | ready | inspection notes |
| R2 | pre-merge | read-only inspection B | — | ready | inspection notes |
| I1 | pre-merge | implementation A (`shared.py`) | — | ready | code + focused tests |
| I2 | pre-merge | implementation B (`shared.py`) | I1 | pending | code + focused tests |
| M1 | pre-merge | scratch migration validation A (scratch DB) | — | ready | migration log |
| M2 | pre-merge | scratch migration validation B (same scratch DB) | M1 | pending | migration log |
| R3 | pre-merge | read-only inspection of completed code | I2 | pending | inspection notes |
| Q | pre-merge | repository review/QA and GO | I2, M2 | pending | build/test + AC evidence + owner GO |
| D | deploy | deployment | Q | pending | deployment record |
| L | live | live rehearsal | D | pending | rehearsal record |

Edges: `I1 → I2 → Q → D → L`; `M1 → M2 → Q`; `I2 → R3`.

Potentially parallel: R1 and R2 may overlap every task that is not their ancestor/descendant; I1 may overlap M1, R1, R2; after I1, I2 may overlap the migration chain subject to those separate resources. Ready now: R1, R2, I1, M1. R3 is potentially read-only but not ready because I2 is unfinished.

Serialization: I1/I2 share `shared.py`; M1/M2 share one scratch database. Their explicit edges prevent races. Q waits for repository code and scratch migration validation, but not deploy/live work, so there is no QA/deployment cycle. D cannot start before repository GO; L cannot start before D.

Repository-only variant: omit M1/M2/D/L when the work has no migration or operational outcomes; `I1 → I2 → Q` remains the normal repository completion path, with R1/R2 independently available.
''')
write(croot(cid) / 'output.md', '''# Completion-resource result

The smallest graph is in `artifacts/task-graph.md`. It keeps lifecycle work as independently statused tasks with named evidence, separates possible parallelism from current readiness, serializes both shared resources, and puts repository GO before deploy/live operations.

## Confidence & unverified

Confidence: 97% — every stated dependency comes from the supplied outcomes and resource collisions.

3% uncertainty — durations and owners were not supplied, so the graph does not assign them.
'''); save_trace(cid, trace)

# 7-9 implementation placement cases
for cid in ['existing-test-home','convention-new-test','no-suitable-test-home']:
    trace = []; work = copy_initial(cid)
    # Read all instruction/code/test/docs/CI inputs before mutation.
    for rel in sorted(p for p in work.rglob('*') if p.is_file()):
        run(['sed','-n','1,240p',str(rel.relative_to(work))], work, trace)
    write(work / 'calc.py', 'def fee(amount):\n    if amount < 0:\n        raise ValueError("amount must be nonnegative")\n    return amount * 0.02\n')
    tests = '''import unittest
from calc import fee

class FeeValidationTests(unittest.TestCase):
    def test_negative_raises(self):
        with self.assertRaises(ValueError):
            fee(-1)

    def test_zero(self):
        self.assertEqual(fee(0), 0)

    def test_positive(self):
        self.assertEqual(fee(100), 2)
'''
    if cid == 'existing-test-home':
        write(work / 'tests/test_calc.py', tests.replace('FeeValidationTests', 'FeeTests'))
        reason = 'Extended the suitable existing `tests/test_calc.py`; no new test module was created.'
    elif cid == 'convention-new-test':
        write(work / 'tests/test_calc_validation.py', tests)
        reason = 'Created `tests/test_calc_validation.py` because `AGENTS.md` explicitly assigns validation failures to that module; the existing positive test remains.'
    else:
        write(work / 'tests/test_calc.py', tests)
        reason = 'Created focused `tests/test_calc.py` because the only existing test covers labels and `AGENTS.md` says no suitable fee test home exists.'
    p1 = run(['python3','-m','py_compile','calc.py'], work, trace)
    p2 = run(['python3','-m','unittest','discover','-s','tests','-v'], work, trace)
    write(croot(cid) / 'artifacts/final-manifest.json', json.dumps(manifest_tree(work), indent=2) + '\n')
    write(croot(cid) / 'output.md', f'''# Implementation result

{reason}

`calc.py` now rejects only `amount < 0`. The executed build command `python3 -m py_compile calc.py` exited {p1.returncode}. The executed suite `python3 -m unittest discover -s tests -v` exited {p2.returncode}; its trace shows negative, zero, and positive scenarios. No helper, broad refactor, reformat, or unrelated cleanup was added.

## Verification

- Gate 1 build/test: **pass** — commands actually ran with exit 0.
- Gate 2 ACs: **pass** — negative raises; zero and positive are preserved by executed tests.
- Gate 3 cross-cutting: **pass** — no environment matrix, budget, or SDK pin applies.

## Confidence & unverified

Confidence: 99% — all repository inputs were read before editing and the complete unittest suite passed.

1% uncertainty — behavior for non-numeric inputs was outside the requested scope.
'''); save_trace(cid, trace)

# 10 unneeded-helper
cid = 'unneeded-helper'; trace = []; work = copy_initial(cid)
for rel in sorted(p for p in work.rglob('*') if p.is_file()):
    run(['nl','-ba',str(rel.relative_to(work))], work, trace)
write(croot(cid) / 'output.md', '''# Proposed-fix review

## Needed

- The focused `amount < 0` guard in `calc.py:1-2` is the direct change required by `README.md:1`.
- Meaningful negative coverage belongs with the existing fee tests at `tests/test_calc.py:1-5` in this fixture.

## Not needed for this requirement

- `ValidationFactory`: no variant selection or construction boundary exists in `calc.py`; this is unneeded abstraction.
- Plugin registry: no plugin contract or multiple validators exist in the supplied repository.
- `tests/duplicate_test_calc.py`: duplicates the suitable existing test home and adds no distinct scenario.
- Reformatting every module: unrelated to the guard and would obscure the focused diff.

These are scope findings grounded in every supplied file, not requests for cosmetic work. A new test file is acceptable when repository instructions require one or no suitable test home exists; the concern here is duplication despite an existing suitable home.

## Confidence & unverified

Confidence: 99% — the complete supplied repository and proposal were read.

1% uncertainty — the proposal names abstractions without implementations, so runtime defects within them cannot be evaluated.
'''); save_trace(cid, trace)

# 11 authorization-cadence
cid = 'authorization-cadence'; trace = []; work = copy_initial(cid)
for rel in ['request.md','findings.md']: run(['nl','-ba',rel], work, trace)
draft = '''# Search filter analysis

Mode: integration. Work name: search-filter.

## Overview
The request adds name filtering to an existing list while preserving its data source (`request.md:1`). The supplied fixture has no application source, so entry points, caller closure, and similar code remain unverified.

## Scope boundaries
In scope: the existing list's input/filter/display path. Preserved contract: existing data source. Open decisions: case matching and debounce behavior (`findings.md:2-3`).

## Confidence & unverified
Confidence: 72% — requirement intent is clear but the implementation repository is absent.
28% uncertainty — exact entry points, consumers, tests, and conventions need the application source; this blocks a 90% analysis gate.
'''
for variant in ['A-file-request','B-inline-request']:
    v = croot(cid) / 'variants' / variant
    write(v / 'search-filter_analysis.md', draft)
write(croot(cid) / 'variants/C-missing-retention/output.md', '''Status: pending clarification.

Blocking question: Which records or data must be retained, for how long, and which deletion exceptions apply? This rule changes the scope and risk map, so it is not inferred.
''')
write(croot(cid) / 'variants/D-walkthrough/findings.md', '''# Findings

## Walkthrough — 2026-09-07 (round 1)

1. Search matching case policy needs a decision — presented; user disposition pending.
2. Debounce duration needs a decision — inventoried; not yet presented.
''')
write(croot(cid) / 'variants/D-walkthrough/output.md', '''Item 1: Should name matching be case-sensitive or case-insensitive?

Recommendation: case-insensitive, confidence 80%, because users usually expect names to match regardless of capitalization. Decision is pending; only item 1 is presented this turn.
''')
write(croot(cid) / 'output.md', '''# Authorization and cadence result

- A and B took the same authorized local draft path: `search-filter_analysis.md`, with byte-identical content. No redundant permission request was made.
- Both drafts stop below the 90% analysis gate because application source is absent; this is a load-bearing evidence gap, not a permission gap.
- C stays pending on one precise retention-rule question and does not infer the rule.
- D inventories both findings on disk, presents only item 1, and leaves item 2 for a later turn after item 1 is dispositioned.

## Confidence & unverified

Confidence: 96% — cadence and equivalent request handling are directly represented in isolated variants.

4% uncertainty — no scripted user reply exists for the walkthrough or retention question, so dependent work remains pending.
'''); save_trace(cid, trace)

# 12 review-depth-severity
cid = 'review-depth-severity'; trace = []; work = copy_initial(cid)
for rel in sorted(p for p in work.rglob('*') if p.is_file()): run(['nl','-ba',str(rel.relative_to(work))], work, trace)
write(croot(cid) / 'output.md', '''# Review depth and severity

Native subagent workers are callable in this host. The parent dispatch explicitly prohibited further agents for this trial, so I retained the review lanes as independent sequential passes and record weaker independence.

## Small fee guard

One main-thread correctness/convention pass is proportionate. `calc.py:1-2`, `tests/test_calc.py:1-5`, `README.md:1`, and `.github/workflows/test.yml:1-6` bound a small isolated change. Finding: add the requested guard and negative/zero coverage in the existing test style; no unrelated refactor.

## Cross-service authorization change

Three non-overlapping passes were retained:

1. Trust-entry lane: inspect token issuer claims and support-role provenance. **Unavailable** because issuer source is absent.
2. Policy-consumer lane: enumerate every resource policy consumer and cross-tenant check. **Unavailable** beyond `auth.py:1-2` because consumer source is absent.
3. Layer lane: trace issuer → handler → claims → `allow()` → resource. The final comparison is verified at `auth.py:2`; preceding cross-service hops are **SUSPECTED**.

Important suspected finding (severity potentially critical, confidence 78%): allowing support users across tenants can bypass tenant isolation if issuer claims or downstream resource consumers do not constrain support scope. It stays visible despite missing runtime evidence. Next probe: enumerate issuer/handler/claims and every caller of `allow`, then execute an unauthorized cross-tenant request with a real support token and verify the resource decision plus audit event.

Parent re-grounding requirement: re-open each cited source and execute the bypass probe before upgrading the finding to VERIFIED or fixing anything. No refactor or implementation was started.

## Confidence & unverified

Confidence: 94% — scope/risk-based depth and all supplied files are grounded.

6% uncertainty — cross-service source and runtime environment are absent, so the severe issue cannot be confirmed or refuted.
'''); save_trace(cid, trace)

# 13 check-reuse
cid = 'check-reuse'; trace = []; work = copy_initial(cid)
# Materialize a fresh fee fixture as the recipe requests.
src_fee = croot('existing-test-home') / 'fixture-initial'
shutil.copytree(src_fee, work, dirs_exist_ok=True)
write(work / 'config.json', '{"mode":"test"}\n')
build = run(['python3','-m','compileall','calc.py'], work, trace, 'setup evidence')
unit = run(['python3','-m','unittest','discover','-s','tests'], work, trace, 'setup evidence')
identity = {
    'source': sha_file(work/'calc.py'), 'tests': sha_file(work/'tests/test_calc.py'),
    'config': sha_file(work/'config.json'), 'commands': sha_file(work/'commands.json'),
    'python': platform.python_version(), 'platform': platform.platform(),
    'build_exit': build.returncode, 'unit_exit': unit.returncode,
    'suite_scope': 'unittest discover -s tests (complete discovered suite)'}
write(croot(cid) / 'artifacts/prior-run-identity.json', json.dumps(identity, indent=2) + '\n')
write(croot(cid) / 'output.md', '''# Check reuse matrix

The initial build and complete discovered unit suite actually ran with exit 0. Their source, test, config, command, Python, platform, and suite-scope identities are recorded in `artifacts/prior-run-identity.json`.

| Independent state | Result | Reason |
|---|---|---|
| All identities match | **reusable pass** | executed, complete evidence and every recorded identity match |
| Source changed | **stale** | source identity invalidates build and unit evidence |
| Relevant config changed | **stale** | config identity invalidates affected evidence |
| Integration suite blocked | **blocked** | absence of an executable environment cannot become pass |
| Smaller subset exits 0 | **unverified for full suite** | a green subset proves only its recorded subset |
| Deliberate staging-only config difference | **pass for asymmetry check** | difference is documented and irrelevant to the required key; syntax alone does not fail it |
| Required production key absent | **fail** | production readiness requires the key and no deliberate irrelevance can satisfy it |
| Browser screenshot absent from fixture | **unavailable** | no actual screenshot/output exists to inspect; observable button AC remains unverified |
| Subjective wording preference | **pending human judgment** | even a screenshot could show the words, not approve their tone |

No build/unit rerun is needed in the exact-match row. Every mutation is evaluated from an independent identity set.

## Confidence & unverified

Confidence: 97% — matching evidence was executed and identity-bound; invalidation rules are explicit.

3% uncertainty — integration and browser evidence were not supplied, so those rows cannot become passes.
'''); save_trace(cid, trace)

# 14 intent-routing
cid = 'intent-routing'; trace = []; work = copy_initial(cid)
for rel in ['old_billing_tasks.md','old_incident.md']: run(['nl','-ba',rel], work, trace)
write(croot(cid) / 'output.md', '''# Independent routing results

| Variant | Route/result |
|---|---|
| A | **Recommend:** `analyze-work search` — confidence 96% — recommend-only feature mapping; do not execute. Old completed billing docs are unrelated. |
| B | **Recommend:** `implement-task search` — confidence 97% — the reviewed task and local authorization satisfy prerequisites, so implementation can continue when invoked. Triage itself does not execute. |
| C | **Recommend:** `analyze-work search` — confidence 95% — current new-feature intent outranks the unrelated incident's rejected review. |
| D | **Recommend:** `review-implementation <prefix>` — confidence 96% — content-hash staleness prevents advancement until a fresh review covers current bytes. |
| E | **Recommend:** `walkthrough-implementation` — confidence 99% — the user explicitly requested the implementation tour; the tour proceeds one dependency-ordered step per turn. |
| F | **Pause at deployment authorization** — confidence 99% — repository completion does not authorize deployment; keep deployment pending and request authority only at that boundary. |

An unrequested walkthrough may be offered near commit but is not automatically started. No route auto-deploys.

## Confidence & unverified

Confidence: 97% — each route follows current intent and stated artifact validity.

3% uncertainty — variants B, D, and F omit concrete prefix names, so argument placeholders remain unresolved.
'''); save_trace(cid, trace)

# 15 incident-causality
cid = 'incident-causality'; trace = []; work = copy_initial(cid)
for rel in ['source.py','race.py','incident.log']: run(['nl','-ba',rel], work, trace)
repro = run(['python3','-c','from source import fee; print(repr(fee(-1)))'], work, trace)
synthetic = '''SYNTHETIC CAUSAL RUNTIME TRANSCRIPT — fixture evidence, not live-system truth
request_id=req-42
input=idempotency_key:key-7, operation:apply
config=IDEMPOTENCY_MODE=check-then-write
build=fixture-build-c
2026-09-06T10:00:00.100Z worker-1 checked key-7 absent
2026-09-06T10:00:00.101Z worker-2 checked key-7 absent
2026-09-06T10:00:00.110Z worker-1 applied key-7
2026-09-06T10:00:00.111Z worker-2 applied key-7
competing timeout-only hypothesis refuted: both apply events completed before timeout
'''
write(croot(cid) / 'artifacts/variant-c-synthetic-runtime.txt', synthetic)
write(croot(cid) / 'output.md', f'''# Incident causality variants

Effective fixture policy: active P1 uses streamlined confidence threshold **70**; normal non-P1 threshold is 90. No deployment is authorized.

## A — source/config suggestion only

`race.py:1-3` contains a check-then-write race candidate, but `incident.log:1-2` has no key trace or evidence that this branch executed. Root-cause hop: **ASSUMED**. Status: candidate cause, confidence 48%, below the P1 threshold. No fix is proposed. Confirm/refute with a correlated per-key trace capturing request id, exact key, build/config identity, both branch decisions, and write outcomes during the incident window; include a known duplicate positive control.

Reversible mitigation proposal, not executed: pause automated retries for the affected operation; monitor duplicate applications and request-loss/latency; rollback by restoring retries if loss or latency breaches the incident baseline. This limits exposure without claiming remediation.

## B — deterministic local defect

Executed `source.fee(-1)` returned `{repro.stdout.strip()}` (trace exit {repro.returncode}). Expected contract forbids negative fees, so the local divergence at `source.py:1-2` is **VERIFIED** (Data Validation), confidence 98%. Minimal local fix: reject negative input at this function and add negative/zero/positive tests. This proves a fixture defect, not that the defect caused the production P1.

## C — supplied synthetic causal runtime

`artifacts/variant-c-synthetic-runtime.txt` is explicitly synthetic. Within that fixture it binds request `req-42`, key `key-7`, config, build, two absent checks, and two completed applies, while refuting the timeout-only hypothesis. The check-then-write race is a bounded **VERIFIED fixture cause**, confidence 75%, which clears the authorized P1 threshold 70. It does not establish live-system truth.

Streamlined artifact-review lane: root cause + proposed fix only, gate 70. Review result: Approved with notes at 75% for the synthetic fixture. Minimal remediation design remains separate: make check-and-apply atomic at `race.py:2-3`, with a concurrency reproduction. Reversible mitigation: serialize the affected key path behind a flag; monitor duplicates, throughput, and latency; rollback the flag if latency exceeds the stated incident threshold. Neither action was deployed.

## Confidence & unverified

Confidence: 96% — A preserves uncertainty, B is executed, and C's synthetic provenance plus threshold are explicit.

4% uncertainty — no live production traces, deployment state, impact population, or mitigation thresholds were supplied; live cause and remediation remain unverified.
'''); save_trace(cid, trace)

# Extra analyzer prompts, fresh initial fixtures, exact prompts already stored.
e1 = ROOT / 'extras/01-existing-test-home-analyze'; trace = []
work = e1 / 'fixture-initial'
for rel in sorted(p for p in work.rglob('*') if p.is_file()): run(['nl','-ba',str(rel.relative_to(work))], work, trace)
run(['rg','-n','fee\\(','-g','*.py','.'], work, trace)
write(e1 / 'artifacts/rejecting-negative-amounts_analysis.md', '''# Rejecting negative amounts — reference map

Mode: integration. Work name: rejecting-negative-amounts.

## Overview
The behavior boundary is `calc.py:1-2`. `README.md:1` supplies the negative-input contract while preserving the current scalar fee calculation.

## Entry points and consumers
- `calc.py:1`: `fee` is the only production entry point in the supplied fixture.
- `tests/test_calc.py:2,5`: the only enumerated consumer is the unittest import/call; repository-wide `rg -n 'fee\\(' -g '*.py' .` found these two files.

## Patterns and test home
`tests/test_calc.py:1-5` establishes unittest style and is the suitable existing home under `AGENTS.md:1`. `README.md:1` and `.github/workflows/test.yml:1-6` identify the complete test command.

## Scope and risks
Expected change surface: `calc.py` plus `tests/test_calc.py`. Zero and positive values are preserved-contract scenarios. No API, database, or external dependency appears in the supplied fixture.

## Confidence & unverified
Confidence: 97% — every supplied file and every `fee` consumer was inspected.
3% uncertainty — non-numeric inputs and external callers outside this isolated fixture are not specified.
''')
write(e1 / 'output.md', '''Produced `artifacts/rejecting-negative-amounts_analysis.md` from the fresh initial fixture. It is a reference map with entry points, patterns, consumer provenance, scope, and risks; it contains no implementation recipe.

Confidence: 97%. Unverified: callers outside the isolated fixture and unspecified non-numeric behavior.
''')
lines = ['# Available tool trace','']
for i,row in enumerate(trace,1): lines += [f'## {i}', f'Command: `{row["command"]}`', f'Exit: {row["exit_code"]}', '```text', row['output'].rstrip(), '```','']
write(e1/'tool-trace.md','\n'.join(lines))

e2 = ROOT / 'extras/02-consumer-closure-analyze'; trace = []; work = e2 / 'fixture-initial'
for rel in sorted(p for p in work.rglob('*') if p.is_file()): run(['nl','-ba',str(rel.relative_to(work))], work, trace)
run(['rg','-n','fetch\\(|from client import fetch','-g','*.py','.'], work, trace)
write(e2 / 'artifacts/fetch-return-contract_analysis.md', '''# Fetch return-contract change — reference map

Mode: integration. Work name: fetch-return-contract.

## Overview
`client.py:1-2` owns the provider return contract. The proposed plan names the API, while repository-wide caller closure finds a second unchanged executable consumer.

## Entry points and consumer closure
- Provider: `client.py:1-2` returns the current scalar.
- API consumer: `api.py:1-3` applies addition to the return.
- Worker consumer: `worker.py:1-3` applies multiplication to the return.
- Contract test: `test_worker.py:1-3` pins the worker result.

The recorded probe is `rg -n 'fetch\\(|from client import fetch' -g '*.py' .`; all hits were read directly.

## Scope and risks
The likely change surface includes the provider and both arithmetic consumers, plus their tests. The main risk is an unchanged consumer receiving a widened shape. The concrete result representation and error-handling behavior are design decisions for the next phase.

## Confidence & unverified
Confidence: 98% — the entire small fixture and all literal consumers were inspected.
2% uncertainty — no concrete widened type or API test file is supplied, so those remain open inputs.
''')
write(e2 / 'output.md', '''Produced `artifacts/fetch-return-contract_analysis.md` from the fresh initial fixture. It maps the provider, both unchanged consumers, and the existing worker test without specifying an implementation recipe.

Confidence: 98%. Unverified: concrete widened type and absent API test location.
''')
lines = ['# Available tool trace','']
for i,row in enumerate(trace,1): lines += [f'## {i}', f'Command: `{row["command"]}`', f'Exit: {row["exit_code"]}', '```text', row['output'].rstrip(), '```','']
write(e2/'tool-trace.md','\n'.join(lines))

print('execution complete')
