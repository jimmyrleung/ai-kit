#!/usr/bin/env python3
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/tmp/astra-backlog-5VdqNm/trials/engineering/current/2')
CORPUS = Path('<user-home>/ai-kit/tests/skill-outcomes/cases.json')
SNAPSHOT = Path('/tmp/astra-backlog-5VdqNm/evaluation-source-snapshots/current')
BASE = 'aeec06bfa0a6b97402b17824d957f29635f40ba7'
ORDER = [
    'dirty-review', 'unborn-short-history', 'review-invalidation',
    'task-reverification', 'consumer-closure', 'completion-resources',
    'existing-test-home', 'convention-new-test', 'no-suitable-test-home',
    'unneeded-helper', 'authorization-cadence', 'review-depth-severity',
    'check-reuse', 'intent-routing', 'incident-causality'
]
EXTRAS = [
    ('existing-test-home', 'Analyze rejecting negative amounts; produce a reference map, no implementation recipe'),
    ('consumer-closure', 'Analyze the fetch return-contract change; produce a reference map, no implementation recipe.'),
]

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def write(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, str):
        data = data.encode('utf-8')
    path.write_bytes(data)

corpus_bytes = CORPUS.read_bytes()
data = json.loads(corpus_bytes)
cases = {c['id']: c for c in data['cases']}
started = datetime.now(timezone.utc).isoformat()

manifest = {
    'schema_version': 1,
    'condition': 'current',
    'repeat': 2,
    'reviewed_base': BASE,
    'source_kind': 'supplied snapshot',
    'corpus': {'path': str(CORPUS), 'sha256': sha(corpus_bytes)},
    'skills': {},
}

all_skills = sorted({s for cid in ORDER for s in cases[cid]['skills']} | {'analyze-work'})
for skill in all_skills:
    src = SNAPSHOT / 'skills' / skill / 'SKILL.md'
    dest = ROOT / 'inputs' / 'skill-bodies' / skill / 'SKILL.md'
    if src.exists():
        b = src.read_bytes()
        write(dest, b)
        manifest['skills'][skill] = {
            'source': str(src), 'captured': str(dest.relative_to(ROOT)),
            'sha256': sha(b), 'bytes': len(b), 'availability': 'available'
        }
    else:
        manifest['skills'][skill] = {
            'source': str(src), 'availability': 'unavailable',
            'reason': 'missing from supplied current snapshot'
        }

run_cases = []
for index, cid in enumerate(ORDER, start=1):
    case = cases[cid]
    case_root = ROOT / 'cases' / f'{index:02d}-{cid}'
    write(case_root / 'inputs' / 'prompt.md', case['prompt'])
    write(case_root / 'inputs' / 'case.json', json.dumps(case, indent=2, ensure_ascii=False) + '\n')
    for rel, body in case.get('files', {}).items():
        write(case_root / 'fixture-initial' / rel, body)
    fixture_hashes = []
    for rel, body in sorted(case.get('files', {}).items()):
        b = body.encode('utf-8')
        fixture_hashes.append({'path': rel, 'sha256': sha(b), 'bytes': len(b)})
    write(case_root / 'inputs' / 'fixture-manifest.json', json.dumps(fixture_hashes, indent=2) + '\n')
    write(case_root / 'output.md', '# Trial output\n\nStatus: pending.\n')
    run_cases.append({
        'case_id': cid, 'order': index, 'status': 'pending',
        'prompt_path': str((case_root / 'inputs' / 'prompt.md').relative_to(ROOT)),
        'skills': case['skills'], 'mandatory_checks': [
            {'criterion': c, 'status': 'pending', 'locator': None} for c in case['mandatory_checks']
        ]
    })

for sequence, (fixture_case, prompt) in enumerate(EXTRAS, start=1):
    eroot = ROOT / 'extras' / f'{sequence:02d}-{fixture_case}-analyze'
    write(eroot / 'inputs' / 'prompt.md', prompt)
    source_fixture = ROOT / 'cases' / f'{ORDER.index(fixture_case)+1:02d}-{fixture_case}' / 'fixture-initial'
    shutil.copytree(source_fixture, eroot / 'fixture-initial', dirs_exist_ok=True)
    write(eroot / 'output.md', '# Trial output\n\nStatus: pending.\n')

write(ROOT / 'inputs' / 'source-manifest.json', json.dumps(manifest, indent=2) + '\n')
run = {
    'schema_version': 1,
    'run_id': 'engineering-current-repeat-2',
    'batch_id': 'engineering-current-shared-context',
    'condition': 'current',
    'repeat': 2,
    'execution_kind': 'supplied-body-procedure',
    'status': 'in_progress',
    'provider': 'OpenAI',
    'host_version': 'unavailable',
    'model': 'gpt-5.6-sol (requested; effective value unavailable)',
    'reasoning': 'high (requested; effective value unavailable)',
    'settings_origin': 'parent dispatch request; effective host settings not exposed',
    'tool_capabilities': ['exec_command', 'apply_patch'],
    'source_manifest': 'inputs/source-manifest.json',
    'trace_path': 'tool-trace.md',
    'trace_unavailable_reason': 'Only manually preserved command/output summaries are available; full host transcript is unavailable.',
    'case_order': ORDER,
    'shared_context_disclosure': 'All cases ran in one declared-order batch. Fresh fixtures isolate filesystem state, but case-level context independence is weaker because the same worker context was reused.',
    'extra_prompts': [
        {'order_after_case': fixture_case, 'prompt': prompt, 'status': 'pending'}
        for fixture_case, prompt in EXTRAS
    ],
    'cases': run_cases,
    'failures': [],
    'unavailable': ['native skill discovery/invocation', 'full host transcript', 'token usage', 'monetary cost', 'effective model/settings identity'],
    'measurements': {
        'started_at': started, 'finished_at': None, 'elapsed_seconds': None,
        'unnecessary_interruptions': 0, 'required_clarifications': 0,
        'requested_discussion_turns': 0, 'retries': 0,
        'artifact_bytes': None, 'total_output_bytes': None,
        'tokens': None, 'cost': None,
        'unavailable_reason': 'Token/cost/full-transcript accounting is not exposed by this host.'
    },
    'review': {'agent_reviewer': 'self-grade pending', 'parent_grounding': 'pending', 'human_owner': 'pending'}
}
write(ROOT / 'run.json', json.dumps(run, indent=2) + '\n')
report = f'''# Engineering supplied-body trial — current repeat 2

- Status: in progress
- Reviewed source base: `{BASE}`
- Execution: supplied-body procedure, not native discovery
- Batch: shared context in declared order; fresh filesystem fixtures, weaker case-level context independence
- Started: {started}
- Provider accounting: tokens, cost, full transcript, effective model and effective reasoning settings unavailable

## Cases

''' + '\n'.join(f'{i}. `{cid}` — pending' for i, cid in enumerate(ORDER, 1)) + '''

## Extra predeclared analysis prompts

1. `existing-test-home` — pending
2. `consumer-closure` — pending

## Confidence & unverified

Confidence: pending until source-grounded execution and grading finish.

Unverified: native discovery, full host transcript, effective provider settings, token usage, cost, and human owner review.
'''
write(ROOT / 'report.md', report)
write(ROOT / 'tool-trace.md', '# Available tool trace\n\nInitial corpus and supplied bodies loaded from the recorded source manifest. Full host transcript is unavailable.\n')
print(ROOT)
