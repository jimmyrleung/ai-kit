#!/usr/bin/env python3
import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path('/tmp/astra-backlog-5VdqNm/trials/engineering/current/2')
def copy_variants(case_dir,names):
    src=case_dir/'fixture-initial'
    for name in names:
        shutil.copytree(src,case_dir/'variants'/name/'fixture-initial',dirs_exist_ok=True)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

copy_variants(ROOT/'cases/11-authorization-cadence',['A-file-request','B-inline-request','C-missing-retention','D-walkthrough'])
copy_variants(ROOT/'cases/12-review-depth-severity',['small-fee','cross-service-authorization'])
copy_variants(ROOT/'cases/14-intent-routing',['A','B','C','D','E','F'])
copy_variants(ROOT/'cases/15-incident-causality',['A','B','C'])

# Re-run the deterministic probe from variant B's isolated fixture and preserve exact output.
b=ROOT/'cases/15-incident-causality/variants/B/fixture-initial'
started=datetime.now(timezone.utc).isoformat()
p=subprocess.run(['python3','-c','from source import fee; print(repr(fee(-1)))'],cwd=b,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
trace=ROOT/'cases/15-incident-causality/tool-trace.md'
with trace.open('a',encoding='utf-8') as f:
    f.write(f'''\n## Independent variant-B reproduction\n\n- Started: {started}\n- CWD: `{b}`\n- Command: `['python3', '-c', 'from source import fee; print(repr(fee(-1)))']`\n- Exit: {p.returncode}\n\n```text\n{p.stdout.rstrip()}\n```\n''')

# Copy C's synthetic evidence into its isolated variant with unchanged bytes.
src=ROOT/'cases/15-incident-causality/artifacts/variant-c-synthetic-runtime.txt'
dst=ROOT/'cases/15-incident-causality/variants/C/fixture-initial/supplied-synthetic-runtime.txt'
dst.write_bytes(src.read_bytes())

# Refresh input hash inventory while preserving the already-proven prompt checks.
im=ROOT/'inputs/input-manifest.json'
data=json.loads(im.read_text(encoding='utf-8'))
rows=[]
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and ('inputs' in path.parts or 'fixture-initial' in path.parts):
        rows.append({'path':str(path.relative_to(ROOT)),'sha256':sha(path),'bytes':path.stat().st_size})
data['files']=rows
im.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

# Refresh the stable case/extra output manifest after the added trace.
files=[]; artifact_bytes=0; total_output_bytes=0
for path in sorted(ROOT.rglob('*')):
    if not path.is_file() or '.git' in path.parts or '__pycache__' in path.parts: continue
    rel=path.relative_to(ROOT)
    if rel.parts[0] not in ('cases','extras'): continue
    is_artifact='artifacts' in rel.parts
    if path.name not in ('output.md','tool-trace.md') and not is_artifact: continue
    n=path.stat().st_size; total_output_bytes+=n
    if is_artifact: artifact_bytes+=n
    files.append({'path':str(rel),'sha256':sha(path),'bytes':n})
om={'definition':{
 'artifact_bytes':'sum of files below case/extra artifacts directories',
 'total_output_bytes':'sum of case/extra output.md, tool-trace.md, and artifacts files; excludes fixtures, inputs, scripts, and root bookkeeping'},
 'files':files,'artifact_bytes':artifact_bytes,'total_output_bytes':total_output_bytes}
(ROOT/'output-manifest.json').write_text(json.dumps(om,indent=2)+'\n',encoding='utf-8')
run=json.loads((ROOT/'run.json').read_text(encoding='utf-8'))
run['measurements']['artifact_bytes']=artifact_bytes
run['measurements']['total_output_bytes']=total_output_bytes
for c in run['cases']:
    prefix=f'cases/{c["order"]:02d}-{c["case_id"]}/'
    c['artifacts']=[row for row in files if row['path'].startswith(prefix)]
run['isolation_evidence']='Multi-variant cases have separate fixture-initial directories; executable incident variant B was rerun from its own fixture. Filesystem isolation does not remove shared model-context effects.'
(ROOT/'run.json').write_text(json.dumps(run,indent=2)+'\n',encoding='utf-8')
report=(ROOT/'report.md').read_text(encoding='utf-8')
import re
report=re.sub(r'Measurements: \d+ artifact bytes; \d+ total output bytes',f'Measurements: {artifact_bytes} artifact bytes; {total_output_bytes} total output bytes',report)
(ROOT/'report.md').write_text(report,encoding='utf-8')
print(json.dumps({'variant_fixtures':15,'incident_b_exit':p.returncode,'artifact_bytes':artifact_bytes,'total_output_bytes':total_output_bytes}))
