# Available tool trace

Initial corpus and supplied bodies loaded from the recorded source manifest. Full host transcript is unavailable.

## Reviewed-base verification

- `analyze-work` snapshot `8ffb8b0efcf8e22e401f0d03583d1ca7dad67919cfb4773c97c1e3dde9f16237`; base `8ffb8b0efcf8e22e401f0d03583d1ca7dad67919cfb4773c97c1e3dde9f16237`; match=true
- `bug-investigation` snapshot `18a77578203eb89c9f3c6a4c5425baf09df240706e882508a08c3d29eedee7e9`; base `18a77578203eb89c9f3c6a4c5425baf09df240706e882508a08c3d29eedee7e9`; match=true
- `implement-task` snapshot `8edcf0a8c9a628b2fd6e75290b689b14c7c3857eb6c46d2ae8d67a66181c8e16`; base `8edcf0a8c9a628b2fd6e75290b689b14c7c3857eb6c46d2ae8d67a66181c8e16`; match=true
- `qa-gates` snapshot `286e85607c8fcd98c97cce5819093146b84d6d30cfe7809568361aa2894646fc`; base `286e85607c8fcd98c97cce5819093146b84d6d30cfe7809568361aa2894646fc`; match=true
- `review-artifact` snapshot `d27b6991e835f8cce9e2ddc33fb2cbfe2413428784b2259550a3e30666d56198`; base `d27b6991e835f8cce9e2ddc33fb2cbfe2413428784b2259550a3e30666d56198`; match=true
- `review-implementation` snapshot `15a670f26ec9000d23483761838e7f40975f216b4ea704038210d813a0efca95`; base `15a670f26ec9000d23483761838e7f40975f216b4ea704038210d813a0efca95`; match=true
- `tasks-breakdown` snapshot `39e1a812b0efc46913888e3ef44905605a42ffabc2a1dcb57339f40fb529ad1e`; base `39e1a812b0efc46913888e3ef44905605a42ffabc2a1dcb57339f40fb529ad1e`; match=true
- `triage` snapshot `d791cbb7219bc1a6e9cb4e4553815f9003459dd70ce282225a7762d34dfc051c`; base `d791cbb7219bc1a6e9cb4e4553815f9003459dd70ce282225a7762d34dfc051c`; match=true
- `verify-task` snapshot `101c14a935ace2cadcc741fc95174d352460e7b0e473a8fa1cdbc97f5574e595`; base `101c14a935ace2cadcc741fc95174d352460e7b0e473a8fa1cdbc97f5574e595`; match=true
- `walkthrough` snapshot `69f7d47832aaa76a25ab36fb8dec494f4d9aac40883f6bbd1d31064e3afe9b06`; base `69f7d47832aaa76a25ab36fb8dec494f4d9aac40883f6bbd1d31064e3afe9b06`; match=true
- `walkthrough-implementation` snapshot `debc39c4950394022850c9519eb32043e9cf8542eb0f7ef25d5f470409ffb2ae`; base `debc39c4950394022850c9519eb32043e9cf8542eb0f7ef25d5f470409ffb2ae`; match=true

## Prompt byte verification

- `dirty-review` exact=true sha256=`271d4c90f54a308d86fd2624c1d1247c04959c292b98f1c65f196aa590bebe44`
- `unborn-short-history` exact=true sha256=`d5eb7bb9165d5d19ac6e6dd22a7b3bd2c4de6958a33521b754dddf4b78bd57ca`
- `review-invalidation` exact=true sha256=`843f13ff207df33f5f17caa5b035140476e7d4180b40b4016be1dbd15af7f625`
- `task-reverification` exact=true sha256=`550ed5449f0fc334e339a512aabbd4af4caa791a73ceb9f79a8497116adc3bbf`
- `consumer-closure` exact=true sha256=`d346286197c95c7b3f8eb3e1ad3350a84bb2761a66a136d0ab956bae60cf9598`
- `completion-resources` exact=true sha256=`773a78972cffbe46cd7e7ffe1ff2f9737bc49b48b826f5c127281f8a8d799618`
- `existing-test-home` exact=true sha256=`0851f04370df4b4e1af4f40740efc10a7d6f070248e82e7c8cbad9fb5cbd19fa`
- `convention-new-test` exact=true sha256=`0851f04370df4b4e1af4f40740efc10a7d6f070248e82e7c8cbad9fb5cbd19fa`
- `no-suitable-test-home` exact=true sha256=`0851f04370df4b4e1af4f40740efc10a7d6f070248e82e7c8cbad9fb5cbd19fa`
- `unneeded-helper` exact=true sha256=`73b16d41a80ca31161c8482999292575428074a8049c7fc15deeb336e51679e4`
- `authorization-cadence` exact=true sha256=`0f7900bf70a14fea30f5230773f4fe45d58d1cc5554c8eff5afb3514921bf2b6`
- `review-depth-severity` exact=true sha256=`25a490d0d22423efca55e16841cd80d91ac30ac3a909e1ccc37f1edd900d50a2`
- `check-reuse` exact=true sha256=`cdbd70ecdc42c84412a025045fcf41c7dad295963660f85c4bce0e803f02d043`
- `intent-routing` exact=true sha256=`d6fded7b40c285bf60e2ead1ac40188d3d58bf9c5d3c7fdf8b9bf6eb058c58e6`
- `incident-causality` exact=true sha256=`d1a371160d21f4f256f1ebe317c0bf03332d10ded58fad18ce113d9d5998598a`
- `extra-1` exact=true sha256=`4dedba26e739c90e458a5bdcec3261fc9ebedfdded4bc264f1f34332f4a2c39a`
- `extra-2` exact=true sha256=`d5026800276160e751a6e64468a40b9b07f14d3fa6ac32acc65e6dcf7e2b27c1`

Full host transcript remains unavailable.
