#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

ROOT=Path('/tmp/astra-backlog-5VdqNm/trials/engineering/current/2')
ORDER=['dirty-review','unborn-short-history','review-invalidation','task-reverification','consumer-closure','completion-resources','existing-test-home','convention-new-test','no-suitable-test-home','unneeded-helper','authorization-cadence','review-depth-severity','check-reuse','intent-routing','incident-causality']
def write(p,s): Path(p).write_text(s,encoding='utf-8')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

run=json.loads((ROOT/'run.json').read_text(encoding='utf-8'))
byid={c['case_id']:c for c in run['cases']}

# Correct aggregate arithmetic and strengthen locators that were too broad.
repl={
 ('review-invalidation',0):'cases/03-review-invalidation/output.md:7; artifacts/git-variant-identities.json:4',
 ('review-invalidation',1):'cases/03-review-invalidation/output.md:8',
 ('task-reverification',2):'cases/04-task-reverification/artifacts/tasks-preserved.md:10; artifacts/tasks-preserved.md:16',
 ('consumer-closure',0):'cases/05-consumer-closure/tool-trace.md:7; tool-trace.md:11',
 ('completion-resources',0):'cases/06-completion-resources/artifacts/task-graph.md:20',
 ('completion-resources',1):'cases/06-completion-resources/artifacts/task-graph.md:8',
 ('completion-resources',2):'cases/06-completion-resources/artifacts/task-graph.md:20',
 ('completion-resources',3):'cases/06-completion-resources/artifacts/task-graph.md:18',
 ('completion-resources',4):'cases/06-completion-resources/artifacts/task-graph.md:18',
 ('completion-resources',5):'cases/06-completion-resources/artifacts/task-graph.md:22',
 ('existing-test-home',1):'cases/07-existing-test-home/tool-trace.md:7; tool-trace.md:24; tool-trace.md:35; tool-trace.md:46; tool-trace.md:58',
 ('existing-test-home',2):'cases/07-existing-test-home/tool-trace.md:58',
 ('existing-test-home',3):'cases/07-existing-test-home/tool-trace.md:84; tool-trace.md:93; tool-trace.md:95',
 ('convention-new-test',1):'cases/08-convention-new-test/tool-trace.md:7; tool-trace.md:24; tool-trace.md:35; tool-trace.md:46; tool-trace.md:58',
 ('convention-new-test',2):'cases/08-convention-new-test/tool-trace.md:58',
 ('convention-new-test',3):'cases/08-convention-new-test/tool-trace.md:84; tool-trace.md:94; tool-trace.md:96',
 ('no-suitable-test-home',1):'cases/09-no-suitable-test-home/tool-trace.md:7; tool-trace.md:24; tool-trace.md:35; tool-trace.md:46; tool-trace.md:58',
 ('no-suitable-test-home',2):'cases/09-no-suitable-test-home/tool-trace.md:58',
 ('no-suitable-test-home',3):'cases/09-no-suitable-test-home/tool-trace.md:83; tool-trace.md:93; tool-trace.md:95',
 ('check-reuse',0):'cases/13-check-reuse/artifacts/variant-identities.json:3; tool-trace.md:41; tool-trace.md:48',
 ('check-reuse',1):'cases/13-check-reuse/artifacts/variant-identities.json:26; artifacts/variant-identities.json:35',
 ('check-reuse',2):'cases/13-check-reuse/output.md:10; output.md:11; tool-trace.md:53',
}
for (cid,i),value in repl.items(): byid[cid]['mandatory_checks'][i]['locator']=value

run['measurements']['required_clarifications']=1
run['measurements']['requested_discussion_turns']=1

# Recompute a stable manifest over case/extra outputs only. Root bookkeeping is excluded.
files=[]; artifact_bytes=0; total_output_bytes=0
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or '.git' in p.parts or '__pycache__' in p.parts: continue
    rel=p.relative_to(ROOT)
    if rel.parts[0] not in ('cases','extras'): continue
    is_artifact='artifacts' in rel.parts
    is_output=p.name in ('output.md','tool-trace.md') or is_artifact
    if not is_output: continue
    n=p.stat().st_size; total_output_bytes += n
    if is_artifact: artifact_bytes += n
    files.append({'path':str(rel),'sha256':sha(p),'bytes':n})
manifest={'definition':{
 'artifact_bytes':'sum of files below case/extra artifacts directories',
 'total_output_bytes':'sum of case/extra output.md, tool-trace.md, and artifacts files; excludes fixtures, inputs, scripts, and root bookkeeping'},
 'files':files,'artifact_bytes':artifact_bytes,'total_output_bytes':total_output_bytes}
write(ROOT/'output-manifest.json',json.dumps(manifest,indent=2)+'\n')

for c in run['cases']:
    prefix=f'cases/{c["order"]:02d}-{c["case_id"]}/'
    c['artifacts']=[row for row in files if row['path'].startswith(prefix)]
run['measurements']['artifact_bytes']=artifact_bytes
run['measurements']['total_output_bytes']=total_output_bytes
run['measurements']['unavailable_reason']='Token, cost, full transcript, and effective model/settings accounting are not exposed. Byte counts are direct file-byte measurements over UTF-8 text outputs, not a savings claim.'
write(ROOT/'run.json',json.dumps(run,indent=2)+'\n')

report=(ROOT/'report.md').read_text(encoding='utf-8')
report=report.replace('Mandatory grades: 78 pass, 0 fail, 1 unavailable','Mandatory grades: 77 pass, 0 fail, 1 unavailable')
import re
report=re.sub(r'Measurements: \d+ artifact bytes; \d+ total output bytes',f'Measurements: {artifact_bytes} artifact bytes; {total_output_bytes} total output bytes',report)
write(ROOT/'report.md',report)
print(json.dumps({'pass':77,'fail':0,'unavailable':1,'artifact_bytes':artifact_bytes,'total_output_bytes':total_output_bytes}))
