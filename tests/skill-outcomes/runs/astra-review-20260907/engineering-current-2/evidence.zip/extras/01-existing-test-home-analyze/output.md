Produced `artifacts/rejecting-negative-amounts_analysis.md` from the fresh initial fixture. It is a reference map with entry points, patterns, consumer provenance, scope, and risks; it contains no implementation recipe.

Confidence: 97%. Unverified: callers outside the isolated fixture and unspecified non-numeric behavior.
