# Rejecting negative amounts — reference map

Mode: integration. Work name: rejecting-negative-amounts.

## Overview
The behavior boundary is `calc.py:1-2`. `README.md:1` supplies the negative-input contract while preserving the current scalar fee calculation.

## Entry points and consumers
- `calc.py:1`: `fee` is the only production entry point in the supplied fixture.
- `tests/test_calc.py:2,5`: the only enumerated consumer is the unittest import/call; repository-wide `rg -n 'fee\(' -g '*.py' .` found these two files.

## Patterns and test home
`tests/test_calc.py:1-5` establishes unittest style and is the suitable existing home under `AGENTS.md:1`. `README.md:1` and `.github/workflows/test.yml:1-6` identify the complete test command.

## Scope and risks
Expected change surface: `calc.py` plus `tests/test_calc.py`. Zero and positive values are preserved-contract scenarios. No API, database, or external dependency appears in the supplied fixture.

## Confidence & unverified
Confidence: 97% — every supplied file and every `fee` consumer was inspected.
3% uncertainty — non-numeric inputs and external callers outside this isolated fixture are not specified.
