# Fetch return-contract change — reference map

Mode: integration. Work name: fetch-return-contract.

## Overview
`client.py:1-2` owns the provider return contract. The proposed plan names the API, while repository-wide caller closure finds a second unchanged executable consumer.

## Entry points and consumer closure
- Provider: `client.py:1-2` returns the current scalar.
- API consumer: `api.py:1-3` applies addition to the return.
- Worker consumer: `worker.py:1-3` applies multiplication to the return.
- Contract test: `test_worker.py:1-3` pins the worker result.

The recorded probe is `rg -n 'fetch\(|from client import fetch' -g '*.py' .`; all hits were read directly.

## Scope and risks
The likely change surface includes the provider and both arithmetic consumers, plus their tests. The main risk is an unchanged consumer receiving a widened shape. The concrete result representation and error-handling behavior are design decisions for the next phase.

## Confidence & unverified
Confidence: 98% — the entire small fixture and all literal consumers were inspected.
2% uncertainty — no concrete widened type or API test file is supplied, so those remain open inputs.
