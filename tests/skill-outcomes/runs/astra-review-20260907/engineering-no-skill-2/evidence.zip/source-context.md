# Source and context trace

- Corpus source read: `<user-home>/ai-kit/tests/skill-outcomes/cases.json`.
- Selected only these exact IDs, in corpus order: `existing-test-home`, `convention-new-test`, `no-suitable-test-home`.
- No candidate/current condition output or other trial result was read.
- No ai-kit skill body was read or supplied. The host-provided skill catalog metadata was unavoidably visible in the worker context.
- The optional `/tmp/astra-backlog-5VdqNm/final-validation-plan.json` was not needed and was not read.
- Execution mode: direct coding assistance in one shared-context batch, fresh worker for repetition 2.
- Each case prompt was executed once. The common literal prompt is preserved separately for each case as `prompt.txt` (237 UTF-8 bytes, SHA-256 `0851f04370df4b4e1af4f40740efc10a7d6f070248e82e7c8cbad9fb5cbd19fa`, no trailing newline).

## Per-case source reads before editing

1. `existing-test-home`: `fixture/AGENTS.md`, `fixture/README.md`, `fixture/calc.py`, `fixture/tests/test_calc.py`, `fixture/.github/workflows/test.yml`.
2. `convention-new-test`: `fixture/AGENTS.md`, `fixture/README.md`, `fixture/calc.py`, `fixture/tests/test_calc.py`, `fixture/.github/workflows/test.yml`.
3. `no-suitable-test-home`: `fixture/AGENTS.md`, `fixture/README.md`, `fixture/calc.py`, `fixture/tests/test_label.py`, `fixture/.github/workflows/test.yml`.

All listed files were read in full before task edits. Changed and newly created source files were read in full after editing.
