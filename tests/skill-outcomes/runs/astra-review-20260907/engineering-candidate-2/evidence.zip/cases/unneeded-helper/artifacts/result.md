# Proposed fix review

Verdict: Needs revision.

- Accept the focused `amount < 0` guard in `calc.py:1-2`; it directly implements the documented negative-input contract in `README.md:1`.
- Extend the meaningful existing home `tests/test_calc.py:1-5` with negative, zero, and positive cases.
- Reject `ValidationFactory` and the plugin registry. No extension point or multiple validation strategies appear in the supplied code, so these are speculative abstractions.
- Reject `tests/duplicate_test_calc.py`. A suitable fee test module already exists; duplicating it adds no behavior coverage.
- Reject reformatting every module. It is unrelated to the requested behavior and would widen review scope.

This result does not establish a rule against new files. A new test file remains correct when repository convention requires it or no suitable existing home exists.

## Confidence & unverified

Confidence: 98%. Every supplied source, test, doc, CI file, and proposal line was inspected. The 2% uncertainty is that no external repository files beyond the fixture were available.
