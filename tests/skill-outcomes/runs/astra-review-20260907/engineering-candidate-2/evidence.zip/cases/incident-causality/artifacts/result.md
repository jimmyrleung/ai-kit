# Incident causality variants

## Effective policy carried through review

Active P1; streamlined one-pass depth; confidence threshold 70; causal runtime evidence required for a confirmed incident cause; authorized boundary is diagnosis and review only. No deployment is authorized. The same policy applies to investigation and artifact review.

## A — source/config suggestion only

Status: candidate hypothesis, not confirmed cause. SOURCE at `race.py:1-3` shows a check-then-write branch that could race. OBSERVED `incident.log:1-2` shows only a timeout and explicitly lacks key/branch execution. It does not link the branch to this incident.

Precise next probe: for the incident window and affected request/key, collect a complete request trace from ingress through both `apply` invocations, including build/config identity, key encoding, branch-entered markers, before/after store values, and write timestamps. Confirmation requires overlapping requests both entering the absent-key branch and producing duplicate application; a trace showing one entry or an atomic store rejection refutes it.

Confidence: 46%. Source proves a mechanism, while causal execution evidence is missing; this is below the effective 70 threshold.

## B — deterministic local defect

OBSERVED: executing `source.fee(-1)` on this fixture returned `-0.02` with exit 0. The expected contract forbids a negative fee. This confirms a local Data Validation defect at `source.py:1-2`.

Minimal local fix: reject negative input at `source.py:1-2` and add negative/zero/positive tests. Falsifier: a reproduction on the same source/build that raises the required error or otherwise satisfies the documented negative-input contract.

This does not prove that the local defect caused any production incident because no production linkage is supplied.

Confidence: 99% for the local defect; 0% for production causality from this evidence alone.

## C — supplied synthetic causal runtime evidence

The clearly labeled synthetic transcript binds request IDs, input key, config, build, both branch entries, and the observed duplicate. It also refutes the competing timeout-only explanation. Under the supplied trial evidence, the race is a confirmed diagnosis at 75%, which exceeds the explicit P1 threshold of 70. This establishes procedure behavior and policy propagation; it is not claimed as live-system truth.

Confirmed remediation proposal: replace the check-then-write at `race.py:1-3` with one atomic insert-if-absent operation, then verify concurrent same-key requests produce one application. No code or deployment was performed.

Reversible mitigation proposal, separate from remediation: temporarily serialize or pause duplicate-key request processing. Rollback: restore normal concurrency after the atomic fix is verified. Monitor duplicate-application count, request latency, and queue depth. Mitigation success would not itself prove the diagnosis.

Artifact-review verdict under the carried policy: Approved with notes for the synthetic trial diagnosis; live deployment remains unauthorized.

## Confidence & unverified

Confidence: 95% that the three variants obey evidence and policy boundaries. The 5% uncertainty is that C’s evidence is synthetic by fixture design and cannot verify live state.
