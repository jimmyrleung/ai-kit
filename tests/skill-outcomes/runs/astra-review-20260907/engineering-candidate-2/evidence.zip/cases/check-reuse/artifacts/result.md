# Check evidence reuse matrix

Initial run `check-reuse-baseline-001` executed the complete build and unit commands with exit 0: Python 3.14.7 on Linux x86_64; 3/3 unit tests passed. It binds source `b1a20a26…d33`, test `b93ba243…698`, config `94ef8657…3b2`, and commands `6f803ff1…6fa`.

| Variant | Verdict | Reason |
|---|---|---|
| Exact matching source/config/environment/commands/suite | reusable | Complete executed evidence and all recorded identities match; cite original run without claiming a new run. |
| Source changed | stale | Affected build/unit evidence must rerun against the new source bytes. |
| Config changed | stale where consumed | Config identity mismatch invalidates checks whose behavior consumes it. |
| Blocked integration suite | BLOCKED | An unexecuted required tier cannot become PASS. |
| Smaller successful subset | subset pass only | The executed 1/1 focused test does not establish the full 3-test suite. |
| Deliberate staging-only optional-region difference | documented, not failed by syntax | The difference is irrelevant only after tracing that the changed contract does not consume it; no magic comment format is required. |
| Required prod key missing | FAIL | `REQUIRED_KEY` is absent, so the required production configuration is incomplete. |
| Browser screenshot | unavailable | No actual browser output was supplied. An actual current-build screenshot could prove button visibility; it could not prove subjective wording approval. |

## Confidence & unverified

Confidence: 97%. Initial and subset commands were executed and identities recorded. The 3% uncertainty is the deliberately unavailable integration and browser evidence; neither is promoted to PASS.
