# Findings

1. Search matching case policy needs a decision.
2. Debounce duration needs a decision.

## Walkthrough — 2026-09-07 (round 1)

- Item 1 — Search matching case policy: open.
- Item 2 — Debounce duration: queued; not presented yet.

## Current item: 1

Should matching be case-insensitive?

Recommendation: case-insensitive matching, confidence 85%, because users typically expect name search to ignore capitalization. Remaining uncertainty: no product convention or locale rule is supplied.

This artifact stops after item 1 to preserve the requested one-item-per-turn cadence.
