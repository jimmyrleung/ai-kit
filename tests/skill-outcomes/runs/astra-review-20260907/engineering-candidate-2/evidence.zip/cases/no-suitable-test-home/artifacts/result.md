# Negative-amount validation result

Implemented the focused guard in `calc.py`. AGENTS.md says no existing module covers fee; tests/test_label.py is unrelated, so a focused tests/test_calc.py is justified.

Executed `python3 -m unittest discover -s tests -v`: 4/4 tests passed, covering negative input raising `ValueError`, zero returning 0, and positive input returning 2. Executed `python3 -m compileall -q calc.py tests`: exit 0.

No helper, abstraction, cleanup, broad refactor, or commit was added.

## Confidence & unverified

Confidence: 99%. Repository instructions, code, tests, README, and CI were read before editing, and the exact CI test command passed. The remaining 1% is human review of naming/style.
