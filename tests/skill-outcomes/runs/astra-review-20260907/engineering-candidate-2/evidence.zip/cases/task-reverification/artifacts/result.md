# Task verification scope and handoff

## Heading task, run 1

<!-- evidence:begin verify-task1-r1 -->
- record_id: verify-task1-r1
- scope_kind: task
- task_id: Task 1
- task_locator: `tasks.md:2-9`
- ac_source: `tasks.md:6-7`
- acceptance_criteria: [`AC-1: returns 2`]
- declared_files: [`value.py`]
- Gate 1: unavailable — no executable implementation or actual supplied runner-result bytes exist in the fixture.
- Gate 2: pending Gate 1; AC set remains AC-1 only.
- Gate 3: no pinned budget/config/version in supplied inputs.
<!-- evidence:end verify-task1-r1 -->

## Heading task, run 2

<!-- evidence:begin verify-task1-r2 -->
- record_id: verify-task1-r2
- supersedes: verify-task1-r1
- scope_kind: task
- task_id: Task 1
- task_locator: `tasks.md:2-9`
- ac_source: `tasks.md:6-7`
- acceptance_criteria: [`AC-1: returns 2`]
- declared_files: [`value.py`]
- Gate 1: unavailable — no execution evidence supplied.
- Gate 2: pending Gate 1.
- Gate 3: no pinned budget/config/version in supplied inputs.
<!-- evidence:end verify-task1-r2 -->

The test checkbox at `tasks.md:5`, old generated AC #9 at lines 8-9, and Task 2 AC at lines 10-12 are excluded.

## Numbered task

- task_id: Task 1
- task_locator: `numbered.md:2-4`, ending before peer item 2
- ac_source: `numbered.md:3-4`
- acceptance_criteria: [`AC-1: returns 2`]

## Tasks-doc-less fix

- task_id: BUG-1
- task_locator: `investigation.md:1-5`
- proposed_fix_locator: `investigation.md:4-5`
- ac_source: `investigation.md:2-3` plus `fix-techspec.md:2-4`
- deduplicated acceptance_criteria: [`returns 2`, `negative input raises ValueError`]
- source locators retained: expected behavior at `investigation.md:2-3`; AC-F1/AC-F2 at `fix-techspec.md:3-4`.

A composed QA call receives `scope_kind=task` and this exact bundle. A later prefix QA call must derive the broader prefix scope separately.

## Confidence & unverified

Confidence: 97%. Section boundaries were directly inspected. The 3% uncertainty is the unavailable runner evidence, which keeps execution gates pending.
