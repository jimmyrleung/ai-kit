# Tasks
### Task 1
Files: value.py
#### Testing requirements
- [ ] Existing test green
#### Acceptance criteria
- [ ] AC-1: returns 2
#### Verify — old run
- [x] AC #9 old generated evidence
#### Verify — candidate run 1
<!-- evidence:begin verify-task1-r1 -->
- task_id: Task 1
- task_locator: tasks.md:2 through before Task 2
- ac_source: Task 1 > Acceptance criteria
- acceptance_criteria: [AC-1: returns 2]
- [ ] Gate 1 — unavailable: no executable implementation or supplied runner-result bytes
- [ ] Gate 2 — pending Gate 1
- [x] Gate 3 — no pinned cross-cutting invariant in supplied inputs
<!-- evidence:end verify-task1-r1 -->
#### Verify — candidate run 2
<!-- evidence:begin verify-task1-r2 -->
- task_id: Task 1
- task_locator: tasks.md:2 through before Task 2
- ac_source: Task 1 > Acceptance criteria
- acceptance_criteria: [AC-1: returns 2]
- supersedes: verify-task1-r1
- [ ] Gate 1 — unavailable: no executable implementation or supplied runner-result bytes
- [ ] Gate 2 — pending Gate 1
- [x] Gate 3 — no pinned cross-cutting invariant in supplied inputs
<!-- evidence:end verify-task1-r2 -->
### Task 2
#### Acceptance criteria
- [ ] AC-2: returns 3
