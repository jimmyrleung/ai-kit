# Evidence reuse assessment

Baseline approved Task A record binds `source.py` SHA-256 `9c86f318…c8f9` and exact Task A section SHA-256 `34a3ca7f…2a30`.

| Independent mutation | Result | Reason |
|---|---|---|
| same-HEAD dirty source edit | stale | Actual source hash is `9e09c649…cf3f`; unchanged HEAD cannot preserve byte-bound review. |
| edited reviewed AC | stale | Task A section hash changed to `c3a15559…fb8`. |
| Task B requested | stale for requested scope | Record names only Task A; it cannot cover Task B. |
| rejected verdict | stale / cannot advance | A Rejected verdict is never reusable approval even with matching bytes. |
| evidence-only append in exact delimiters | reusable | Subject/dependency bytes still match; exact evidence regions are excluded by the recorded rule. The appended pending record does not become approval itself. |
| unrelated file edit | reusable for Task A | `unrelated.txt` is outside recorded scope and dependencies; Task A identities match. |
| missing identities | unverified | The record omits source/dependency identities, so equality cannot be established. |

Every mutation came from a fresh baseline copy, not cumulative state.

## Confidence & unverified

Confidence: 99%. Actual hashes and record fields were inspected for every row. The remaining 1% is final owner review of scope relevance.
