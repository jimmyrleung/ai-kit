# Task-plan review: fetch return contract

Verdict: Needs revision.

Repository-wide search found two direct consumers: `api.py:3` adds 1 and unchanged `worker.py:3` multiplies by 2. Returning `Result(value, error)` breaks both numeric contracts. The omitted worker path is concrete: a runtime probe substituted a tuple-like Result and `worker.run()` returned `(4, None, 4, None)` instead of 8, causing the assertion to fail.

The owning return-contract task must include:

- `client.py`: change the producer contract.
- `api.py`: unwrap/handle Result according to the reviewed design and test the API.
- `worker.py`: update the unchanged-line consumer to unwrap/handle Result.
- `test_worker.py`: update the existing worker contract test and cover success/error variants.

The plan’s citation to `client.py` and `api.py` is not coverage of the unchanged consumer. Completion remains blocked until consumer and existing-test ownership are explicit.

## Confidence & unverified

Confidence: 99%. Repo-wide search, source reads, and an executable consumer probe support the gap. The remaining 1% is that the final Result implementation details are intentionally unspecified.
