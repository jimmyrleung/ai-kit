# Smallest executable task graph

| ID | Work | Boundary | Depends on | Resource/write set | Status | Potentially parallel | Ready now |
|---|---|---|---|---|---|---|---|
| I1 | Implement code slice 1 + tests | pre-merge | — | shared.py | Not Started | R1, R2 | yes |
| I2 | Implement code slice 2 + tests | pre-merge | I1 | shared.py | Not Started | R1, R2 | no |
| M1 | Scratch migration validation 1 | pre-merge | — | scratch DB | Not Started | R1, R2 | yes |
| M2 | Scratch migration validation 2 | pre-merge | M1 | same scratch DB | Not Started | R1, R2 | no |
| R1 | Read-only inspection 1 | pre-merge | — | read-only | Not Started | I1, M1, R2 | yes |
| R2 | Read-only inspection 2 | pre-merge | — | read-only | Not Started | I1, M1, R1 | yes |
| R3 | Read-only inspection of finished code | pre-merge | I2 | read-only | Not Started | M1/M2 when ready | no |
| GO | Repository review + QA | pre-merge | I2, M2, R3 | repository evidence | Not Started | — | no |
| D1 | Deploy | deploy | GO | deployment target | Not Started | — | no |
| L1 | Live rehearsal | live | D1 | deployed state | Not Started | — | no |

Edges: `I1 → I2 → R3 → GO → D1 → L1` and `M1 → M2 → GO`; `R1 → GO`, `R2 → GO`. Review/QA does not wait on D1 or L1, so the graph is acyclic. Shared-file tasks are serialized, and same-database migrations are serialized because no isolation/reconciliation plan was supplied. The two independent reads can overlap. R3 is potentially compatible with unrelated work after I2, but is not ready now because I2 is unfinished.

Each operation retains its own status and evidence producer: repository checks for I1/I2/GO, scratch DB results for M1/M2, deployment result for D1, and live rehearsal result for L1. Repository GO does not complete deployment or rehearsal.

Repository-only variant: omit D1 and L1; `GO` is the normal terminal task after all pre-merge dependencies.

## Confidence & unverified

Confidence: 96%. Dependencies follow the supplied outcome and resource conflicts. The 4% uncertainty is that task internals and actual resource isolation capabilities were not supplied.
