# Task A implementation review

Record ID: engineering-candidate-r2-dirty-review
Verdict: Approved with notes; current Task A content is fully inspected. No commit was made by the review.

## Scope

- Repository: this isolated fixture
- Base: `fixture-base` = `5ff1b755e4f14d5bd1ddd681f037191249e52a80`
- Task: Task A from `tasks.md`
- Intended paths: `calc.py`, `old.md -> new.md`, `fresh.txt`
- Excluded: `unrelated.txt` belongs to Task B and its earlier change is before the supplied base. `tasks.md` is the supplied scope definition, not implementation content.

## Layer coverage

- Committed, base to HEAD: `calc.py` adds the negative guard.
- Staged, HEAD to index: `calc.py` adds rounding; rename `old.md -> new.md` is recorded as R100.
- Unstaged, index to worktree: `calc.py` adds the worktree-only refinement comment.
- Untracked: `fresh.txt` was enumerated and read.
- Each transition is treated once. No cumulative diff is counted as another layer.

## Current-byte manifest

| Path | State | SHA-256 |
|---|---|---|
| calc.py | current worktree | ca3e9ead8a5ea9f3b826002fe776a47d89c86de126d4413bf1cfeac63b8a9ecf |
| new.md | staged/current | 7c85c33a763a8710f5a4f6deb04bf507904733cae9b88f59180fbe87e3a9fa7c |
| fresh.txt | untracked/current | ba576081dc1e16341bc085b399a28af3d45d0c4d2833a508892f5600ecf7dc62 |
| tasks.md | scope dependency | 00c5ee5256e4817f2d6807844fb4535bb42d90901e6e4f2809d21867f710dc52 |

Repository SHA and dirty state are context only. Reuse requires recomputing these scoped bytes and dependencies.

## Confidence & unverified

Confidence: 98%. The exact four layers, task boundary, rename mapping, and current bytes were inspected. The remaining 2% is human judgment over whether the worktree-only comment is intended Task A content.
