def fee(amount):
    if amount < 0:
        raise ValueError("negative amount")
    amount = round(amount, 2)
    # Worktree-only Task A refinement.
    return amount * 0.02
