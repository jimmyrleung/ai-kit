# Independent intent routes

| Variant | Route | Execution boundary |
|---|---|---|
| A | `analyze-work` recommendation for the new search box | Recommendation only. Do not execute. Old completed billing docs are unrelated and do not hijack current intent. |
| B | `implement-task` when the reviewed search task’s content-bound approval and dependencies are current | Local work is explicitly authorized, so it may continue without a second permission question once those prerequisites validate. The fixture supplies no search task bytes or valid approval record, so no implementation is claimed here. |
| C | `analyze-work` for the new search request | The unrelated incident file and its Rejected heading do not control this new work. |
| D | `review-artifact` or the named corrective producer for the stale reviewed task | Stale content identity cannot advance to implementation. |
| E | `walkthrough-implementation` | The user explicitly requested the tour. An unrequested tour would only be offered. |
| F | Report repository completion and pending deployment | Do not deploy: deployment has no authorization. Repository GO is not live-state evidence. |

No conditional route above is represented as executed work.

## Confidence & unverified

Confidence: 97%. Current-intent and evidence-state rules determine all routes. The 3% uncertainty is the absent underlying search artifacts in B and D, which prevents validating or executing them.
