# Task 1 scope verification

## Unborn repository

- HEAD: absent.
- Explicit base: empty tree `4b825dc642cb6eb9a060e54bf8d69288fbee4904`, computed with an empty input stream.
- Staged snapshot: `value.py` returns 1; `tasks.md` is also staged as fixture input.
- Additional unstaged snapshot: `value.py` returns 2.
- Current `value.py` SHA-256: `d3fe37235936f63ebabd6ba2bb8d3cf67404555d856dc63b0611fe9b6231ec13`.

## Single-commit repository

- HEAD: `d82f513cfbbe9f7790ae857d9cd099640a48e0d6`; commit count is 1.
- Scope was compared directly with HEAD. No `HEAD~N` or parent window was used.
- Staged snapshot changes `value.py` from 0 to 1.
- Additional unstaged snapshot changes `value.py` from 1 to 2.
- Current `value.py` SHA-256 matches the unborn variant.

Task AC source is `tasks.md:4`: AC-1, `value() returns 2`.

## Confidence & unverified

Confidence: 99%. Both independent histories and both dirty layers were inspected. The remaining 1% is owner review of the synthetic staging recipe.
