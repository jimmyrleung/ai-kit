# Fetch return-contract analysis

Mode: integration.

## Overview and scope

The requested change affects the return contract of `fetch`. This map identifies producer, consumers, and existing tests without specifying the Result design or an implementation sequence.

## Entry points and consumer ledger

Search command: `rg -n 'fetch|run\(' .`

| Consumer | Current contract |
|---|---|
| `api.py:1-3` | Imports `fetch`; adds 1 to its numeric return. |
| `worker.py:1-3` | Imports `fetch`; multiplies its numeric return by 2. |
| `test_worker.py:1-3` | Pins `worker.run() == 8`. |

Producer: `client.py:1-2` returns integer 4. The unchanged `worker.py` consumer is load-bearing even though `plan.md:1-2` omits it.

## Execution flow

- API path: `client.fetch` → `api.request` numeric addition.
- Worker path: `client.fetch` → `worker.run` numeric multiplication → `test_worker.test_run` expected value.

## Similar features and reusable patterns

No existing Result type or error-handling pattern is present in the supplied fixture. Its final shape and handling policy remain a design-phase decision.

## Impact and risks

Changing the producer return shape can break both arithmetic consumers. The existing worker test is the suitable test home for that path. API tests are not present in the fixture, so their home is unverified.

## Essential files

Potentially affected: `client.py`, `api.py`, `worker.py`, `test_worker.py`. `plan.md` is an input whose coverage claim is incomplete.

## Confidence & unverified

Confidence: 98%. Every direct consumer in the supplied fixture was enumerated and read. The 2% uncertainty is the absence of a defined Result contract and API test convention. No implementation recipe is included.
