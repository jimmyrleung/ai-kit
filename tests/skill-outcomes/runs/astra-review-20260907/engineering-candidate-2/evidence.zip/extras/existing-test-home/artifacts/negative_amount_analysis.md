# Negative amount validation analysis

Mode: integration.

## Overview and scope

The requested change is bounded to rejecting negative values in `fee`, preserving zero and positive behavior, and mapping the existing test home. This is a reference map; it does not prescribe implementation steps.

## Entry point and execution flow

- `calc.py:1-2`: `fee(amount)` is the production entry point and currently multiplies every input by 0.02.
- `tests/test_calc.py:1-5`: the existing `FeeTests` suite imports `fee` and pins positive behavior.
- `README.md:1`: documents both the unittest command and the negative-input requirement.
- `.github/workflows/test.yml:1-7`: CI runs the same unittest discovery command.
- `AGENTS.md:1`: explicitly requires extending suitable existing test files.

Flow: caller input → `fee` → numeric return. There are no other consumers in the supplied fixture search.

## Existing pattern and test home

The suitable test home is `tests/test_calc.py`, using `unittest.TestCase`. A new test module is not justified by the supplied convention.

## Impact and risks

The observable contract spans negative, zero, and positive inputs. The main risk is changing valid boundary behavior while adding rejection. No external callers or type constraints are present in the fixture, so repository-wide consumer closure is limited to the supplied root.

## Essential files

- Modify candidate: `calc.py`
- Existing test home: `tests/test_calc.py`
- Verification sources: `README.md`, `.github/workflows/test.yml`, `AGENTS.md`

## Confidence & unverified

Confidence: 96%. All fixture sources, tests, docs, CI, and instructions were inspected. The 4% uncertainty is the bounded fixture’s lack of external callers. No implementation recipe or code change is included.
