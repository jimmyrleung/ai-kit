# Feedback, memory, and ownership records

This contract defines optional, portable recording for skills that produce observations,
improvement work, memory, learning records, or decision records. The workflow result must not
depend on an undeclared private store.

## Recorder, store, and schema are separate

- A **recorder** decides whether to emit a record and owns deduplication for one composed
  execution. Nested skills return candidate signals to that recorder; they do not write a second
  copy.
- A **store** maps record kinds to paths and provides append/read access. It does not define what
  fields mean.
- This document owns the **schema and lifecycle semantics**. A store-local README may add tags or
  presentation rules, but it may not silently change required fields or make optional recording
  mandatory.

Resolve recording in this order: explicit task/session configuration, applicable repository or
user instructions, then a detected compatible store profile. If none resolves, recording is
`disabled`; continue the main workflow and report that no feedback record was written. If a caller
declares recording to be an enabled acceptance gate, a missing/unwritable store or failed validation
is `unavailable`/`failed`, never PASS.

The established `~/.claude` layout is a supported profile, including its observations,
improvements, project memory, ownership, and learning locations. It is not a prerequisite for
Claude, Codex, Cursor, or another host. Do not migrate an existing store automatically.

An optional fresh-user bootstrap may, with authorization, create a chosen root with
`observations/`, `improvements/`, `memory/`, `ownership/`, and `learning/` directories plus a small
manifest that records `profile`, `schema_version`, and the path for each enabled record kind. A
caller may also configure only the kinds it needs. Bootstrap changes storage only; it does not add
private facts, infer old records, or enable invocation telemetry.

## Common record envelope

Every new recorder entry emitted through this feedback system carries these fields, whether
represented as Markdown fields, frontmatter, or a machine-readable sidecar:

- `schema_version`, `record_id`, `recorded_at` (ISO 8601 with offset), and `record_kind`;
- `execution_id`, an opaque identifier for the actual session, task run, or standalone invocation;
- `producer` and `recorder`, where `recorder` is the one owner for the composed execution;
- a public-safe project/repository identity and optional `task_id`;
- `source_record_ids` and `evidence_identity` when the record is derived from artifacts;
- validation state: `passed`, `failed`, or `unavailable`, with a reason for the latter two.

Record IDs are stable across copies. A backup or synchronized copy with the same `record_id` is a
replica, not new evidence. For legacy records without IDs, deduplicate by normalized content hash
plus source locator and label the result as legacy-derived.

Use the scoped content and dependency identities in [change-evidence.md](change-evidence.md) for
`evidence_identity`. A repository SHA, timestamp, pathname, or dirty flag alone is not a content
identity.

## Observation records are selective evidence

One observation represents one supported finding, not a skill invocation. New observation records
use the common envelope and:

- `skill_or_workflow`, `phase_area`, and `outcome` (`success`, `mostly`, `partial`, or `failed`);
- `evidence_kind` (`lived` or `artifact-reconstructed`);
- `friction_observed`, exactly one store-approved `tag`, `would_have_helped`, and `principle`;
- optional `improvement_suggestion`.

Artifact-reconstructed observations require a current `evidence_identity` and precise source
locators. Lived observations may use the session execution identity without inventing an artifact
hash. The recorder validates all enabled records before it writes a completion receipt.

Within one composed execution, nested verification and QA return observation candidates to the
calling recorder. Standalone verification or QA may be its own recorder. Deduplicate candidates by
`execution_id` plus the finding's evidence identity and subject; several distinct observations from
one execution remain several observations and never become several invocation events.

Invocation telemetry is a separate optional record kind. Each measured invocation needs its own
stable `invocation_id`, `execution_id`, skill, provider/host, start/end time, and measured outcome.
Deduplicate it by `invocation_id`. Observation counts, absent observation files, transcript counts,
and backup copies must not be presented as invocation counts or evidence of non-use. When no
instrumented source exists, report invocation coverage as `unavailable`.

## Tags

The portable baseline is `wrong_approach`, `buggy_code`, `misunderstood_request`, `scope_creep`,
`over_design`, `read_skipped`, `rm_violation`, `line_budget_overrun`, `async_context_loss`,
`sdk_version_drift`, `doc_drift`, and `positive_evidence`. A configured store may extend this list
under an explicit maintenance rule. Use exactly one listed tag at the end of each
**friction_observed** field; validate a configured store's compatible local syntax and extensions.
A local tag list cannot remove the portable baseline or override the one-tag requirement.
Reserve inline-code tokens in this Tags section for approved tag names: the existing validator
extracts that set from this section.

## Improvement queue and discovery watermark

The discovery watermark says which source records were scanned; it does not resolve them. Keep an
append-only queue (or equivalent indexed ledger) with stable `item_id`, source observation IDs,
current disposition (`open`, `deferred`, `actioned`, or `declined`), proposal/packet locator, and
prediction state (`open`, `met`, `missed`, or `no-evidence`). Later disposition events supersede
earlier ones without erasing them.

Every review reads both newly discovered observations and all open/deferred queue items and
predictions. A run with zero new observations still processes that queue. Before creating an item,
match its source IDs and target/finding identity so repeating a review does not duplicate it.

Retention must keep every open/deferred item, its evidence, and its packet reachable. Resolved
packets may remain in place or move to an archive with the queue locator updated. Do not discard a
dated packet merely because a newer window exists.

## Session close and harvest receipts

A close receipt is valid only for the execution boundary named by its `execution_id`. Prefer a host
session/run ID. Otherwise use a generated opaque ID kept in the live session; if the host exposes a
session start time, include it as supporting context. A same-day log entry or the current top entry
does not prove that it belongs to the current session.

Write a `started` marker with a unique `close_id` before persistence. Write the completion receipt
only after every enabled record validates and persists. An interrupted close resumes only when the
current execution can match that marker; otherwise preserve the incomplete entry and start a new
one. Repeating a completed close with no new work is a no-op. New work in the same execution appends
a new receipt with the same `execution_id` and a `supersedes` link to the previous receipt.

A tasks-run harvest uses the same rule with a unique `harvest_id`. Bind it to the canonical tasks
path/run identity and to a sorted content manifest of every consumed task, QA, review, runner-state,
and digest artifact. Store the receipt outside the hashed subject bytes, using the evidence markers
defined in [change-evidence.md](change-evidence.md). A legacy commit-only marker remains readable but
is unverified and cannot suppress a harvest after current artifact bytes change.

Write an observation receipt only after observation validation passes. If recording is disabled,
record that state in the close/harvest result and do not pretend an enabled observation gate passed.

## Memory, learning, and decision records

The common envelope applies to recorder entries, sidecars, or receipts for these kinds. It does not
force domain-native teaching artifacts, learning-format documents, memory notes, or ADR bodies into
one document template. Preserve an established domain format and attach the envelope in the least
disruptive compatible representation. Recorder entries still use explicit ownership:

- **Memory** records name their scope (`user`, `cross-repo`, or repository) and owner. Store a fact
  in one scope only; repository facts remain in repository documentation.
- **Learning** records name the topic/journey and distinguish learner-supplied claims from coach
  assessment or generated material.
- **Decision** records include `created_at`, provenance, lifecycle (`active`, `parked`, or
  `superseded`), review state (`unreviewed`, `partial`, or `owned`), separate rationale and
  consequences authorship states, and `supersedes`/`superseded_by` relationships. Missing dates in
  legacy decisions mean age `unknown`; do not infer age from file metadata. Human-supplied text
  remains human-supplied. Any assistant-drafted field stays visibly draft until a human confirms or
  rewrites it.

Superseding a decision creates a new record and preserves the historical record. Add only the
relationship/lifecycle update to the older record; never replace its original decision or rationale.
