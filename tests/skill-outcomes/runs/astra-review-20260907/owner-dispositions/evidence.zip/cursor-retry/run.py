"""Authorized one Cursor model attempt after user-reported trust-state change.
Only a pre-model workspace-trust failure can advance to the trusted-repo startup.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,time
R=Path(__file__).parent;W=R/'workspace';OLD=Path('/tmp/astra-backlog-5VdqNm/existing-provider-stores-20260907/cursor/workspace');REPO=Path('<user-home>/ai-kit')
sha=lambda b:hashlib.sha256(b).hexdigest();utc=lambda:datetime.now(timezone.utc).isoformat()
assert not (R/'attempts.json').exists()
W.mkdir(parents=True,exist_ok=True)
help_run=subprocess.run(['cursor-agent','--help'],capture_output=True,text=True)
(R/'help.txt').write_text(help_run.stdout)
version=subprocess.run(['cursor-agent','--version'],capture_output=True,text=True)
(R/'version.txt').write_text(version.stdout)
source_manifest=[]
for row in json.loads(Path('/tmp/astra-backlog-5VdqNm/existing-provider-stores-20260907/procedure-manifest.json').read_text()):
    source=Path(row['source']);data=source.read_bytes();target=W/'procedure'/row['relative'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    source_manifest.append({**row,'previous_sha256':row['sha256'],'sha256':sha(data),'unchanged_since_full_review':sha(data)==row['sha256'],'copy':str(target)})
assert all(x['unchanged_since_full_review'] for x in source_manifest),'changed procedure requires source reading before dependent claims'
(R/'procedure-manifest.json').write_text(json.dumps(source_manifest,indent=2)+'\n')
obs=W/'store/.claude/observations';obs.mkdir(parents=True,exist_ok=True)
seed=obs/'2026-09-06-existing.md';seed.write_text('# Existing disposable store record\n\nThis seeded legacy record contains no actual private historical content. Preserve its bytes.\n')
positive=obs/'2026-09-07-trust-retry.md';absent=obs/'intentionally-absent.md'
execution='b17-cursor-trust-retry-20260907'
profile={'profile':'claude-layout','schema_version':1,'root':str(W/'store/.claude'),'paths':{'observation':str(obs)},'recording':'enabled','acceptance_gate':True,'other_kinds':'disabled','execution_id':execution,'scope':'disposable Claude-layout emulation; not actual home/private content'}
(W/'store-profile.json').write_text(json.dumps(profile,indent=2)+'\n')
checker=W/'procedure/skills/close/scripts/check-observation-tags.mjs';contract=W/'procedure/docs/contracts/feedback.md'
argv=['node',str(checker),str(contract),str(absent)];p=subprocess.run(argv,capture_output=True,text=True)
event={'record_id':execution+'-preflight','record_kind':'verification','captured_at':utc(),'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'synthetic_fixture':True,'scope':'enabled required observation is actually absent'}
eventpath=W/'preflight-evidence.json';eventpath.write_text(json.dumps(event,indent=2)+'\n')
prompt=f'''User has updated Cursor workspace trust and authorizes this one bounded B17.AC3 retry. Perform only a minimal configured-store recording slice in {W}, an explicitly added writable root. The host and source repository are OS read-only. Do not edit the source repository, old fixture workspace, policy, config or credentials. Do not access actual private stores or auth/account details. No shell, MCP, delegation, installs, git mutations, external actions, approval requests, global close invocation or additional workflows. Do not use --force, --yolo or change trust. Explicit scratch configuration overrides any default/private store path in host instructions.

Read {W/'store-profile.json'}, {eventpath}, {contract}, and the observation/tag/receipt sections of {W/'procedure/skills/close/SKILL.md'}. Inspect the existing {seed} so its bytes remain unchanged. This is a disposable Claude-layout emulation with a seeded legacy record, not live private history.

Write exactly one observation at {positive}, reconstructing the actual supplied preflight evidence: a configured enabled required-record tag check given an absent input returned the recorded error/exit. Include common envelope and observation fields from the public feedback contract. Use execution_id={execution}, producer=cursor-native, recorder=b17-probe-recorder, project=disposable-provider-store, source_record_ids=[{event['record_id']}], evidence_identity=sha256:{sha(eventpath.read_bytes())}, evidence_kind=artifact-reconstructed, and a precise preflight locator. End friction_observed with exactly one canonical tag. Do not claim this is lived historical evidence or invocation telemetry.

Shell validation is intentionally deferred to the outer recorder; no shell tool or bypass is authorized. Set observation validation=unavailable with reason awaiting canonical tag validation by the outer recorder. The outer recorder will validate the actual file and keep an independent sidecar; do not claim that gate already passed. The separate enabled-required-record negative scenario must keep {absent} absent and enabled, with failed/unavailable result grounded in the actual preflight exit. Never label this negative gate passed, disable it, create its missing file, or issue a completion receipt.

Write {W/'result.json'} with execution_id, producer, observation path, positive validation state/reason, negative enabled=true and state/reason, prior_record_preserved, completion_receipt_issued=false, and model metadata only if actually available (otherwise unknown). Preserve tool denial/unavailable honestly and stop; no permission broadening or retries. End with one concise result. Memory, rules, SESSION_LOG and commits are outside this slice.
'''
(R/'stdin.txt').write_text(prompt)
policy={'permissions':{'allow':['Read('+str(W)+'/**)','Write('+str(positive)+')','Write('+str(W/'result.json')+')'],'deny':['Shell(*)','Read(/home/**)','Write(/home/**)','Write('+str(seed)+')','Write('+str(W/'procedure')+'/**)','Write('+str(W/'store-profile.json')+')']}}
(R/'scoped-cli.json').write_text(json.dumps(policy,indent=2)+'\n')
startfacts={'captured_at':utc(),'user_change':'User reports Cursor workspace now trusted; Claude subscription cancelled and remains pending with no attempts.','help_exit':help_run.returncode,'version_exit':version.returncode,'version':version.stdout.strip(),'seed_sha256':sha(seed.read_bytes()),'source_manifest':source_manifest,'prompt_sha256':sha(prompt.encode()),'prior_permissions_sha256':sha((OLD/'.cursor/cli.json').read_bytes()),'native_model_requested':'existing configured default; task worker requested gpt-6-astra/high separately; no model substitution claim','write_boundary':str(R)+' only; bwrap read-only root','max_model_attempts':1,'model_timeout_seconds':180}
(R/'inputs.json').write_text(json.dumps(startfacts,indent=2)+'\n')

def sanitize(s):
    s=re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}','[redacted-email]',s)
    return re.sub(r'(?i)("(?:account_id|accountId|user_id|userId|organization_id|organizationId|org_id|email)"\s*:\s*)"[^"]*"',r'\1"[redacted-identity]"',s)

attempts=[]
for number,root in enumerate([OLD,REPO],1):
    outdir=R/('startup-'+str(number));outdir.mkdir()
    native=['cursor-agent','--print','--output-format','stream-json','--sandbox','enabled','--workspace',str(root),'--add-dir',str(W),prompt]
    wrapper=['bwrap','--ro-bind','/','/','--bind',str(R),str(R),'--dev','/dev','--proc','/proc','--chdir',str(root),'--die-with-parent']
    if root==OLD:wrapper+=['--ro-bind',str(R/'scoped-cli.json'),str(OLD/'.cursor/cli.json')]
    argv=wrapper+native
    invocation={'argv':argv,'cwd':str(root),'stdin':'none; exact prompt is final argv element and stdin.txt','started_at':utc(),'timeout_seconds':180,'setup_number':number,'trust_flags_used':False,'native_policy':'read-only scratch-only permission overlay at original root' if root==OLD else 'existing trusted repository configuration unchanged; native sandbox plus outer OS write boundary; prompt forbids shell/private/external access','scope_note':'old fixture and repo read-only; only fresh retry scratch writable'}
    (outdir/'invocation.json').write_text(json.dumps(invocation,indent=2)+'\n')
    start=time.monotonic();process=subprocess.Popen(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    (outdir/'process.json').write_text(json.dumps({'pid':process.pid,'started_at':invocation['started_at']},indent=2)+'\n')
    timedout=False
    try:out,err=process.communicate(timeout=180)
    except subprocess.TimeoutExpired:
        timedout=True;process.terminate()
        try:out,err=process.communicate(timeout=10)
        except subprocess.TimeoutExpired:process.kill();out,err=process.communicate()
    out=sanitize(out);err=sanitize(err)
    (outdir/'stdout.jsonl').write_text(out);(outdir/'stderr.txt').write_text(err)
    model_evidence=any(token in out for token in ['"type":"assistant"','"type": "assistant"','"type":"tool_call"','"type": "tool_call"'])
    trustfailure=('Workspace Trust Required' in out+err or 'Failed to trust workspace' in out+err) and not model_evidence
    result={'startup':number,'workspace':str(root),'started_at':invocation['started_at'],'completed_at':utc(),'elapsed_seconds':round(time.monotonic()-start,3),'exit_code':process.returncode,'timed_out':timedout,'pre_model_trust_failure':trustfailure,'model_output_detected':model_evidence,'new_observation_exists':positive.exists(),'result_file_exists':(W/'result.json').exists()}
    (outdir/'run.json').write_text(json.dumps(result,indent=2)+'\n');attempts.append(result)
    (R/'attempts.json').write_text(json.dumps(attempts,indent=2)+'\n');print(json.dumps(result),flush=True)
    if not trustfailure:break
print('Bounded retry finished.',flush=True)
