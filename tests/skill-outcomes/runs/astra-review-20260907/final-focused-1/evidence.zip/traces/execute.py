from pathlib import Path
import json,hashlib,shutil,subprocess,time,datetime,re
R=Path('/tmp/astra-backlog-5VdqNm/trials/final-focused/1'); F=Path('/tmp/astra-backlog-5VdqNm/final-post-review-frozen'); E=json.loads((R/'inputs/final-regression-extensions.json').read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p,s):
 p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s)
def dump(p,x): write(p,json.dumps(x,indent=2)+'\n')
def snap(p): return {str(q.relative_to(p)):sha(q.read_bytes()) for q in sorted(p.rglob('*')) if q.is_file() and '.git' not in q.parts}
def cmd(args,cwd):
 t=time.monotonic(); x=subprocess.run(args,cwd=cwd,text=True,capture_output=True); record={'args':args,'cwd':str(cwd),'exit':x.returncode,'stdout':x.stdout,'stderr':x.stderr,'seconds':time.monotonic()-t};
 with (R/'traces/commands.jsonl').open('a') as out: out.write(json.dumps(record)+'\n')
 return x
def repo(p):
 for a in [['git','init','-q'],['git','add','.'],['git','-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-qm','fixture setup']]: assert cmd(a,p).returncode==0
 return cmd(['git','rev-parse','HEAD'],p).stdout.strip()
def finish(id,start,checks,details):
 d=R/'artifacts'/id; dump(d/'checks.json',checks); dump(d/'details.json',details)
 run=json.loads((R/'run.json').read_text()); run['cases'].append({'id':id,'seconds':time.monotonic()-start,'checks':checks,'artifact_bytes':sum(p.stat().st_size for p in d.rglob('*') if p.is_file() and '.git' not in p.parts)}); dump(R/'run.json',run)
def check(name,ok,loc): return {'check':name,'status':'pass' if ok else 'fail','evidence':loc}
def group1():
 t=time.monotonic(); id=E['cases'][0]['id']; d=R/'artifacts'/id; inp=R/'inputs'/id; shutil.copytree(Path(E['cases'][0]['fixture']),inp); dump(inp/'original-hashes.json',snap(inp)); write(d/'prompt.txt',E['cases'][0]['recipe']+'\n'+ '\n'.join(E['cases'][0]['checks']))
 outcomes=[]
 for mode in ['separate','colocated','all-workspaces']:
  src=d/mode/'source'; shutil.copytree(inp,src)
  for p,b in E['cases'][0]['files'].items(): write(src/p,b)
  before=snap(src); dump(d/mode/'initial-source-hashes.json',before); head=repo(src)
  for ws in ['next','dotnet-web','functions']:
   w=src/ws; slug={'next':'widgets-web','dotnet-web':'widgets-api','functions':'functions'}[ws]; source=src if mode=='all-workspaces' else w
   docs=(src/'docs'/slug) if mode=='colocated' else (d/mode/'docs'/slug)
   files=[p for p in sorted(w.rglob('*')) if p.is_file()]; readlog=[]
   for p in files: readlog.append({'path':str(p),'text':p.read_text(),'sha256':sha(p.read_bytes())})
   dump(d/mode/(ws+'-source-reads.json'),readlog)
   if ws=='next':
    entries=[('get-widgets-by-id','http:get:/api/widgets/[id]','src/app/(ops)/api/widgets/[id]/route.ts:GET','REST GET /api/widgets/[id]'),('post-widgets-by-id','http:post:/api/widgets/[id]','src/app/(ops)/api/widgets/[id]/route.ts:POST','REST POST /api/widgets/[id]'),('archive-widget','action:archiveWidget','src/app/actions.ts:archiveWidget','Server action archiveWidget'),('api-health','http:any:/api/_health','pages/api/_health.ts:handler','REST /api/_health'),('api-root','http:any:/api','pages/api/index.ts:handler','REST /api')]
    coverage='| Next App Router | Covered | app/**/route.*, src/app/**/route.* | const GET and sync POST inspected |\n| Next Pages API | Covered | pages/api/**, src/pages/api/**; next.config.mjs | default exports; default page extensions; root app/pages search empty where absent |\n| Next Server Actions | Partial | app/**, src/app/** | src/app/actions.ts:8 unresolved generatedAction re-export |\n'
   elif ws=='dotnet-web':
    entries=[('get-widgets-by-id','http:get:/api/widgets/{id}','Program.cs:5','REST GET /api/widgets/{id}')]; coverage='| ASP.NET minimal API | Partial | **/*.cs, *.csproj | Web SDK; literal /api + /widgets + /{id}; Program.cs:7 dynamic ROUTE_PREFIX unresolved |\n'
   else:
    entries=[('queue-ingest','queue:widget-inbox','Functions.cs:FixtureFunctions.QueueIngest','Queue widget-inbox'),('legacy-timer','timer:0 */5 * * * *:FixtureFunctions.LegacyTimer','Functions.cs:FixtureFunctions.LegacyTimer','Timer 0 */5 * * * *')]; coverage='| Azure Functions | Covered | **/*.cs, *.csproj | Function and FunctionName separate execution boundaries; literal queue and timer inspected |\n'
   entries.sort(); out='# Documentation Tasks — '+slug+'\n\n> Inventory Schema: v2\n\n## Handoff\n\n| Field | Value |\n|---|---|\n'+''.join('| '+k+' | `'+str(v)+'` |\n' for k,v in [('Source root',source),('Docs root',docs),('Workspace root',w)])+'\n## Tasks overview\n\n| # | Title | Trigger | Service | Status |\n|---|---|---|---|---|\n'
   out+=''.join(f'| {i} | Document {x[0]} | {x[3]} | {slug} | Todo |\n' for i,x in enumerate(entries,1)); tasks=[]
   for i,(name,wid,ref,trigger) in enumerate(entries,1):
    target=docs/'workflows'/slug/(name+'.md'); handoff={'Source root':str(source),'Docs root':str(docs),'Workspace root':str(w),'Reference':ref,'Resolved output':str(target),'Workflow ID':slug+':'+wid}; tasks.append(handoff)
    out+=f'\n## Task {i} — Document {name}\n\n**Status:** Todo\n**Workflow ID:** `{handoff["Workflow ID"]}`\n<!-- inventory:begin -->\n'+''.join(f'**{k}:** `{v}`\n' for k,v in handoff.items() if k!='Workflow ID')+f'**Files affected:** `workflows/{slug}/{name}.md`\n**Trigger:** {trigger}\n<!-- inventory:end -->\n\n**Acceptance criteria:**\n- A workflow doc exists exactly at Resolved output.\n- The doc follows Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies.\n- Backend mode.\n'+('- [TODO: verify entry point]\n' if 'action:' in wid else '')
   write(docs/'_docs-tasks.md',out); write(docs/'project-overview.md',f'# {slug} — Project Overview\n\n## Summary\n\nStatic fixture inventory: {len(entries)} execution boundaries (computed from emitted records).\n\n## Top-level layout\n\n'+ '\n'.join('- '+str(p.relative_to(w)) for p in files)+'\n\n## Build / Run\n\nNo scripts supplied in package manifest; .NET host defaults not executed.\n\n## Services\n\n'+slug+'\n\n## Scan coverage\n\n| Detector | State | Roots/patterns searched | Boundary |\n|---|---|---|---|\n'+coverage+'\n## Notes\n\nStatic inspection only; unresolved forms are not invented tasks.\n'); (docs/'workflows').mkdir(exist_ok=True)
   # Execute one emitted handoff, selecting a fully bounded handler.
   task=next(x for x in tasks if ('http:get:' in x['Workflow ID'] if ws!='functions' else 'queue:' in x['Workflow ID'])); dump(d/mode/(ws+'-executed-handoff.json'),task)
   tracefiles=files if ws!='next' else [w/'package.json',w/'next.config.mjs',w/'src/app/(ops)/api/widgets/[id]/route.ts']
   manifest=[{'source_id':'app','path':str(p.relative_to(source)),'role':'Entry point' if p.suffix in ['.ts','.cs'] else 'Registration/config','sha256':sha(p.read_bytes())} for p in tracefiles]; manifest.sort(key=lambda x:x['path']); digest=sha((''.join('app\t'+x['path']+'\t'+x['role']+'\t'+x['sha256']+'\n' for x in manifest)).encode())
   behavior={'next':('GET → GET → Response.json','Returns JSON {ok:true}; no input used, branches or persistence in this handler.','Output | JSON | {ok:true}'), 'dotnet-web':('GET → MapGet lambda → Results.Ok(id)','Literal groups compose /api/widgets/{id}; bound string id is returned using Results.Ok. Dynamic health registration is outside this route boundary.','Input/output | string id | Path parameter echoed'), 'functions':('Queue widget-inbox → FixtureFunctions.QueueIngest','Queue trigger binds body to string; method body is empty. No writes or outgoing calls are declared.','Input | string body | Queue message')}
   seq,flow,data=behavior[ws]; boundary=[str(p.relative_to(source)) for p in tracefiles]; target=Path(task['Resolved output'])
   doc=f'# {task["Workflow ID"]}\n\n## Summary\n\n| Field | Value |\n|---|---|\n| Schema | v2 |\n| Mode | Backend |\n| Created | 2026-09-07 |\n| Last Updated | 2026-09-07 |\n| Generated From | {head[:12]} |\n| Cross-Service | No |\n| Business Rules | No |\n| Complex Logic | No |\n\n## Sequence of Calls\n\n{seq}\n\n## Flow Description\n\n1. {flow}\n\n## Data Inventory\n\n### Request / Response\n\n| Direction | Type | Description |\n|---|---|---|\n| {data} |\n\n## Business Rules\n\nNo business rules declared in this bounded handler.\n\n## Configuration\n\nRegistration and project inputs listed in Source Files.\n\n## Dependencies\n\nFramework response/trigger primitives; no external service calls traced.\n\n## Source Evidence\n\n| Source ID | Repository/source identity | Full revision | Trace boundary | Relevant dirty paths | Manifest SHA-256 |\n|---|---|---|---|---|---|\n| app | {source} | {head} | '+', '.join(boundary)+f' | none | sha256:{digest} |\n\n## Source Files\n\n| Source ID | Role | Path | SHA-256 |\n|---|---|---|---|\n'+''.join(f'| app | {x["role"]} | `{x["path"]}` | {x["sha256"]} |\n' for x in manifest)+'\n## Change Log\n\n| Date | Change | Reason |\n|---|---|---|\n| 2026-09-07 | Initial documentation pass | First version |\n\nConfidence: 95%; static source trace, framework/runtime not executed.\n'
   write(target,doc); prior=target.read_bytes(); refresh=[]
   for x in manifest:
    p=source/x['path']; b=p.read_bytes(); refresh.append({'resolved':str(p),'sha256':sha(b),'matches':sha(b)==x['sha256']})
   ancestor=cmd(['git','merge-base','--is-ancestor',head,'HEAD'],src); dirty=cmd(['git','status','--short','--',*[''+str(p.relative_to(src)) for p in tracefiles]],src)
   state='Current' if all(x['matches'] for x in refresh) and ancestor.returncode==0 and not dirty.stdout else 'Stale'; dump(d/mode/(ws+'-refresh.json'),{'state':state,'actual_reads':refresh,'boundary_reenumeration':[str(p.relative_to(source)) for p in tracefiles if p.exists()],'doc_before':sha(prior),'doc_after':sha(target.read_bytes())})
   outcomes.append({'mode':mode,'workspace':ws,'tasks':len(tasks),'unique_ids':len({x['Workflow ID'] for x in tasks})==len(tasks),'exact_output':target.exists(),'refresh':state,'no_op':prior==target.read_bytes(),'task_doc':str(docs/'_docs-tasks.md')})
  after={p:sha((src/p).read_bytes()) for p in before}; dump(d/mode/'final-source-hashes.json',after); assert before==after
 finish(id,t,[check('original W1 static inventory, coverage and exact outputs',all(x['unique_ids'] and x['exact_output'] for x in outcomes),str(d)),check('Pages underscore and root route emitted',all('/api/_health' in Path(x['task_doc']).read_text() and 'http:any:/api`' in Path(x['task_doc']).read_text() for x in outcomes if x['workspace']=='next'),str(d)),check('SourceID paths actually read during refresh',all(x['refresh']=='Current' and x['no_op'] for x in outcomes),str(d)+'/*/*-refresh.json'),check('source bytes unchanged',True,str(d)+'/*/final-source-hashes.json')],outcomes)
if __name__=='__main__': group1()
