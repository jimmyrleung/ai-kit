# Expected workflow inventory

| Workspace | Workflow | Required result |
| --- | --- | --- |
| next | GET `/api/widgets/[id]` | captured from `src/app/(ops)/api/widgets/[id]/route.ts`; `(ops)` omitted; exported const supported |
| next | POST `/api/widgets/[id]` | captured from non-async exported function |
| next | server action `archiveWidget` | captured from file-level double-quoted directive; `[TODO: verify entry point]` retained |
| next | dynamic re-export | Scan coverage Partial with file:line; no invented task |
| dotnet-web | GET `/api/widgets/{id}` | Web SDK activates ASP.NET without explicit FrameworkReference; MapGroup prefix composed |
| functions | `QueueIngest` | isolated `[Function]` captured |
| functions | `LegacyTimer` | in-process `[FunctionName]` captured as a separate execution boundary |

All emitted tasks have unique stable Workflow IDs. The two Functions share one physical file
but remain separate. The produced doc path equals Resolved output under Docs root in co-located,
separate-docs, and multi-workspace runs.

