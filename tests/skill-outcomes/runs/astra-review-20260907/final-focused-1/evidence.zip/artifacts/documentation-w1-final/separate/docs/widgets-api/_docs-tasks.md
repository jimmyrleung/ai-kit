# Documentation Tasks — widgets-api

> Inventory Schema: v2

## Handoff

| Field | Value |
|---|---|
| Source root | `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/separate/source/dotnet-web` |
| Docs root | `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/separate/docs/widgets-api` |
| Workspace root | `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/separate/source/dotnet-web` |

## Tasks overview

| # | Title | Trigger | Service | Status |
|---|---|---|---|---|
| 1 | Document get-widgets-by-id | REST GET /api/widgets/{id} | widgets-api | Todo |

## Task 1 — Document get-widgets-by-id

**Status:** Todo
**Workflow ID:** `widgets-api:http:get:/api/widgets/{id}`
<!-- inventory:begin -->
**Source root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/separate/source/dotnet-web`
**Docs root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/separate/docs/widgets-api`
**Workspace root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/separate/source/dotnet-web`
**Reference:** `Program.cs:5`
**Resolved output:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/separate/docs/widgets-api/workflows/widgets-api/get-widgets-by-id.md`
**Files affected:** `workflows/widgets-api/get-widgets-by-id.md`
**Trigger:** REST GET /api/widgets/{id}
<!-- inventory:end -->

**Acceptance criteria:**
- A workflow doc exists exactly at Resolved output.
- The doc follows Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies.
- Backend mode.
