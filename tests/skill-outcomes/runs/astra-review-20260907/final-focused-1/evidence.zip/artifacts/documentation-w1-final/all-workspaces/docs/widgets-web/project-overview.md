# widgets-web — Project Overview

## Summary

Static fixture inventory: 5 execution boundaries (computed from emitted records).

## Top-level layout

- next.config.mjs
- package.json
- pages/api/_health.ts
- pages/api/index.ts
- src/app/(ops)/api/widgets/[id]/route.ts
- src/app/actions.ts

## Build / Run

No scripts supplied in package manifest; .NET host defaults not executed.

## Services

widgets-web

## Scan coverage

| Detector | State | Roots/patterns searched | Boundary |
|---|---|---|---|
| Next App Router | Covered | app/**/route.*, src/app/**/route.* | const GET and sync POST inspected |
| Next Pages API | Covered | pages/api/**, src/pages/api/**; next.config.mjs | default exports; default page extensions; root app/pages search empty where absent |
| Next Server Actions | Partial | app/**, src/app/** | src/app/actions.ts:8 unresolved generatedAction re-export |

## Notes

Static inspection only; unresolved forms are not invented tasks.
