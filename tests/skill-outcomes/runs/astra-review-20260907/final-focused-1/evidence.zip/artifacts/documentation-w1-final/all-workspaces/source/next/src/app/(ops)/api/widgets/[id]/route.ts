export const GET = async () => Response.json({ ok: true })

export function POST() {
  return Response.json({ created: true })
}

