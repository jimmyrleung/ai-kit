# Documentation Tasks — functions

> Inventory Schema: v2

## Handoff

| Field | Value |
|---|---|
| Source root | `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source` |
| Docs root | `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/functions` |
| Workspace root | `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source/functions` |

## Tasks overview

| # | Title | Trigger | Service | Status |
|---|---|---|---|---|
| 1 | Document legacy-timer | Timer 0 */5 * * * * | functions | Todo |
| 2 | Document queue-ingest | Queue widget-inbox | functions | Todo |

## Task 1 — Document legacy-timer

**Status:** Todo
**Workflow ID:** `functions:timer:0 */5 * * * *:FixtureFunctions.LegacyTimer`
<!-- inventory:begin -->
**Source root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source`
**Docs root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/functions`
**Workspace root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source/functions`
**Reference:** `Functions.cs:FixtureFunctions.LegacyTimer`
**Resolved output:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/functions/workflows/functions/legacy-timer.md`
**Files affected:** `workflows/functions/legacy-timer.md`
**Trigger:** Timer 0 */5 * * * *
<!-- inventory:end -->

**Acceptance criteria:**
- A workflow doc exists exactly at Resolved output.
- The doc follows Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies.
- Backend mode.

## Task 2 — Document queue-ingest

**Status:** Todo
**Workflow ID:** `functions:queue:widget-inbox`
<!-- inventory:begin -->
**Source root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source`
**Docs root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/functions`
**Workspace root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source/functions`
**Reference:** `Functions.cs:FixtureFunctions.QueueIngest`
**Resolved output:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/functions/workflows/functions/queue-ingest.md`
**Files affected:** `workflows/functions/queue-ingest.md`
**Trigger:** Queue widget-inbox
<!-- inventory:end -->

**Acceptance criteria:**
- A workflow doc exists exactly at Resolved output.
- The doc follows Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies.
- Backend mode.
