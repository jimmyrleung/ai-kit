// comments may precede the directive
"use server"

export async function archiveWidget() {
  return { archived: true }
}

export { generatedAction } from './generated-actions'

