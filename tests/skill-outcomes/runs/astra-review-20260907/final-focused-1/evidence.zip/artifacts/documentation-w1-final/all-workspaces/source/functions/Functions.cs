public class FixtureFunctions
{
    [Function("QueueIngest")]
    public void QueueIngest([QueueTrigger("widget-inbox")] string body) { }

    [FunctionName("LegacyTimer")]
    public void LegacyTimer([TimerTrigger("0 */5 * * * *")] object timer) { }
}

