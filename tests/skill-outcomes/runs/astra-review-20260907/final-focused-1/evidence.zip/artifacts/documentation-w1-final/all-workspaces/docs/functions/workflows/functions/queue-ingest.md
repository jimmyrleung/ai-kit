# functions:queue:widget-inbox

## Summary

| Field | Value |
|---|---|
| Schema | v2 |
| Mode | Backend |
| Created | 2026-09-07 |
| Last Updated | 2026-09-07 |
| Generated From | cacf82a90a76 |
| Cross-Service | No |
| Business Rules | No |
| Complex Logic | No |

## Sequence of Calls

Queue widget-inbox → FixtureFunctions.QueueIngest

## Flow Description

1. Queue trigger binds body to string; method body is empty. No writes or outgoing calls are declared.

## Data Inventory

### Request / Response

| Direction | Type | Description |
|---|---|---|
| Input | string body | Queue message |

## Business Rules

No business rules declared in this bounded handler.

## Configuration

Registration and project inputs listed in Source Files.

## Dependencies

Framework response/trigger primitives; no external service calls traced.

## Source Evidence

| Source ID | Repository/source identity | Full revision | Trace boundary | Relevant dirty paths | Manifest SHA-256 |
|---|---|---|---|---|---|
| app | /tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source | cacf82a90a76d50fd077822c5dc32df5fae7976d | functions/Functions.cs, functions/Functions.csproj | none | sha256:c7ee5be6a62935dafd41c893267835f129712423655f1dadcbdf5d8c941d015d |

## Source Files

| Source ID | Role | Path | SHA-256 |
|---|---|---|---|
| app | Entry point | `functions/Functions.cs` | a7a8e0ec7cd395bb1efe0bad26fe22d193d33d8aba4c40a8360d0aeecd883449 |
| app | Registration/config | `functions/Functions.csproj` | 2c0a04e85900ba76d6a203f6fcaeb0eb1a0138f1b61869312e4347743f240392 |

## Change Log

| Date | Change | Reason |
|---|---|---|
| 2026-09-07 | Initial documentation pass | First version |

Confidence: 95%; static source trace, framework/runtime not executed.
