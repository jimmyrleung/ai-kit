# functions — Project Overview

## Summary

Static fixture inventory: 2 execution boundaries (computed from emitted records).

## Top-level layout

- Functions.cs
- Functions.csproj

## Build / Run

No scripts supplied in package manifest; .NET host defaults not executed.

## Services

functions

## Scan coverage

| Detector | State | Roots/patterns searched | Boundary |
|---|---|---|---|
| Azure Functions | Covered | **/*.cs, *.csproj | Function and FunctionName separate execution boundaries; literal queue and timer inspected |

## Notes

Static inspection only; unresolved forms are not invented tasks.
