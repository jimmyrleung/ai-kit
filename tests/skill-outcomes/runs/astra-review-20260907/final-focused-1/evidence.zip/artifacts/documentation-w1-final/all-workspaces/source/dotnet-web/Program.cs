var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();
var api = app.MapGroup("/api");
var widgets = api.MapGroup("/widgets");
widgets.MapGet("/{id}", (string id) => Results.Ok(id));
var dynamicPrefix = Environment.GetEnvironmentVariable("ROUTE_PREFIX");
app.MapGroup(dynamicPrefix!).MapGet("/health", () => Results.Ok());
app.Run();

