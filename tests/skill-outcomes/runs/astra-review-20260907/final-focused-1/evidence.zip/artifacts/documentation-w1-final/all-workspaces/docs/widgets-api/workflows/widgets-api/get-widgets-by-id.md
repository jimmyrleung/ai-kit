# widgets-api:http:get:/api/widgets/{id}

## Summary

| Field | Value |
|---|---|
| Schema | v2 |
| Mode | Backend |
| Created | 2026-09-07 |
| Last Updated | 2026-09-07 |
| Generated From | cacf82a90a76 |
| Cross-Service | No |
| Business Rules | No |
| Complex Logic | No |

## Sequence of Calls

GET → MapGet lambda → Results.Ok(id)

## Flow Description

1. Literal groups compose /api/widgets/{id}; bound string id is returned using Results.Ok. Dynamic health registration is outside this route boundary.

## Data Inventory

### Request / Response

| Direction | Type | Description |
|---|---|---|
| Input/output | string id | Path parameter echoed |

## Business Rules

No business rules declared in this bounded handler.

## Configuration

Registration and project inputs listed in Source Files.

## Dependencies

Framework response/trigger primitives; no external service calls traced.

## Source Evidence

| Source ID | Repository/source identity | Full revision | Trace boundary | Relevant dirty paths | Manifest SHA-256 |
|---|---|---|---|---|---|
| app | /tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source | cacf82a90a76d50fd077822c5dc32df5fae7976d | dotnet-web/Program.cs, dotnet-web/Widgets.Api.csproj | none | sha256:b0d5ba525614577b4e7c62bbc48a4d3c9f6548419a0bc553c615b91b11ddb59a |

## Source Files

| Source ID | Role | Path | SHA-256 |
|---|---|---|---|
| app | Entry point | `dotnet-web/Program.cs` | e440906d5be9ac807e58065cde9e31d8b5eceed176eee07db8e251dfad472861 |
| app | Registration/config | `dotnet-web/Widgets.Api.csproj` | 69e4ddf0eac0a03f38fc2c937cee2a4458aea640409744600442b3b9c4b76f78 |

## Change Log

| Date | Change | Reason |
|---|---|---|
| 2026-09-07 | Initial documentation pass | First version |

Confidence: 95%; static source trace, framework/runtime not executed.
