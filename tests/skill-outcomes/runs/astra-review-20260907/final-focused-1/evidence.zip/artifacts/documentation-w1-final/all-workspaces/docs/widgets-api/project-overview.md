# widgets-api — Project Overview

## Summary

Static fixture inventory: 1 execution boundaries (computed from emitted records).

## Top-level layout

- Program.cs
- Widgets.Api.csproj

## Build / Run

No scripts supplied in package manifest; .NET host defaults not executed.

## Services

widgets-api

## Scan coverage

| Detector | State | Roots/patterns searched | Boundary |
|---|---|---|---|
| ASP.NET minimal API | Partial | **/*.cs, *.csproj | Web SDK; literal /api + /widgets + /{id}; Program.cs:7 dynamic ROUTE_PREFIX unresolved |

## Notes

Static inspection only; unresolved forms are not invented tasks.
