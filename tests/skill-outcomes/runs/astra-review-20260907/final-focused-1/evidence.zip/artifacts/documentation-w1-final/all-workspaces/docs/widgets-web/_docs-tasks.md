# Documentation Tasks — widgets-web

> Inventory Schema: v2

## Handoff

| Field | Value |
|---|---|
| Source root | `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source` |
| Docs root | `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web` |
| Workspace root | `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source/next` |

## Tasks overview

| # | Title | Trigger | Service | Status |
|---|---|---|---|---|
| 1 | Document api-health | REST /api/_health | widgets-web | Todo |
| 2 | Document api-root | REST /api | widgets-web | Todo |
| 3 | Document archive-widget | Server action archiveWidget | widgets-web | Todo |
| 4 | Document get-widgets-by-id | REST GET /api/widgets/[id] | widgets-web | Todo |
| 5 | Document post-widgets-by-id | REST POST /api/widgets/[id] | widgets-web | Todo |

## Task 1 — Document api-health

**Status:** Todo
**Workflow ID:** `widgets-web:http:any:/api/_health`
<!-- inventory:begin -->
**Source root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source`
**Docs root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web`
**Workspace root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source/next`
**Reference:** `pages/api/_health.ts:handler`
**Resolved output:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web/workflows/widgets-web/api-health.md`
**Files affected:** `workflows/widgets-web/api-health.md`
**Trigger:** REST /api/_health
<!-- inventory:end -->

**Acceptance criteria:**
- A workflow doc exists exactly at Resolved output.
- The doc follows Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies.
- Backend mode.

## Task 2 — Document api-root

**Status:** Todo
**Workflow ID:** `widgets-web:http:any:/api`
<!-- inventory:begin -->
**Source root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source`
**Docs root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web`
**Workspace root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source/next`
**Reference:** `pages/api/index.ts:handler`
**Resolved output:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web/workflows/widgets-web/api-root.md`
**Files affected:** `workflows/widgets-web/api-root.md`
**Trigger:** REST /api
<!-- inventory:end -->

**Acceptance criteria:**
- A workflow doc exists exactly at Resolved output.
- The doc follows Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies.
- Backend mode.

## Task 3 — Document archive-widget

**Status:** Todo
**Workflow ID:** `widgets-web:action:archiveWidget`
<!-- inventory:begin -->
**Source root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source`
**Docs root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web`
**Workspace root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source/next`
**Reference:** `src/app/actions.ts:archiveWidget`
**Resolved output:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web/workflows/widgets-web/archive-widget.md`
**Files affected:** `workflows/widgets-web/archive-widget.md`
**Trigger:** Server action archiveWidget
<!-- inventory:end -->

**Acceptance criteria:**
- A workflow doc exists exactly at Resolved output.
- The doc follows Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies.
- Backend mode.
- [TODO: verify entry point]

## Task 4 — Document get-widgets-by-id

**Status:** Todo
**Workflow ID:** `widgets-web:http:get:/api/widgets/[id]`
<!-- inventory:begin -->
**Source root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source`
**Docs root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web`
**Workspace root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source/next`
**Reference:** `src/app/(ops)/api/widgets/[id]/route.ts:GET`
**Resolved output:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web/workflows/widgets-web/get-widgets-by-id.md`
**Files affected:** `workflows/widgets-web/get-widgets-by-id.md`
**Trigger:** REST GET /api/widgets/[id]
<!-- inventory:end -->

**Acceptance criteria:**
- A workflow doc exists exactly at Resolved output.
- The doc follows Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies.
- Backend mode.

## Task 5 — Document post-widgets-by-id

**Status:** Todo
**Workflow ID:** `widgets-web:http:post:/api/widgets/[id]`
<!-- inventory:begin -->
**Source root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source`
**Docs root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web`
**Workspace root:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/source/next`
**Reference:** `src/app/(ops)/api/widgets/[id]/route.ts:POST`
**Resolved output:** `/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/documentation-w1-final/all-workspaces/docs/widgets-web/workflows/widgets-web/post-widgets-by-id.md`
**Files affected:** `workflows/widgets-web/post-widgets-by-id.md`
**Trigger:** REST POST /api/widgets/[id]
<!-- inventory:end -->

**Acceptance criteria:**
- A workflow doc exists exactly at Resolved output.
- The doc follows Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies.
- Backend mode.
