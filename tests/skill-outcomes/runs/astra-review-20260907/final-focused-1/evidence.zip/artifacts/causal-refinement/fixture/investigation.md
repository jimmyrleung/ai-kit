# Reviewed investigation — 2026-09-06
The working diagnosis was a missing timeout setting. This was approved as the incident cause on the evidence then available.
