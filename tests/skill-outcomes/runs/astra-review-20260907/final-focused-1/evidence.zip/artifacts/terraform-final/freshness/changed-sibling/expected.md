# Expected Terraform result

- Root input `environment` resolves to `prod` from `production.auto.tfvars`; `region` resolves
  from the root default. Child `local_leaf.name` resolves only through the parent module
  argument. No root tfvars are applied directly inside the child.
- No backend block and no orchestration mapping for this root means default local backend.
  The unrelated stack file is not evidence for an orchestrator-managed backend.
- Both `null_resource` blocks remain separate producer entries because their provider
  configurations differ, despite the same resolved trigger name.
- `modules/local-leaf` is a source-resolved local provenance leaf with no invented version.
- `network` and `logs` are two module subdirectories/source identities in one package
  repository and the same ref; repository count, module-source count, and source@version count
  are reported separately.
- `registry_semantics_only` is `semantics-only` unless its pinned module body is readable;
  registry prose does not create resource inventory rows.
- With no credentials/state: declared topology remains useful; every Deployment and Effective
  cell is `unknown`, never failure. A later observed denial is `proven failure` and differs from
  an unrun check.
- Output is schema v4 with per-source full revision/manifest identity and Source Files hashes.
  Dirty root HCL invalidates freshness at unchanged HEAD. An independently changing readable
  module has its own Source ID/revision/hash; unreadable source makes affected freshness
  Unverifiable.
