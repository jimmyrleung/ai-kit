# Terraform fixture

## Summary

| Field | Value |
|---|---|
| Created | 2026-09-07 |
| Last Updated | 2026-09-07 |
| Generated From | a39cf1f9eda9 |
| Schema | v4 |
| Scope | root/prod |
| Source Root | /tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/terraform-final/source/root |
| Docs Root | /tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/terraform-final/docs |

## Topology and on-ramp

One execution root, environment prod from production.auto.tfvars:1, region south from main.tf:8 default. No other environment execution inputs supplied. Backend is default local: no backend block and unrelated-stack.yaml maps some-other-root. [Backend contract](https://developer.hashicorp.com/terraform/language/backend).

## Inputs

environment prod binds in root, local.name = widget-prod-south (main.tf:10). The root calls local_leaf with name=local.name, and wrapper with that same value; wrapper forwards var.name to both children. Root tfvars never directly bind child variables. [Input contract](https://developer.hashicorp.com/terraform/language/values/variables). Confidence 95% within supplied execution context; unobserved CLI overrides are unknown.

## Module provenance

```text
root [entry]
├─ module.local_leaf → ./modules/local-leaf [local]
├─ module.network → platform-modules.git//modules/network@v1.2.3 [priv?] unresolved
├─ module.logs → platform-modules.git//modules/logs@v1.2.3 [priv?] unresolved
├─ module.registry_semantics_only → hashicorp/consul/aws@0.11.0 [priv?] semantics-only
└─ module.wrapper → ./modules/wrapper [wrap]
   ├─ module.one → ../../../sibling [local] independently versioned
   └─ module.two → ../local-leaf [local]
```

## Resource inventory

| Address | Provider | Origin | Trigger template → value | Source | Deployment | Effective |
|---|---|---|---|---|---|---|
| null_resource.primary | null | [entry] | local.name / var.name → widget-prod-south (95%) | main.tf:15 | unknown | unknown |
| null_resource.same_name_other_context | null.secondary | [entry] | local.name / var.name → widget-prod-south (95%) | main.tf:19 | unknown | unknown |
| module.local_leaf.null_resource.leaf | null | [local] | local.name / var.name → widget-prod-south (95%) | modules/local-leaf/main.tf:1 | unknown | unknown |
| module.wrapper.module.one.null_resource.leaf | null | [local] | local.name / var.name → widget-prod-south (95%) | sibling/main.tf:2 | unknown | unknown |
| module.wrapper.module.two.null_resource.leaf | null | [local] | local.name / var.name → widget-prod-south (95%) | modules/local-leaf/main.tf:1 | unknown | unknown |

The trigger name is arbitrary trigger data, not an observed cloud object name. Changes to trigger strings cause replacement according to [null_resource docs](https://registry.terraform.io/providers/hashicorp/null/latest/docs/resources/resource).

## Roles in this architecture

```text
local_leaf provides a null-resource trigger (modules/local-leaf/main.tf:1); no in-repo consumer edge found.
wrapper composes two local leaves (modules/wrapper/main.tf:2,6), forwarding name; no runtime dependency proven.
network/logs pinned bodies unavailable; architectural role indeterminate beyond their literal source identities.
registry_semantics_only: generic Consul-on-AWS module semantics; no body-derived resource rows.
```

[Registry semantics](https://registry.terraform.io/modules/hashicorp/consul/aws/latest). The network/logs calls share one remote package and ref but identify two module subdirectories and two source@version pairs. See module-identities.json for computed full enumeration.

## Integration & permissioning (incident-triage)

| Link/grant | Mechanism | Identity | Target | Exact role/perm | Declared | Deployment | Effective | Evidence |
|---|---|---|---|---|---|---|---|---|
| In-repo grants | none found in readable HCL | deploy identity unknown | runtime target unknown | unknown | indeterminate across unreadable modules | unknown | unknown | source-manifest.json |

## External infrastructure

No data sources in inspected files; remote module contents remain indeterminate, not external by assumption. Missing bodies require readable pinned source before resource or producer claims.

## Secrets

No secret-bearing values read.

## Source Evidence

| Source ID | Root/locator | Full revision | Boundary | Dirty | Manifest SHA-256 |
|---|---|---|---|---|---|
| root | /tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/terraform-final/source/root | a39cf1f9eda97b3952306379812eaa15b97720a1 | extra.tf, main.tf, modules/local-leaf/main.tf, modules/local-leaf/variables.tf, modules/wrapper/main.tf, production.auto.tfvars | none | 7940cc3096e411b4c899a9d25eb62652c8dbf15ee852d827e69445b8973dfa19 |
| sibling | /tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/terraform-final/source/sibling | 93c5af72f675d99152b6e8dbd4010bcf11b778be | main.tf | none | b1a173475e6d8d23fb89562e55a274e4343ca05963b646e0b8d4763887ae022a |
| orchestration | /tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/terraform-final/source/orchestration | unversioned; revision freshness Unverifiable | unrelated-stack.yaml | none | 471cf6febdd25eb39845851d16c6fbf6f78256e873f51739a456779d807539f1 |

## Source Files

| Source ID | Role | Path | SHA-256 |
|---|---|---|---|
| orchestration | module/config | unrelated-stack.yaml | b148fb2be0de1d3819d4b60258f3e078617ba2787f0a4655eda845acd24cc701 |
| root | module/config | extra.tf | d1f6a0980462fa0e7768c2272c1df90287de35a0596880b91b478181268872a4 |
| root | module/config | main.tf | f12825155f232a7764e246e2159925bd34a1ab714af6cb7694927433d64795c8 |
| root | module/config | modules/local-leaf/main.tf | 14a6b5c6ecc53eac2470833123fd7dc22014d3109e99e2df353e24129b90f5fb |
| root | module/config | modules/local-leaf/variables.tf | 74b3fe9a884cfe559ff3e1d2cfa639a8a672a1c9e4e4ea3cf68927d3b09193c7 |
| root | module/config | modules/wrapper/main.tf | b734fc21597e99d2e3f275d99a4ca29ebf80505a0c6eba5a65cca0ba32124b00 |
| root | module/config | production.auto.tfvars | 452be631aaede015ccb7a3b3a5f25e4710e597ae89a984ed191891b6027e740e |
| sibling | module/config | main.tf | 1f935939e2f8a7968179b3fa792fe7c3151db5186b2fadc0e4538d3a03f18e94 |

## Change Log

| Date | Change | Reason |
|---|---|---|
| 2026-09-07 | Initial documentation pass | First v4 draft |
