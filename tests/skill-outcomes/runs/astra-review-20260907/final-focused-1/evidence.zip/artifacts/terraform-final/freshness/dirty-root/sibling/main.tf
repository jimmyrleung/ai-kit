variable "name" { type = string }
resource "null_resource" "leaf" { triggers = { name = var.name } }
