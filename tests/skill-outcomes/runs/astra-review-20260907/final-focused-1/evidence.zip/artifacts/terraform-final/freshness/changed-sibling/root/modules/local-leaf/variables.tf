variable "name" { type = string }
