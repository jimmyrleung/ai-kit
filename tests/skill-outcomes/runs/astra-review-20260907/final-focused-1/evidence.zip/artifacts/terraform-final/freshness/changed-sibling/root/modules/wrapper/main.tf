variable "name" { type = string }
module "one" {
  source = "../../../sibling"
  name = var.name
}
module "two" {
  source = "../local-leaf"
  name = var.name
}
