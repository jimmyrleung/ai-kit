terraform {
  required_providers {
    null = { source = "hashicorp/null" }
  }
}

variable "environment" { default = "dev" }
variable "region" { default = "south" }

locals { name = "widget-${var.environment}-${var.region}" }

provider "null" {}
provider "null" { alias = "secondary" }

resource "null_resource" "primary" {
  triggers = { name = local.name }
}

resource "null_resource" "same_name_other_context" {
  provider = null.secondary
  triggers = { name = local.name }
}

module "local_leaf" {
  source = "./modules/local-leaf"
  name   = local.name
}

module "network" {
  source = "git::https://example.invalid/platform-modules.git//modules/network?ref=v1.2.3"
  name   = local.name
}

module "logs" {
  source = "git::https://example.invalid/platform-modules.git//modules/logs?ref=v1.2.3"
  name   = local.name
}

module "registry_semantics_only" {
  source  = "hashicorp/consul/aws"
  version = "0.11.0"
}

