# BUG-1 fix technical specification

## Summary
Fix mode, bounded single approach. The deterministic fixture value() returns 2 and rejects negative input. Risk LOW; SAFE TO IMPLEMENT within synthetic fixture scope. Reviewed status is supplied synthetic evidence, not an actual upstream review.

## Approach
Use the direct value return and negative-input guard; existing unittest fixture covers both outcomes.

## Scope
value.py and tests/test_value.py. Live behavior and deployment are outside the fixture.

## Patterns reused
| Pattern | Source | Usage |
|---|---|---|
| unittest assertions | tests/test_value.py:3 ValueTests | behavior checks |

## Acceptance criteria
- AC-F1: returns 2
- AC-F2: negative input raises ValueError

AC-F1 maps to investigation.md / Expected behavior / returns 2. AC-F2 is the explicitly supplied distinct fix acceptance outcome.

## Implementation map
value.py: value uses the direct guard and constant result. tests/test_value.py: extend the suitable existing fixture test module.

## Test plan
| # | Scenario | Input | Expected | Priority | Automatable |
|---|---|---|---|---|---|
| 1 | Return value | default | 2 | High | yes |
| 2 | Negative input | -1 | ValueError | High | yes |
No browser or integration tests needed: the fixture has no UI, network, database or other consumer.

## Files changed summary
1 production file and 1 test file in the named fixture scope; enumerated by scope-files.json. No new mechanism.

## Impact and dependencies
Source search finds tests/test_value.py importing value. No other fixture importers. No shared state, config or side effects. Production incident linkage remains unproven.

## Rollback
For a regression restore the prior reviewed fixture source bytes; no live rollback or deployment authorized.

## Risks table
| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Fixture differs from production | unknown | live behavior unverified | restrict verdict to fixture |

## Confidence score
95%: exact expected outcomes, inspected fixture source/tests, bounded behavior. 5% uncertainty: synthetic inputs do not establish production source or causal evidence.
