import unittest
from value import value
class ValueTests(unittest.TestCase):
    def test_returns_two(self):
        self.assertEqual(value(), 2)
    def test_negative(self):
        with self.assertRaises(ValueError): value(-1)
