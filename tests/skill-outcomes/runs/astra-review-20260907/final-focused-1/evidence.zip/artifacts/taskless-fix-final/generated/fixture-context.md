Source and tests are deterministic materialized fixture subjects, not source supplied by the original investigation. This trial tests handoff and verification behavior, not a production bug fix.
