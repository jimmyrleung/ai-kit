# BUG-1
## Expected behavior
- returns 2
## Proposed fix
Use corrected value.

<!-- evidence:begin generated-verify-1 -->
## Verify — generated-verify-1
{
  "record_id": "generated-verify-1",
  "ac_mapping": [
    {
      "id": "AC-F1",
      "text": "returns 2",
      "source_locators": [
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/generated/investigation.md:3",
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/generated/BUG-1_techspec.md:18"
      ]
    },
    {
      "id": "AC-F2",
      "text": "negative input raises ValueError",
      "source_locators": [
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/generated/BUG-1_techspec.md:19"
      ]
    }
  ],
  "same_original_mapping": true,
  "test_exit": 0,
  "test_output": "test_negative (test_value.ValueTests.test_negative) ... ok\ntest_returns_two (test_value.ValueTests.test_returns_two) ... ok\n\n----------------------------------------------------------------------\nRan 2 tests in 0.002s\n\nOK\n",
  "evidence_kind": "executed local synthetic source fixture",
  "source_review": "supplied synthetic; not actually executed",
  "gates": {
    "build_test": "pass",
    "ac": "pass",
    "cross_cutting": "pass: scoped fixture no env/config/version/budget constraints; source read and caller search executed"
  }
}
<!-- evidence:end generated-verify-1 -->

<!-- evidence:begin generated-verify-2 -->
## Verify — generated-verify-2
{
  "record_id": "generated-verify-2",
  "ac_mapping": [
    {
      "id": "AC-F1",
      "text": "returns 2",
      "source_locators": [
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/generated/investigation.md:3",
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/generated/BUG-1_techspec.md:18"
      ]
    },
    {
      "id": "AC-F2",
      "text": "negative input raises ValueError",
      "source_locators": [
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/generated/BUG-1_techspec.md:19"
      ]
    }
  ],
  "same_original_mapping": true,
  "test_exit": 0,
  "test_output": "test_negative (test_value.ValueTests.test_negative) ... ok\ntest_returns_two (test_value.ValueTests.test_returns_two) ... ok\n\n----------------------------------------------------------------------\nRan 2 tests in 0.001s\n\nOK\n",
  "evidence_kind": "executed local synthetic source fixture",
  "source_review": "supplied synthetic; not actually executed",
  "gates": {
    "build_test": "pass",
    "ac": "pass",
    "cross_cutting": "pass: scoped fixture no env/config/version/budget constraints; source read and caller search executed"
  }
}
<!-- evidence:end generated-verify-2 -->
