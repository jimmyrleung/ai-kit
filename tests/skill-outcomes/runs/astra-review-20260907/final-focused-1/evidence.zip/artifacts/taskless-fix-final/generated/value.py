def value(amount=0):
    if amount < 0:
        raise ValueError("negative input")
    return 2
