# BUG-1
## Expected behavior
- returns 2
## Proposed fix
Use corrected value.

<!-- evidence:begin duplicate-original-verify-1 -->
## Verify — duplicate-original-verify-1
{
  "record_id": "duplicate-original-verify-1",
  "ac_mapping": [
    {
      "id": "AC-F1",
      "text": "returns 2",
      "source_locators": [
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/duplicate-original/investigation.md:3",
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/duplicate-original/fix-techspec.md:3"
      ]
    },
    {
      "id": "AC-F2",
      "text": "negative input raises ValueError",
      "source_locators": [
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/duplicate-original/fix-techspec.md:4"
      ]
    }
  ],
  "same_original_mapping": true,
  "test_exit": 0,
  "test_output": "test_negative (test_value.ValueTests.test_negative) ... ok\ntest_returns_two (test_value.ValueTests.test_returns_two) ... ok\n\n----------------------------------------------------------------------\nRan 2 tests in 0.001s\n\nOK\n",
  "evidence_kind": "executed local synthetic source fixture",
  "source_review": "supplied synthetic; not actually executed",
  "gates": {
    "build_test": "pass",
    "ac": "pass",
    "cross_cutting": "pass: scoped fixture no env/config/version/budget constraints; source read and caller search executed"
  }
}
<!-- evidence:end duplicate-original-verify-1 -->

<!-- evidence:begin duplicate-original-verify-2 -->
## Verify — duplicate-original-verify-2
{
  "record_id": "duplicate-original-verify-2",
  "ac_mapping": [
    {
      "id": "AC-F1",
      "text": "returns 2",
      "source_locators": [
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/duplicate-original/investigation.md:3",
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/duplicate-original/fix-techspec.md:3"
      ]
    },
    {
      "id": "AC-F2",
      "text": "negative input raises ValueError",
      "source_locators": [
        "/tmp/astra-backlog-5VdqNm/trials/final-focused/1/artifacts/taskless-fix-final/duplicate-original/fix-techspec.md:4"
      ]
    }
  ],
  "same_original_mapping": true,
  "test_exit": 0,
  "test_output": "test_negative (test_value.ValueTests.test_negative) ... ok\ntest_returns_two (test_value.ValueTests.test_returns_two) ... ok\n\n----------------------------------------------------------------------\nRan 2 tests in 0.001s\n\nOK\n",
  "evidence_kind": "executed local synthetic source fixture",
  "source_review": "supplied synthetic; not actually executed",
  "gates": {
    "build_test": "pass",
    "ac": "pass",
    "cross_cutting": "pass: scoped fixture no env/config/version/budget constraints; source read and caller search executed"
  }
}
<!-- evidence:end duplicate-original-verify-2 -->
