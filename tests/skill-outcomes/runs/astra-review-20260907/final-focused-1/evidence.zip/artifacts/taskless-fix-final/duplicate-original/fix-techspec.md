# Fix
## Acceptance criteria
- AC-F1: returns 2
- AC-F2: negative input raises ValueError
