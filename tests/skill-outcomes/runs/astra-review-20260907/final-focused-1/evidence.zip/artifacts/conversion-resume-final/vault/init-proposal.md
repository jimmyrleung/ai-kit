# Approved conversion

Approval: alpha and beta source conversion plus local synthesis authorized by supplied fixture. cache excluded. unknown is blocked, owner classification required; no acceptance supplied.

```tsv
item_id	origin	destination	classification	domain	original_tracking	intended_tracking	content_identity	source_note	status	note
alpha	legacy/alpha.md	raw/course/alpha.md	source	course	tracked	tracked	sha256:0a6e82553d42a0153d92b9e5bae94c5514a9afa281e7928509351682397651d5	sources/course/alpha.md	compiled	origin absent; destination bytes verified
beta	legacy/beta.md	raw/course/beta.md	source	course	untracked	untracked	sha256:532b49ac7ac21509d27993b477e5ae8bf985b4b0dc2067dc2e0d91a1720f62bc	sources/course/beta.md	compiled	approved
cache	legacy/cache.bin	leave	exhaust	course	untracked	untracked	sha256:fb25be91f70e50999b7c35000f5de83d5477c74e10fd1b84d7fa2639a356ffd1	-	excluded	SCHEMA exhaust
unknown	legacy/data.xyz	leave	unknown	course	untracked	untracked	sha256:2dba0f423fc49a39934ec38a430e37ad2e1c051ff45d5b4fca5065a8c688abfb	-	blocked	owner classification required
```
