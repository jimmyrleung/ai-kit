# Fixture vault

## Compile
archetype: study
domains:
  course: study
synthesis_depth: full
compile_targets: [wiki/topics]

## Exhaust
legacy/cache.bin is exhaust. Unknown extension requires owner classification.
