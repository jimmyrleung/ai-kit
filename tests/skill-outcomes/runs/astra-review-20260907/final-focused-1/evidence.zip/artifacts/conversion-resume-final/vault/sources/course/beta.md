---
status: integrated
domains: [course]
themes: [retries]
date_consumed: 2026-09-07
source_type: markdown
original_filename: legacy/beta.md
raw: raw/course/beta.md
sha256_prefix: 532b49ac7ac2
---
# Beta
Use idempotency keys for repeated requests.

## Source Trail
Origin: legacy/beta.md; current: raw/course/beta.md
