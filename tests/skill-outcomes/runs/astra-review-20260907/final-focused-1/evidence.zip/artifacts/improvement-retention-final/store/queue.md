# Improvement queue

- item_id: item-7
  source_observation_ids: [obs-old]
  disposition: deferred
  packet: packets/2026-08-01/proposals/07.md
  prediction_state: none
- item_id: item-9
  source_observation_ids: [obs-actioned]
  disposition: actioned
  packet: packets/2026-08-03/proposals/09.md
  prediction_id: pred-2
  prediction_state: no-evidence

discovery_watermark: 2026-09-07T00:00:00Z

