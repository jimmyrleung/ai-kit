# Synthetic historical observation
record_id: obs-old
execution_id: synthetic-20260801
recorded_at: 2026-08-01T10:00:00Z
evidence_kind: lived
Evidence: a handler moved, while its workflow document still cited the old path.
