# Synthetic historical observation
record_id: obs-actioned
recorded_at: 2026-08-03T10:00:00Z
Evidence: prior task verification omitted source locators.
