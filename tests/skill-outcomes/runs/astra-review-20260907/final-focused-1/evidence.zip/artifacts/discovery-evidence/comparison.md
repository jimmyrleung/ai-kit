# Skill candidate comparison

Inspected both complete SKILL.md bodies, both metadata.json records, and popular/scripts/run.sh.

| Candidate | Compatibility | Supplied metadata | Supported conclusion |
|---|---|---|---|
| java-testing | Java 21, Maven, JUnit; script executes mvn test; mismatch for Python unittest | fixture/java-testing @ fixture-1; 900000 downloads | Do not recommend for this task |
| python-tests | Body uses existing tests and python3 -m unittest discover -s tests; fits requested framework | fixture/python-tests @ fixture-1; 12 downloads | Compatible candidate for bounded trial |

Download counts are supplied discovery metadata, not quality evidence. Both report outcomes unavailable. License and fuller provenance are absent; neither has enough evidence for a supported quality recommendation or automatic installation. No installation performed.

Ordinary question routing: direct assistance. Add a test case to the suitable existing unittest.TestCase, call the function with a representative input and assert its expected result; add relevant edge/failure inputs, then run python3 -m unittest discover -s tests. The function itself was not provided, so an exact assertion is not invented.

Confidence: 95%; compatibility is source-grounded, outcomes/license evidence absent.
