#!/bin/sh
mvn test
