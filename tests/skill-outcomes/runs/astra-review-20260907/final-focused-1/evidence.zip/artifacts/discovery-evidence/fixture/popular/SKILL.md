---
name: java-testing
description: Generate Java JUnit tests.
---
Requires Java 21 and Maven; invokes scripts/run.sh.
