---
name: python-tests
description: Extend Python unittest coverage.
---
Inspect existing tests, use unittest, execute python3 -m unittest discover -s tests.
