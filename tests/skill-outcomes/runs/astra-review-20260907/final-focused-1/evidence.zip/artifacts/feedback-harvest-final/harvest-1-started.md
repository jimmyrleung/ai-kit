# Fixture tasks

<!-- close-tasks: harvested through abc123 @ 2026-09-06 -->

## Task 1 — repository change

**Status:** Done
**Lifecycle:** pre-merge

<!-- evidence:begin verify-input-1 -->
### Verify

- Gate 1: pass
- Gate 3: FAIL — accepted: fixture environment differs

<!-- evidence:end verify-input-1 -->

## Task 2 — live rehearsal

**Status:** Todo
**Lifecycle:** live

<!-- evidence:begin harvest-1 -->
feedback-harvest-started: harvest-1; execution_id: fixture-tasks-run; state: started
<!-- evidence:end harvest-1 -->
