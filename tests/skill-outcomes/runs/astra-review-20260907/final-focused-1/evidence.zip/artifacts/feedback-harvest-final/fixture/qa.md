<!-- evidence:begin qa-input-1 -->
# Fixture QA

**Recommendation:** go
**Scope:** repository

<!-- evidence:end qa-input-1 -->
