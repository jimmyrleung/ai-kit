# Fixture tasks

<!-- close-tasks: harvested through abc123 @ 2026-09-06 -->

## Task 1 — repository change

**Status:** Done
**Lifecycle:** pre-merge

<!-- evidence:begin verify-input-1 -->
### Verify

- Gate 1: pass
- Gate 3: FAIL — accepted: fixture environment requires explicit key mapping

<!-- evidence:end verify-input-1 -->

## Task 2 — live rehearsal

**Status:** Todo
**Lifecycle:** live

<!-- evidence:begin harvest-1 -->
feedback-harvest:
{
  "schema_version": 1,
  "record_id": "harvest-1",
  "record_kind": "feedback-harvest",
  "recorded_at": "2026-09-07T11:17:10.264490+00:00",
  "execution_id": "fixture-tasks-run",
  "producer": "close-tasks",
  "recorder": "close-tasks",
  "project": "fixture-feedback",
  "source_record_ids": [
    "verify-input-1",
    "qa-input-1",
    "legacy-derived:matching-state.json"
  ],
  "evidence_identity": "ba1152c059b4e69dc78add1d2a28a3f4a490244d37d48e9a6071b25057091d42",
  "validation": "passed",
  "verdict": "passed",
  "supersedes": "none",
  "runner_attribution": "verified from supplied artifact only",
  "repository_status": "complete",
  "operational_status": "pending",
  "artifact_manifest": [
    {
      "path": "tasks-after.md",
      "sha256": "281b80e7d32cc7cffe812ca99a0da9135d19e59dce128763cffaf70476ba04de"
    },
    {
      "path": "qa.md",
      "sha256": "a5c970d10f8a31d14dbbbc14a3a0a360e953f293574fa5a135f759baa69cdc8c"
    },
    {
      "path": "matching-state.json",
      "sha256": "9a8c16e46f11c39578b2fe59fc84c8a0c56bd89167b6e083b3de4b83c3a1397b"
    }
  ],
  "observation_ids": [
    "obs-fa88a8eef246b7db"
  ],
  "exclusions": [
    {
      "id": "harvest-1",
      "kind": "feedback-harvest start/receipt"
    }
  ],
  "gaps": "Live runner compatibility unavailable; synthetic runner source accepted for artifact attribution only"
}
<!-- evidence:end harvest-1 -->
<!-- evidence:begin harvest-2 -->
feedback-harvest-started: harvest-2; execution_id: fixture-tasks-run; state: started
<!-- evidence:end harvest-2 -->
