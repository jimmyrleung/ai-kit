# BUG-1
## Expected behavior
- returns 2
## Proposed fix
Use corrected value.
