# Tasks
### Task 1
Files: value.py
#### Testing requirements
- [ ] Existing test green
#### Acceptance criteria
- [ ] AC-1: returns 2
#### Verify — old run
- [x] AC #9 old generated evidence
### Task 2
#### Acceptance criteria
- [ ] AC-2: returns 3
