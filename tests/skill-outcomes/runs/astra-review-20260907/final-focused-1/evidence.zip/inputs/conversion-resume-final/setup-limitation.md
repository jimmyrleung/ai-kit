# Resolved fixture identities

The supplied manifest used placeholder identities (`sha256:alpha`, `sha256:beta`, `sha256:cache`, `sha256:unknown`). Setup materialized the exact deterministic bytes under `bytes/`, computed full SHA-256 values, and wrote `conversion-manifest.tsv`. The original placeholder manifest is preserved separately. These resolved bytes and identities are the comparison fixture; refusing the placeholders is not graded as a skill defect.
