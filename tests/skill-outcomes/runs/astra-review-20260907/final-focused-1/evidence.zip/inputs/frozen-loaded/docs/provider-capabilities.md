# Provider capability reference

Checked 2026-09-07. Recheck after host, mode, account, or extension changes.
Model reasoning quality does not grant host tools. Resolve the capability from the
active tool catalog and documented interface, then record `available`, `blocked`,
or `unavailable` with the actual probe. Do not infer native discovery from a model
reciting a description supplied in its prompt.

| Decision | Claude Code | OpenAI / Codex | Cursor |
|---|---|---|---|
| Discovery | Documented personal `.claude/skills` and project roots; inspect observed catalog [1] | Documented `.agents/skills` user/project roots and linked folders; inspect observed catalog [2] | Documented skills roots and compatibility roots; identify duplicate source paths, without a precedence assumption [3] |
| Explicit invocation | Native skill name/command [1] | Native picker or `$skill` [2] | Native `/skill-name` [3] |
| Automatic selection | Description selection, subject to explicit-only settings and listing budget [1] | Description selection, subject to skill-local policy [2] | Description selection, subject to explicit-only overlay [3] |
| Questions | Use a structured question tool only if exposed and permitted in this mode; otherwise one concise text question | Same; neither provider name nor CLI version proves universal absence | Same |
| Delegation | Use an exposed native worker facility when authorized; otherwise record sequential coverage | Native subagents are documented; active authorization and tool availability still apply [4] | Native subagents are documented; active mode/tool availability still apply [5] |
| Worker model | Inherit effective session configuration unless a supported override is justified | Inspect actual spawn configuration; record effective model/reasoning, not just a requested override [4] | Documented inheritance; inspect actual configuration and fallbacks [5] |
| Goal / recurrence | Check installed runner, persistence, stop controls and authorization | Check actual goal/recurrence tools; manual continuation if absent | Check installed loop support and stop controls; manual continuation if absent [3] |
| Memory / feedback | Explicit store and recorder contract [6] | Same contract; no assumed private auto-memory API | Same contract; no required private conventions |

Sources opened on the check date:

1. [Claude skills](https://code.claude.com/docs/en/skills).
2. [OpenAI skill discovery and metadata](https://learn.chatgpt.com/docs/build-skills).
3. [Cursor skills](https://prod.cursor.com/docs/skills).
4. [OpenAI subagents](https://learn.chatgpt.com/docs/agent-configuration/subagents).
5. [Cursor subagents](https://prod.cursor.com/docs/subagents).
6. [Public feedback contract](contracts/feedback.md).

## Probe record and recovery

Record provider, host/version, mode, model/settings, source/input identity, operation,
discovery mechanism, expected/actual result, exit status, and durable output location.
Version probes in this execution: `codex --version` → `0.153.2`, `claude --version` →
`2.1.251`, `cursor-agent --version` → `2026.09.02-c22c1a3`. These establish installed
versions only. This session exposes structured questions, native workers, and a goal
tool; it does not establish those tools in every local CLI mode.

Pass literal input through an argument array or a UTF-8 prompt file on stdin. Inspect
the current command help first. Preserve the exact prompt or its digest and an input
echo/sentinel proving that quotes, newlines, `$()`, and backticks reached the intended
tool unchanged. Bound output, time, and writes to a disposable workspace; record
truncation and timeouts. A version or help probe is not a workflow outcome.

For a workflow tool that supplies script arguments, inspect its actual argument contract.
Parse JSON only when the tool supplies a JSON string; preserve an already structured object.
An earlier string/object mismatch is a reason to check that interface, not a universal wrapper
to paste into unrelated runtimes.

For long operations keep the actual process/session/worker handle and durable logs.
Poll a confirmed live handle after an observation timeout; don't start a duplicate
job merely because observation expired. Resume an existing worker when supported.
If recovery is unavailable, reassign its missing charter explicitly and keep completed
outputs. Other workers' agreement cannot cover a missing domain.

## Copied mechanics

`python3 scripts/check-mechanics-mirror.py --provider codex --file <private-file>`
compares only the delimited `kit-mechanics` block with the public adapter. It prints
status/digests, never private text, and never writes either file. An absent or ambiguous
block is unverified; a mismatch is drift. The owner controls any refresh of private
instructions. The common sync engine only manages skill links.
