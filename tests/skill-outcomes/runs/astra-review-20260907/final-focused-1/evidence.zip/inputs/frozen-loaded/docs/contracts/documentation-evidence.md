# Documentation roots and freshness evidence

Documentation skills use the repository-wide
[change-evidence contract](change-evidence.md) for byte identity. This contract adds the
roots, source inventory, and freshness states needed by generated documentation.

## Handoff record (version 1)

Resolve these values before tracing or writing:

- `source_root`: absolute root of the source repository; source access is read-only.
- `docs_root`: absolute root under which documentation may be written.
- `workspace_root`: absolute scan/tracing root inside `source_root` (equal to
  `source_root` for a single-repository workspace).
- `entry_reference`: workspace-relative path plus symbol, or the documented literal
  trigger when no symbol exists.
- `resolved_output`: absolute destination inside `docs_root`.

Generated tasks carry all five values. `resolved_output` is authoritative. A relative
`Files affected` value may remain as a human-readable compatibility field, but consumers
resolve it against `docs_root`, never the current directory or `source_root`. An ad-hoc run
without a generated task defaults `docs_root` to the source repository's git root and then
derives `resolved_output` from the skill's normal layout. Ask when either root is ambiguous.

## Source evidence record (version 1)

Each generated document records:

- one public-safe source ID per repository or independently changing module source;
- the source's repository root or stable source locator, resolved full revision (when
  available), and whether that revision is an ancestor of the current revision;
- the relevant staged, unstaged, and untracked paths at generation time;
- a sorted manifest of source ID, source-root-relative path, role, and SHA-256 of the actual
  bytes read; and
- the registration, dispatch, routing, project, workspace, orchestration, and configuration
  inputs that control whether the documented entry point or Terraform root exists.

Use the manifest rules and public-safe repository identity from the change-evidence
contract. A short SHA may remain in a display summary, but it is not the evidence identity.
Never use one repository's revision to identify source read from another repository.

Manifest paths, dirty paths, and trace-boundary patterns resolve from the root/locator
recorded for their Source ID. For a repository Source ID, include the workspace prefix:
source root `/repo`, workspace `/repo/apps/api`, and entry `src/handler.ts` produce manifest
path `apps/api/src/handler.ts`. The handoff's `entry_reference` remains workspace-relative;
it is a different field. Never guess a missing manifest path base in an older document:
mark the affected source Unverifiable and retrace it.

## Freshness states

- `Current`: every recorded source is readable; each recorded revision exists and is an
  ancestor of the current revision; all relevant manifest bytes still match; no relevant
  staged, unstaged, or untracked source differs; and no controlling input indicates that
  the trace boundary must be rediscovered.
- `Stale`: a known relevant source byte changed, a source was moved/deleted, a new or changed
  controlling input can change registration/dispatch/topology, or the recorded output no
  longer represents the same entry/root boundary.
- `Unverifiable`: identity is missing, a revision is inaccessible or is not an ancestor,
  a source/module is unreadable, the manifest is absent, or an unsupported/dynamic boundary
  prevents the claimed scope from being checked.

Use revision history only to shortlist candidate changes. An empty path-limited log does not
prove `Current`: compare actual bytes and relevant dirty state. Conversely, unrelated changes
outside the recorded sources and controlling inputs do not make a document stale. Preserve a
truly unchanged document byte-for-byte, including its dates.

## Schema changes and legacy documents

Adding or changing required Summary, Source Evidence, Source Files, or evidence-state fields
changes the stable document shape and requires a schema-version bump. Older documents remain
readable, but their revision-only freshness is `Unverifiable` until a full retrace/regeneration
creates the current evidence record. Never manufacture missing historical byte identity.
