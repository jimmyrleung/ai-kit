# Fixture tasks

<!-- close-tasks: harvested through abc123 @ 2026-09-06 -->

## Task 1 — repository change

**Status:** Done
**Lifecycle:** pre-merge

### Verify

- Gate 1: pass
- Gate 3: FAIL — accepted: fixture environment differs

## Task 2 — live rehearsal

**Status:** Todo
**Lifecycle:** live

