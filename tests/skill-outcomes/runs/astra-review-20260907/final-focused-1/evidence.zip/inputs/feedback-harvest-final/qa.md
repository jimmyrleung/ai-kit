# Fixture QA

**Recommendation:** go
**Scope:** repository

