# Get a widget

## Summary

Created: 2026-08-01. Legacy schema unspecified.

Returns a widget identifier. No source revision or byte manifest was recorded.
