# Get a widget

## Summary

| Field | Value |
| --- | --- |
| Created | 2026-09-07 |
| Last Updated | 2026-09-07 |
| Generated From | unknown |
| Schema | v2 |
| Source Root | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/detectors/source |
| Docs Root | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/legacy-workflow/regenerated-v2 |
| Workspace Root | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/detectors/source/express |
| Mode | Backend |
| Trigger | REST GET /api/v1/widgets/:id |
| Entry Point | widgets.js:getWidget |
| Success Response | JSON { id: req.params.id }, default 200 |
| Cross-Service | No observed outbound call |
| Business Rules | Echoes the route identifier |
| Complex Logic | No |

## Sequence of Calls

```text
app.use(/api, v1Router) [express/app.js:4]
  → v1Router.use(/v1, widgetsRouter) [express/routes.js:4]
    → widgetsRouter.get(/widgets/:id, getWidget) [express/widgets.js:5]
      → res.json({id:req.params.id}) [express/widgets.js:3]
```

## Flow Description

The literal mounts compose `/api/v1/widgets/:id`. The handler returns the path identifier as JSON. There is no data lookup, explicit validation branch or outbound call in its body. Dynamic health mounting is outside this traced entry and remains unresolved.

## Data Inventory

### Inputs

`req.params.id` is the route parameter.

### Outputs

JSON object with `id`. No data store access in this handler.

## Business Rules

The supplied identifier is echoed without conversion (`express/widgets.js:3`).

## Configuration

Literal mount prefixes `/api` and `/v1`; Express dependency declared in `express/package.json`. No auth middleware is present in the enumerated fixture source.

## Dependencies

Express Router and response JSON API; package metadata only, dependency installation/runtime untested.

## Source Evidence

| Source ID | Root / package | Subdirectory | Full revision | Trace boundary | Staged / unstaged / untracked | Manifest SHA-256 |
| --- | --- | --- | --- | --- | --- | --- |
| fixture-source | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/detectors/source | . | unknown (unborn Git repository) | All enumerated fixture files; static source only | staged none; unstaged none; untracked `AGENTS.md`, `express/app.js`, `express/package.json`, `express/routes.js`, `express/widgets.js`, `fastify/api.js`, `fastify/app.js`, `fastify/package.json`, `fastify/widgets.js`, `nest/controller.ts`, `nest/main.ts`, `nest/module.ts`, `nest/package.json`, `next/app/(admin)/api/items/route.ts`, `next/next.config.mjs`, `next/package.json`, `next/pages/api/declared.ts`, `next/src/app/actions.ts`, `next/src/app/api/forward/route.ts`, `next/src/app/editor.ts`, `next/src/app/not-a-prologue.ts`, `next/src/pages/api/expression.ts`, `next/src/pages/api/identifier.ts`, `package.json` | baa92623e383bac49ffa1de34c26984f5cb0d386ac169d39b2adb2c2fcd90084 |

Revision-based freshness: **Unverifiable**. The source-byte manifest is available; no ancestry or deployed-state claim is made. Manifest serialization: sorted source-relative path, TAB, SHA-256, LF.

## Source Files

| Source ID | Role | Path | SHA-256 |
| --- | --- | --- | --- |
| fixture-source | inspected source/config | AGENTS.md | 7aa2cb4e84cb12d752f1107d204ae1b6cffb1434c898a44231b1f29719e35620 |
| fixture-source | inspected source/config | express/app.js | bf95a49944dbbf4f7d485d7f2adcd8e06368fc457d5a3a342bc0d70f42571c45 |
| fixture-source | inspected source/config | express/package.json | 8f9845d9699abd40bd2b5ad30804423f8e1d4a5550c0c63d1467c1348302b03e |
| fixture-source | inspected source/config | express/routes.js | 093bae6361b2dc2a765c67f7e5b32c466e5c6e8ac87c83298312d707846605f4 |
| fixture-source | inspected source/config | express/widgets.js | a9bebf6be136c6fc4bef8e4ed98b106e95a1b158efa830fffb073f6c065ec173 |
| fixture-source | inspected source/config | fastify/api.js | d1df88befc499c5d5bf5168c7276b0ca76422b659122407dd04ef4130d225667 |
| fixture-source | inspected source/config | fastify/app.js | 7b2ffd6a9d404d137fd4551e9c5bbaabdafd94ebf3397212733b6ad27d873e71 |
| fixture-source | inspected source/config | fastify/package.json | ba6a6769baeb456821eb9ea01014ab8ca1b9cdf70442eb54807c53e6b94f5027 |
| fixture-source | inspected source/config | fastify/widgets.js | 8e471b580c74977ba3615486ead63c400439fa889a5c2375da913c1525609dd3 |
| fixture-source | inspected source/config | nest/controller.ts | 558e6d9528918ac3beea5f28ec438461913c889668b4482195463e9bf8e688ec |
| fixture-source | inspected source/config | nest/main.ts | 91173a8ea2b7009220a9c6dc40dd4c5582f351afa9d748cdbb8ddf1157299b5c |
| fixture-source | inspected source/config | nest/module.ts | 211fe913f05b076ddc58ec2210eba809c31434fd3940c42536df1555495edf66 |
| fixture-source | inspected source/config | nest/package.json | f40f65d0021dfdc80b54bc0ff6aa3a2be1f404f284435b8bd3e54aa14c663de3 |
| fixture-source | inspected source/config | next/app/(admin)/api/items/route.ts | 8634e5635a88fc225b0ef776f436beb124f47913084c1263191dc87b5dccadf4 |
| fixture-source | inspected source/config | next/next.config.mjs | 450f0af4f4c1ecc4c7180f2e364c8a59bfed69dd350fb6b47bce8641c2a37786 |
| fixture-source | inspected source/config | next/package.json | 2e7f71495e99fdb5be24a1e91f9bebd7aebad3c089f4e3d5e779da059d370852 |
| fixture-source | inspected source/config | next/pages/api/declared.ts | 6c67292c620f031b6ba23dcce4c35d04d08ffc7dc75c0e66813bb6302a7c5e21 |
| fixture-source | inspected source/config | next/src/app/actions.ts | 35ba8864082596ec73526e4730c55486f32bd63ae4ba338726608b0df9fbe3be |
| fixture-source | inspected source/config | next/src/app/api/forward/route.ts | b1c281a0735833d9d6ca50d3c9ec6a774f5a9ec428ae95ffb5e78c52d6de92fe |
| fixture-source | inspected source/config | next/src/app/editor.ts | 97a235b708600cd925595875405a9dc4551e24e1251f688aea5f62a7f1d5cfa8 |
| fixture-source | inspected source/config | next/src/app/not-a-prologue.ts | c441db74b7a1d8205ead50d14cd639fb957ebeae371724aef5d44e4b96e70342 |
| fixture-source | inspected source/config | next/src/pages/api/expression.ts | cf00a27f61e5851a0c924777627c2c37e49241b92fb625f2d5bf1dddb437ca91 |
| fixture-source | inspected source/config | next/src/pages/api/identifier.ts | dd9dc4345fbdad5408e37abf981e4c22cd3df2c1df205b89afb4f1672248bc08 |
| fixture-source | inspected source/config | package.json | 05ddbcb27636f05e2e329db388ef06cda601e8d97cca134c0377423c0583652d |

## Change Log

| Date | Change |
| --- | --- |
| 2026-09-07 | Full retrace from legacy schema-unspecified record; original preserved at ../legacy/get-widget.md. |
