"""One artifact review correction and byte/path validation; does not execute another trial."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
R=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
G=R/'grouping';p=G/'docs/_docs-tasks.md';old=p.read_text()
(G/'first-draft.md').write_text(old)
timer=re.search(r'## Task 8 .*?(?=\n## Task |\Z)',old,re.S).group()
seed=(G/'seed.md').read_text()
retired=re.search(r'## Task 8 .*?(?=\n## Task |\Z)',seed,re.S).group().replace('**Status:** Todo','**Status:** Review retirement')
newtimer=timer.replace('Task 8','Task 10').replace('Utility.Heartbeat','HealthChecks.Heartbeat')
newtimer=newtimer[:newtimer.index('**Acceptance criteria:**')]+'''**Acceptance criteria:**
- A workflow doc exists exactly at the task's `Resolved output`.
- The doc follows the `document-workflow` output format (Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies).
- Backend mode.

'''
new=old.replace(timer,newtimer).replace('| 8 | Document heartbeat','| 10 | Document heartbeat').replace('Health.cs:Utility.Health','Health.cs:HealthChecks.Health').replace('Orchestration.cs:OrderFlow.Run','Orchestration.cs:OrderFlow.Process').replace('Activity.cs:OrderActivities.Record','Activity.cs:OrderActivity.Record')
new+='\n## Retired workflows — review required\n\nPossible rename: `functions:timer:0 */5 * * * *:Utility.Heartbeat` → `functions:timer:0 */5 * * * *:HealthChecks.Heartbeat`. The seed references an absent class; preserve its notes here and do not transfer evidence without owner review.\n\n'+retired
p.write_text(new)
(G/'refresh-report.md').write_text('''# Inventory refresh and artifact inspection

The source was inspected once and the generated inventory was corrected during artifact review. No second model trial or changed-source execution occurred. The first draft is preserved in `first-draft.md`.

- `functions:http:post:/orders` retains task 7, Done, acceptance text, dated fixture evidence, and manual note byte-for-byte outside the generated block. Its members now resolve to `Start.cs:OrderStart.Start`, `Orchestration.cs:OrderFlow.Process`, and `Activity.cs:OrderActivity.Record`.
- Independent Health and Heartbeat entries share `Health.cs` but remain two tasks. Health is new task 9; the current `HealthChecks.Heartbeat` identity is new task 10, both Todo.
- The supplied seed used the nonexistent old `Utility.Heartbeat` identity. Its old task 8 and manual note remain under Retired workflows with Review retirement. Possible rename is explicit; no completion/history transfers to the new timer identity. This is a fixture-authoring defect, not an observed repository regression.
- The first draft also mirrored stale/incorrect member symbols (`OrderFlow.Run`, `OrderActivities.Record`); current source bodies provided the correction. These findings prevent treating this informed artifact-writing pass as independent model-success proof.

Seeded Done/Verify text is synthetic historical input, not a claim of an actual earlier tasks run. Static named edges prove StartOrder → ProcessOrder → RecordOrder across three files. They establish one connected documentation boundary; runtime orchestration was not executed.
''')
scrub=lambda s:re.sub(r'<!-- inventory:begin -->.*?<!-- inventory:end -->','',s,flags=re.S)
section=lambda t,n:re.search(r'## Task '+str(n)+r' .*?(?=\n## Task |\n## Retired workflows |\Z)',t,re.S).group().strip()
checks=[]
before=section(seed,7);after=section(new,7)
checks.append({'check':'connected task history outside inventory','before_sha256':sha(scrub(before).encode()),'after_sha256':sha(scrub(after).encode()),'observed_equal':scrub(before)==scrub(after)})
task_files=list((R/'detectors/docs').glob('*/_docs-tasks.md'))+[p]
resolved=[];refs=[];counts={}
for tf in task_files:
    data=tf.read_text().split('## Retired workflows')[0]
    sections=re.findall(r'## Task \d+.*?(?=\n## Task |\Z)',data,re.S)
    counts[str(tf)]=len(sections)
    for sec in sections:
        fields=dict(re.findall(r'\*\*([^*]+):\*\* `([^`]+)`',sec))
        docs=Path(fields['Docs root']);out=Path(fields['Resolved output'])
        resolved.append({'tasks':str(tf),'workflow_id':fields['Workflow ID'],'docs_root':str(docs),'resolved_output':str(out),'contained':out.is_relative_to(docs),'relative_output_matches':str(out.relative_to(docs))==fields['Files affected']})
        reference=fields['Reference'];workspace=Path(fields['Workspace root'])
        if re.match(r'.+\.(ts|js|cs):',reference):
            name,symbol=reference.rsplit(':',1);source=workspace/name;text=source.read_text()
            tokens=symbol.split('.')
            refs.append({'reference':reference,'source':str(source),'source_sha256':sha(source.read_bytes()),'symbol_tokens_present':all(re.search(r'\b'+re.escape(t)+r'\b',text) for t in tokens) is not None and all(bool(re.search(r'\b'+re.escape(t)+r'\b',text)) for t in tokens)})
        for name,symbol in re.findall(r'`([^`]+\.cs):([^`]+)`',sec):
            source=workspace/name;text=source.read_text()
            refs.append({'reference':name+':'+symbol,'source':str(source),'source_sha256':sha(source.read_bytes()),'symbol_tokens_present':all(bool(re.search(r'\b'+re.escape(t)+r'\b',text)) for t in symbol.split('.'))})
manifestchecks=[]
for doc in list((R/'terraform').rglob('*.md'))+[R/'legacy-workflow/regenerated-v2/get-widget.md']:
    data=doc.read_text()
    if '## Source Files' not in data:continue
    root=Path(re.search(r'\| Source Root \| ([^|]+) \|',data).group(1).strip())
    rows=re.findall(r'\| fixture-source \| inspected source/config \| ([^|]+) \| ([a-f0-9]{64}) \|',data)
    for rel,expected in rows:
        actual=sha((root/rel.strip()).read_bytes())
        manifestchecks.append({'document':str(doc),'path':str(root/rel.strip()),'recorded_sha256':expected,'actual_sha256':actual,'equal':actual==expected})
sourcechecks=[]
for row in json.loads((R/'inputs.json').read_text())['source_files']:
    actual=sha((Path(row['root'])/row['path']).read_bytes());sourcechecks.append({**row,'actual_sha256':actual,'unchanged':actual==row['sha256']})
artifacts=[]
for f in sorted(R.rglob('*')):
    if not f.is_file() or '.git' in f.parts or 'frozen-inputs' in f.parts:continue
    artifacts.append({'path':str(f),'sha256':sha(f.read_bytes())})
results={'captured_at':datetime.now(timezone.utc).isoformat(),'kind':'artifact review, one correction, independent byte/path/reference checks; no second trial','artifact_correction':'grouping source symbols corrected; old unmatched timer ID retired with possible rename and note preserved','counts_from_files':counts,'history_checks':checks,'source_checks':sourcechecks,'task_output_boundaries':resolved,'source_reference_checks':refs,'document_manifest_checks':manifestchecks,'artifacts':artifacts,'first_execution_results':'execution-results.json preserves pre-correction output hashes; this file binds final artifacts'}
(R/'verification.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'task_counts':counts,'source_unchanged':sum(x['unchanged'] for x in sourcechecks),'source_total':len(sourcechecks),'history_checks':checks,'task_boundaries':len(resolved),'task_boundaries_valid':all(x['contained'] and x['relative_output_matches'] for x in resolved),'source_reference_checks':len(refs),'source_references_valid':all(x['symbol_tokens_present'] for x in refs),'document_hash_checks':len(manifestchecks),'document_hashes_equal':all(x['equal'] for x in manifestchecks)},indent=2))
