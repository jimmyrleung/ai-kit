using Microsoft.Azure.Functions.Worker;
public class OrderActivity {
  [Function("RecordOrder")]
  public string Record([ActivityTrigger] string orderId) { return orderId; }
}
