using Microsoft.Azure.Functions.Worker;
using Microsoft.DurableTask.Client;
public class OrderStart {
  [Function("StartOrder")]
  public async Task<string> Start([HttpTrigger(AuthorizationLevel.Function, "post", Route="orders")] object request, [DurableClient] DurableTaskClient client) {
    return await client.ScheduleNewOrchestrationInstanceAsync("ProcessOrder", "order-42");
  }
}
