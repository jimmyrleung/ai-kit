Treat literal Durable start/orchestration/activity edges as one workflow. Keep unrelated functions separate. Preserve task status and manual notes on refresh.
