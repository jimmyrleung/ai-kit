using Microsoft.Azure.Functions.Worker;
using Microsoft.DurableTask;
public class OrderFlow {
  [Function("ProcessOrder")]
  public async Task<string> Process([OrchestrationTrigger] TaskOrchestrationContext context) {
    return await context.CallActivityAsync<string>("RecordOrder", context.GetInput<string>());
  }
}
