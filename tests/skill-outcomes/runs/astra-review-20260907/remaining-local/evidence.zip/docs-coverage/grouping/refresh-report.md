# Inventory refresh and artifact inspection

The source was inspected once and the generated inventory was corrected during artifact review. No second model trial or changed-source execution occurred. The first draft is preserved in `first-draft.md`.

- `functions:http:post:/orders` retains task 7, Done, acceptance text, dated fixture evidence, and manual note byte-for-byte outside the generated block. Its members now resolve to `Start.cs:OrderStart.Start`, `Orchestration.cs:OrderFlow.Process`, and `Activity.cs:OrderActivity.Record`.
- Independent Health and Heartbeat entries share `Health.cs` but remain two tasks. Health is new task 9; the current `HealthChecks.Heartbeat` identity is new task 10, both Todo.
- The supplied seed used the nonexistent old `Utility.Heartbeat` identity. Its old task 8 and manual note remain under Retired workflows with Review retirement. Possible rename is explicit; no completion/history transfers to the new timer identity. This is a fixture-authoring defect, not an observed repository regression.
- The first draft also mirrored stale/incorrect member symbols (`OrderFlow.Run`, `OrderActivities.Record`); current source bodies provided the correction. These findings prevent treating this informed artifact-writing pass as independent model-success proof.

Seeded Done/Verify text is synthetic historical input, not a claim of an actual earlier tasks run. Static named edges prove StartOrder → ProcessOrder → RecordOrder across three files. They establish one connected documentation boundary; runtime orchestration was not executed.
