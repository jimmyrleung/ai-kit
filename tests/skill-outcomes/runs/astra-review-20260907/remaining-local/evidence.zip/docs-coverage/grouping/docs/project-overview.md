# Functions — Project Overview

## Summary

| Field | Value |
| --- | --- |
| Path | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/grouping/source |
| Stack(s) | Azure Functions isolated / Durable declarations |
| Services | 1 (functions) |
| Entry points | 3 workflow boundaries: 2 HTTP, 1 timer; 5 decorated member functions |

## Top-level layout

- `Start.cs` — HTTP starter.
- `Orchestration.cs` — named orchestration.
- `Activity.cs` — named activity.
- `Health.cs` — unrelated HTTP and timer.
- `Functions.csproj` — framework signal.

## Build / Run

No execution undertaken; the source fixture does not supply a runnable Functions host or Durable storage.

## Services

### functions

- Path: `.`
- Entry points: 3 workflow boundaries.
- Stack: Azure Functions isolated.

## Scan coverage

| Detector | State | Roots/patterns searched | Boundary |
| --- | --- | --- | --- |
| Azure Functions isolated | Covered | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/grouping/source/*.cs; Function, HttpTrigger, TimerTrigger, OrchestrationTrigger, ActivityTrigger, named call edges | Static attributes and named grouping edges inspected; FunctionName coverage remains in original trial, not claimed anew here |

## Notes

Health and Heartbeat share a file but have unrelated triggers; they remain separate. StartOrder, ProcessOrder and RecordOrder have two explicit named edges across three files, so they remain one workflow.
