using Microsoft.Azure.Functions.Worker;
public class HealthChecks {
  [Function("Health")]
  public string Health([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route="health")] object request) { return "ok"; }
  [Function("Heartbeat")]
  public string Heartbeat([TimerTrigger("0 */5 * * * *")] object timer) { return "alive"; }
}
