import { Router } from 'express';
import { widgetsRouter } from './widgets.js';
export const v1Router = Router();
v1Router.use('/v1', widgetsRouter);
export const healthRouter = Router();
healthRouter.get('/health', (req, res) => res.json({ok: true}));
