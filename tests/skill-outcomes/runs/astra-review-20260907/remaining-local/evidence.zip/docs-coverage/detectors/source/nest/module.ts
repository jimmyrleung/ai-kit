import { Module } from '@nestjs/common';
import { WidgetsController, AdminController } from './controller';
@Module({controllers: [WidgetsController, AdminController]})
export class AppModule {}
