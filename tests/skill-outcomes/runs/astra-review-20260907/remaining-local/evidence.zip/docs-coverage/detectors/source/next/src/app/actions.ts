// Module actions; comment before directive is allowed.
'use server';
export async function archiveItem(id: string) { return {archived: id}; }
export const restoreItem = async (id: string) => ({restored: id});
