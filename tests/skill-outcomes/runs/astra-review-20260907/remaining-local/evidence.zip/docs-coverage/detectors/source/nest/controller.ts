import { Controller, Get, Post, Param } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
@Controller('widgets')
export class WidgetsController {
  @Get(':id')
  get(@Param('id') id: string) { return {id}; }
  @Post()
  create() { return {created: true}; }
  @MessagePattern('widgets.created')
  onCreated(message: {id: string}) { return message.id; }
}
@Controller(process.env.ADMIN_PREFIX)
export class AdminController {
  @Get('health')
  health() { return {ok: true}; }
}
