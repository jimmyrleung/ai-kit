export default function declared(req, res) { res.json({ok: true}); }
