Inspect every selected workspace. Write documentation only under the explicit external docs root. Framework execution is not requested. Preserve partial dynamic registrations.
