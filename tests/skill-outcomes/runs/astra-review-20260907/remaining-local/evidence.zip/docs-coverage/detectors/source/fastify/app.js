import Fastify from 'fastify';
import api from './api.js';
import widgets from './widgets.js';
const app = Fastify();
app.register(api, {prefix: '/api'});
app.register(widgets, {prefix: process.env.EXTRA_PREFIX});
export default app;
