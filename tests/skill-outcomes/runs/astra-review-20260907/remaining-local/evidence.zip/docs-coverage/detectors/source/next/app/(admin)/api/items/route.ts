export function GET() { return Response.json({items: []}); }
export async function POST() { return Response.json({created: true}); }
export const PATCH = async () => Response.json({changed: true});
