export default async function widgets(fastify) {
  fastify.route({method: ['GET', 'HEAD'], url: '/widgets/:id', handler: async (request) => ({id: request.params.id})});
  fastify.post('/widgets', async () => ({created: true}));
}
