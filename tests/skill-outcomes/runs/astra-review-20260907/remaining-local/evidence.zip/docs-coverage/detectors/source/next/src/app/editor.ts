export async function saveItem(id: string) {
  'use server';
  return {saved: id};
}
export function formatTitle(title: string) { return title.trim(); }
