import { Router } from 'express';
export const widgetsRouter = Router();
export function getWidget(req, res) { return res.json({id: req.params.id}); }
export function createWidget(req, res) { return res.status(201).json({created: true}); }
widgetsRouter.get('/widgets/:id', getWidget);
widgetsRouter.post('/widgets', createWidget);
