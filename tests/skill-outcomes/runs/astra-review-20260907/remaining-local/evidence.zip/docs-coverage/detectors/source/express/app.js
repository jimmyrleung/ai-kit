import express from 'express';
import { v1Router, healthRouter } from './routes.js';
const app = express();
app.use('/api', v1Router);
app.use(process.env.EXTRA_PREFIX, healthRouter);
export default app;
