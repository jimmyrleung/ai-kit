const mode = 'edit';
'use server';
export async function ambiguousAction() { return mode; }
