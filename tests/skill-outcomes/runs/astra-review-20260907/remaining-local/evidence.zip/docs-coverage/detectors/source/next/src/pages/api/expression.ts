export default (req, res) => res.json({id: 2});
