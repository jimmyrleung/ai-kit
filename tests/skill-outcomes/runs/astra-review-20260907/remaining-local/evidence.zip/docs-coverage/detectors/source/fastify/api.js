import widgets from './widgets.js';
export default async function api(fastify) {
  fastify.register(widgets, {prefix: '/v2'});
}
