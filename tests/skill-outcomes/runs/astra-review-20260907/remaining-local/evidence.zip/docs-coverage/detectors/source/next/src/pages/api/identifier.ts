function handler(req, res) { res.json({id: 1}); }
export default handler;
