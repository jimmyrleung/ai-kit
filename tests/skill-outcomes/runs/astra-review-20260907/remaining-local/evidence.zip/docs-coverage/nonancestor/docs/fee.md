# Calculate fee

## Summary

| Field | Value |
| --- | --- |
| Created | 2026-08-01 |
| Last Updated | 2026-08-01 |
| Generated From | bcd7f716b742 |
| Schema | v2 |
| Source Root | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/nonancestor/source |
| Docs Root | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/nonancestor/docs |
| Workspace Root | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/nonancestor/source |
| Mode | Backend |
| Trigger | Function call fee(amount) |
| Entry Point | calc.py:fee |
| Success Response | amount * 0.02 |
| Cross-Service | No |
| Business Rules | Negative values rejected |
| Complex Logic | No |

## Source Evidence

| Source ID | Full revision | Trace boundary | Dirty paths |
| --- | --- | --- | --- |
| fee-source | bcd7f716b742f3bfd2683f17ca1e04d46edc4d87 | calc.py | none recorded |

## Source Files

| Source ID | Role | Path | SHA-256 |
| --- | --- | --- | --- |
| fee-source | entry | calc.py | 31c17039c0b3705d1816ae7f918560685f9b5e3fa4616a3fb7e0af5f90a96214 |

## Change Log

| Date | Change |
| --- | --- |
| 2026-08-01 | Recorded negative-value guard. |
