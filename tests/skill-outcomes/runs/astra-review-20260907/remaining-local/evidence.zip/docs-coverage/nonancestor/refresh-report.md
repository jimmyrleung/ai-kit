# Fee freshness result

**Unverifiable**: the recorded full revision exists (`cat-file` returns commit), but is not an ancestor of current HEAD (`merge-base --is-ancestor` exit 1). The source manifest is historical; no false Current classification and no incremental content edit. Full retrace is needed before a new current-state document.

Recorded: `bcd7f716b742f3bfd2683f17ca1e04d46edc4d87`. Current: `8baddca5be6909f1b04d4da76e733e5cbdf0a07d`.
