from pathlib import Path
import datetime,hashlib,json,subprocess
R=Path('/tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage')
F=Path('/tmp/astra-backlog-5VdqNm/final-post-review-frozen')
commands=[]
def command(args,cwd=R):
 p=subprocess.run(args,cwd=cwd,text=True,capture_output=True);commands.append({'argv':args,'cwd':str(cwd),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});return p
def write(path,text):
 p=R/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
files={
'detectors/source/package.json':'{"private":true,"workspaces":["express","fastify","nest","next"]}\n',
'detectors/source/AGENTS.md':'Inspect every selected workspace. Write documentation only under the explicit external docs root. Framework execution is not requested. Preserve partial dynamic registrations.\n',
'detectors/source/express/package.json':'{"name":"widgets-express","type":"module","dependencies":{"express":"^5.0.0"}}\n',
'detectors/source/express/app.js':'''import express from 'express';
import { v1Router, healthRouter } from './routes.js';
const app = express();
app.use('/api', v1Router);
app.use(process.env.EXTRA_PREFIX, healthRouter);
export default app;
''',
'detectors/source/express/routes.js':'''import { Router } from 'express';
import { widgetsRouter } from './widgets.js';
export const v1Router = Router();
v1Router.use('/v1', widgetsRouter);
export const healthRouter = Router();
healthRouter.get('/health', (req, res) => res.json({ok: true}));
''',
'detectors/source/express/widgets.js':'''import { Router } from 'express';
export const widgetsRouter = Router();
export function getWidget(req, res) { return res.json({id: req.params.id}); }
export function createWidget(req, res) { return res.status(201).json({created: true}); }
widgetsRouter.get('/widgets/:id', getWidget);
widgetsRouter.post('/widgets', createWidget);
''',
'detectors/source/fastify/package.json':'{"name":"widgets-fastify","type":"module","dependencies":{"fastify":"^5.0.0"}}\n',
'detectors/source/fastify/app.js':'''import Fastify from 'fastify';
import api from './api.js';
import widgets from './widgets.js';
const app = Fastify();
app.register(api, {prefix: '/api'});
app.register(widgets, {prefix: process.env.EXTRA_PREFIX});
export default app;
''',
'detectors/source/fastify/api.js':'''import widgets from './widgets.js';
export default async function api(fastify) {
  fastify.register(widgets, {prefix: '/v2'});
}
''',
'detectors/source/fastify/widgets.js':'''export default async function widgets(fastify) {
  fastify.route({method: ['GET', 'HEAD'], url: '/widgets/:id', handler: async (request) => ({id: request.params.id})});
  fastify.post('/widgets', async () => ({created: true}));
}
''',
'detectors/source/nest/package.json':'{"name":"widgets-nest","dependencies":{"@nestjs/core":"^11.0.0","@nestjs/common":"^11.0.0","@nestjs/microservices":"^11.0.0"}}\n',
'detectors/source/nest/main.ts':'''import { NestFactory } from '@nestjs/core';
import { AppModule } from './module';
async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.setGlobalPrefix('api');
  await app.listen(3000);
}
bootstrap();
''',
'detectors/source/nest/module.ts':'''import { Module } from '@nestjs/common';
import { WidgetsController, AdminController } from './controller';
@Module({controllers: [WidgetsController, AdminController]})
export class AppModule {}
''',
'detectors/source/nest/controller.ts':'''import { Controller, Get, Post, Param } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
@Controller('widgets')
export class WidgetsController {
  @Get(':id')
  get(@Param('id') id: string) { return {id}; }
  @Post()
  create() { return {created: true}; }
  @MessagePattern('widgets.created')
  onCreated(message: {id: string}) { return message.id; }
}
@Controller(process.env.ADMIN_PREFIX)
export class AdminController {
  @Get('health')
  health() { return {ok: true}; }
}
''',
'detectors/source/next/package.json':'{"name":"widgets-next","dependencies":{"next":"^15.0.0"}}\n',
'detectors/source/next/next.config.mjs':'export default {};\n',
'detectors/source/next/app/(admin)/api/items/route.ts':'''export function GET() { return Response.json({items: []}); }
export async function POST() { return Response.json({created: true}); }
export const PATCH = async () => Response.json({changed: true});
''',
'detectors/source/next/src/app/actions.ts':'''// Module actions; comment before directive is allowed.
'use server';
export async function archiveItem(id: string) { return {archived: id}; }
export const restoreItem = async (id: string) => ({restored: id});
''',
'detectors/source/next/src/app/editor.ts':'''export async function saveItem(id: string) {
  'use server';
  return {saved: id};
}
export function formatTitle(title: string) { return title.trim(); }
''',
'detectors/source/next/src/app/api/forward/route.ts':"export { GET } from '../../../../app/(admin)/api/items/route';\n",
'detectors/source/next/src/app/not-a-prologue.ts':'''const mode = 'edit';
'use server';
export async function ambiguousAction() { return mode; }
''',
'detectors/source/next/pages/api/declared.ts':'''export default function declared(req, res) { res.json({ok: true}); }
''',
'detectors/source/next/src/pages/api/identifier.ts':'''function handler(req, res) { res.json({id: 1}); }
export default handler;
''',
'detectors/source/next/src/pages/api/expression.ts':'''export default (req, res) => res.json({id: 2});
''',
'terraform/source/AGENTS.md':'Documentation may be written under the supplied docs root, inside or outside this repository. Infrastructure source is read-only. Do not run init, plan, apply, or cloud probes.\n',
'terraform/source/main.tf':'''terraform { required_version = ">= 1.4.0" }
variable "environment" { type = string }
module "catalog" {
  source = "./modules/catalog"
  label  = "${var.environment}-catalog"
}
output "catalog_label" { value = module.catalog.label }
''',
'terraform/source/dev.tfvars':'environment = "dev"\n',
'terraform/source/prod.tfvars':'environment = "prod"\n',
'terraform/source/modules/catalog/main.tf':'''variable "label" { type = string }
resource "terraform_data" "catalog" { input = var.label }
output "label" { value = terraform_data.catalog.output }
''',
'grouping/source/Functions.csproj':'<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net8.0</TargetFramework></PropertyGroup><ItemGroup><PackageReference Include="Microsoft.Azure.Functions.Worker" Version="1.21.0" /></ItemGroup></Project>\n',
'grouping/source/Start.cs':'''using Microsoft.Azure.Functions.Worker;
using Microsoft.DurableTask.Client;
public class OrderStart {
  [Function("StartOrder")]
  public async Task<string> Start([HttpTrigger(AuthorizationLevel.Function, "post", Route="orders")] object request, [DurableClient] DurableTaskClient client) {
    return await client.ScheduleNewOrchestrationInstanceAsync("ProcessOrder", "order-42");
  }
}
''',
'grouping/source/Orchestration.cs':'''using Microsoft.Azure.Functions.Worker;
using Microsoft.DurableTask;
public class OrderFlow {
  [Function("ProcessOrder")]
  public async Task<string> Process([OrchestrationTrigger] TaskOrchestrationContext context) {
    return await context.CallActivityAsync<string>("RecordOrder", context.GetInput<string>());
  }
}
''',
'grouping/source/Activity.cs':'''using Microsoft.Azure.Functions.Worker;
public class OrderActivity {
  [Function("RecordOrder")]
  public string Record([ActivityTrigger] string orderId) { return orderId; }
}
''',
'grouping/source/Health.cs':'''using Microsoft.Azure.Functions.Worker;
public class HealthChecks {
  [Function("Health")]
  public string Health([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route="health")] object request) { return "ok"; }
  [Function("Heartbeat")]
  public string Heartbeat([TimerTrigger("0 */5 * * * *")] object timer) { return "alive"; }
}
''',
'grouping/source/AGENTS.md':'Treat literal Durable start/orchestration/activity edges as one workflow. Keep unrelated functions separate. Preserve task status and manual notes on refresh.\n',
}
assert not (R/'inputs.json').exists(), 'do not overwrite an existing execution'
for name,text in files.items():write(name,text)
for name in ['detectors/source','terraform/source','grouping/source']:
 p=command(['git','init','--quiet',str(R/name)]);assert p.returncode==0
source=Path('/tmp/astra-backlog-5VdqNm/trials/engineering/candidate/1/fixtures/dirty-review')
dest=R/'nonancestor/source';dest.parent.mkdir(parents=True,exist_ok=True)
assert command(['git','clone','--no-hardlinks','--no-checkout',str(source),str(dest)]).returncode==0
later=command(['git','rev-parse','HEAD'],dest).stdout.strip();earlier=command(['git','rev-parse','HEAD^'],dest).stdout.strip()
assert command(['git','switch','--detach',earlier],dest).returncode==0
readable=command(['git','cat-file','-t',later],dest);ancestry=command(['git','merge-base','--is-ancestor',later,'HEAD'],dest)
assert readable.returncode==0 and readable.stdout.strip()=='commit';assert ancestry.returncode==1
write('nonancestor/identity.json',json.dumps({'recorded':later,'current':earlier,'recorded_exists':True,'ancestor_exit':ancestry.returncode,'note':'Both commits pre-existed; source clone detached to earlier revision; no commits created.'},indent=2)+'\n')
for name in ['skills/docs-tasks-creator/SKILL.md','skills/docs-tasks-creator/references/detectors.md','skills/document-workflow/SKILL.md','skills/document-workflow/references/output-template.md','skills/update-workflow-docs/SKILL.md','skills/document-terraform/SKILL.md','skills/document-terraform/reference/heuristics.md','docs/contracts/documentation-evidence.md','docs/contracts/change-evidence.md','docs/contracts/authorized-work.md']:
 b=(F/name).read_bytes();p=R/'frozen-inputs'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
snapshot=[]
for source_root in [R/'detectors/source',R/'terraform/source',R/'grouping/source',R/'nonancestor/source']:
 top=command(['git','rev-parse','--show-toplevel'],source_root);assert Path(top.stdout.strip())==source_root
 for f in sorted(source_root.rglob('*')):
  if f.is_file() and '.git' not in f.relative_to(source_root).parts:snapshot.append({'root':str(source_root),'path':str(f.relative_to(source_root)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
write('inputs.json',json.dumps({'kind':'informed local coverage completion; no comparison','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':snapshot,'frozen_manifest_sha256':hashlib.sha256((F/'manifest.json').read_bytes()).hexdigest(),'acceptance_ids':['B08.AC1','B08.AC6','B09.AC2','B10.AC3','B26.AC3'],'framework_execution':'not requested or performed; source-traced detector output only'},indent=2)+'\n')
write('setup-commands.json',json.dumps(commands,indent=2)+'\n')
print(json.dumps({'files_materialized':len(files),'source_files_captured':len(snapshot),'existing_nonancestor':later,'current':earlier,'ancestor_exit':ancestry.returncode},indent=2))
