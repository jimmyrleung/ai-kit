"""One informed execution of the frozen prose procedures, materializing source-traced docs.
This is an artifact writer, not a skill runner, generic detector, or model-success evaluator.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess

R=Path(__file__).parent
I=json.loads((R/'inputs.json').read_text())
commands=[]
outputs=[]
def digest(data): return hashlib.sha256(data).hexdigest()
def write(path, text):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(text);outputs.append(str(path))
def run(args):
    p=subprocess.run(args,capture_output=True,text=True)
    row={'argv':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    commands.append(row);return row
def table(headers,rows):
    return '| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |\n'+''.join('| '+' | '.join(str(x).replace('|','\\|') for x in row)+' |\n' for row in rows)
def snapshot(root): return [x for x in I['source_files'] if x['root']==str(root)]
def evidence(root):
    rows=snapshot(root)
    manifest=''.join(x['path']+'\t'+x['sha256']+'\n' for x in sorted(rows,key=lambda x:x['path']))
    names=', '.join('`'+x['path']+'`' for x in rows)
    return ('## Source Evidence\n\n'+table(['Source ID','Root / package','Subdirectory','Full revision','Trace boundary','Staged / unstaged / untracked','Manifest SHA-256'],[['fixture-source',str(root),'.','unknown (unborn Git repository)','All enumerated fixture files; static source only','staged none; unstaged none; untracked '+names,digest(manifest.encode())]])+'\nRevision-based freshness: **Unverifiable**. The source-byte manifest is available; no ancestry or deployed-state claim is made. Manifest serialization: sorted source-relative path, TAB, SHA-256, LF.\n\n')
def source_files(root):
    return '## Source Files\n\n'+table(['Source ID','Role','Path','SHA-256'],[['fixture-source','inspected source/config',x['path'],x['sha256']] for x in snapshot(root)])+'\n'
def summary(fields):return '## Summary\n\n'+table(['Field','Value'],fields)+'\n'

assert not (R/'execution-results.json').exists(),'one bounded execution only'
roots=sorted(set(x['root'] for x in I['source_files']))
for root in roots:
    run(['rg','--files','--hidden','-g','!.git',root])
    run(['git','-C',root,'status','--porcelain=v1','--untracked-files=all'])

# Informed detector scan: execute the recipe searches, then materialize the edges
# directly inspected in app/registration bodies. Dynamic branches stay Partial.
D=R/'detectors/source'
for ws in ['express','fastify','nest','next']:
    run(['rg','-n','use\(|register\(|setGlobalPrefix|Controller\(|MessagePattern|route\(|\.get\(|\.post\(|export|use server',str(D/ws)])
routes={
 'express':[
  ('widgets.get-by-id','http:get:/api/v1/widgets/:id','REST GET /api/v1/widgets/:id','widgets.js:getWidget','app.js:4 → routes.js:4 → widgets.js:5'),
  ('widgets.create','http:post:/api/v1/widgets','REST POST /api/v1/widgets','widgets.js:createWidget','app.js:4 → routes.js:4 → widgets.js:6')],
 'fastify':[
  ('widgets.get-by-id','http:get:/api/v2/widgets/:id','REST GET /api/v2/widgets/:id','GET /api/v2/widgets/:id','app.js:5 → api.js:3 → widgets.js:2'),
  ('widgets.head-by-id','http:head:/api/v2/widgets/:id','REST HEAD /api/v2/widgets/:id','HEAD /api/v2/widgets/:id','app.js:5 → api.js:3 → widgets.js:2'),
  ('widgets.create','http:post:/api/v2/widgets','REST POST /api/v2/widgets','POST /api/v2/widgets','app.js:5 → api.js:3 → widgets.js:3')],
 'nest':[
  ('widgets.get-by-id','http:get:/api/widgets/:id','REST GET /api/widgets/:id','controller.ts:WidgetsController.get','main.ts:5 → module.ts:3 → controller.ts:3,5'),
  ('widgets.create','http:post:/api/widgets','REST POST /api/widgets','controller.ts:WidgetsController.create','main.ts:5 → module.ts:3 → controller.ts:3,7'),
  ('widgets.on-created','message:nest-pattern:widgets.created','Message handler: widgets.created','controller.ts:WidgetsController.onCreated','controller.ts:9; transport activation unverified in main.ts')],
 'next':[
  ('items.get','http:get:/api/items','REST GET /api/items','app/(admin)/api/items/route.ts:GET','app/(admin)/api/items/route.ts:1'),
  ('items.create','http:post:/api/items','REST POST /api/items','app/(admin)/api/items/route.ts:POST','app/(admin)/api/items/route.ts:2'),
  ('items.patch','http:patch:/api/items','REST PATCH /api/items','app/(admin)/api/items/route.ts:PATCH','app/(admin)/api/items/route.ts:3'),
  ('items.archive','action:archiveItem','Server Action archiveItem [TODO: verify entry point]','src/app/actions.ts:archiveItem','src/app/actions.ts:2,3; file directive after comment'),
  ('items.restore','action:restoreItem','Server Action restoreItem [TODO: verify entry point]','src/app/actions.ts:restoreItem','src/app/actions.ts:2,4; exported async arrow'),
  ('items.save','action:saveItem','Server Action saveItem [TODO: verify entry point]','src/app/editor.ts:saveItem','src/app/editor.ts:1,2; function-level directive'),
  ('declared','http:any:/api/declared','REST handler /api/declared (method dispatch not restricted)','pages/api/declared.ts:declared','pages/api/declared.ts:1; default declaration'),
  ('identifier','http:any:/api/identifier','REST handler /api/identifier (method dispatch not restricted)','src/pages/api/identifier.ts:handler','src/pages/api/identifier.ts:1,2; identifier resolved locally'),
  ('expression','http:any:/api/expression','REST handler /api/expression (method dispatch not restricted)','/api/expression','src/pages/api/expression.ts:1; default function expression')]
}
boundaries={
 'express':'Partial: app.js:5 mounts healthRouter using process.env.EXTRA_PREFIX. Its /health leaf is visible, but the external prefix is unknown; no concrete route task emitted for this mount.',
 'fastify':'Partial: app.js:6 registers widgets a second time with process.env.EXTRA_PREFIX. Literal /api/v2 paths are captured; the second runtime prefix is unresolved.',
 'nest':'Partial: controller.ts:12 has dynamic ADMIN_PREFIX, so no concrete health URL task. MessagePattern is a declared consumer; main.ts supplies no microservice transport bootstrap, so runtime activation is unverified.',
 'next':'Partial: src/app/api/forward/route.ts re-exports GET; bounded recipe does not resolve re-exports. src/app/not-a-prologue.ts:2 follows an ordinary statement, so it is not a directive prologue and no action task is emitted. editor.ts:5 is a synchronous helper. Both app and src/app roots are inventoried as requested static forms; simultaneous deployed Next root selection was not exercised.'
}
def inv(root,docs,workspace,reference,name,service,trigger,extra=''):
    path='workflows/'+service+'/'+name+'.md'
    return ('<!-- inventory:begin -->\n'+''.join('**'+k+':** `'+str(v)+'`\n' for k,v in [('Source root',root),('Docs root',docs),('Workspace root',workspace),('Reference',reference),('Files affected',path),('Resolved output',docs/path)])+'**Trigger:** '+trigger+'\n'+extra+'<!-- inventory:end -->')
ac='\n\n**Acceptance criteria:**\n- A workflow doc exists exactly at the task\'s `Resolved output`.\n- The doc follows the `document-workflow` output format (Summary, Sequence of Calls, Flow Description, Data Inventory, Business Rules, Configuration, Dependencies).\n- Backend mode.\n'
def taskhead(name,root,docs,workspace):
    return '# Documentation Tasks — '+name+'\n\n> Generated by `docs-tasks-creator` on 2026-09-07.\n> Inventory Schema: v2\n> Refresh reconciles Workflow IDs and preserves progress and manual evidence.\n\n## Handoff\n\n'+table(['Field','Value'],[['Source root',root],['Docs root',docs],['Workspace root',workspace]])+'\n'
for ws, entries in routes.items():
    slug='widgets-'+ws;docs=R/'detectors/docs'/slug;workspace=D/ws
    entries=sorted(entries)
    sections=[];overview=[]
    for n,(name,identity,trigger,ref,trace) in enumerate(entries,1):
        sections.append('## Task '+str(n)+' — Document `'+name+'`\n\n**Status:** Todo\n**Workflow ID:** `'+slug+':'+identity+'`\n'+inv(D,docs,workspace,ref,name,ws,trigger,'**Registration trace:** '+trace+'\n')+ac)
        overview.append([n,'Document '+name,trigger,ws,'Todo'])
    write(docs/'_docs-tasks.md',taskhead(slug,D,docs,workspace)+'## Tasks overview\n\n'+table(['#','Title','Trigger','Service','Status'],overview)+'\n'+'\n'.join(sections))
    (docs/'workflows').mkdir(exist_ok=True)
    coverage=[['Express' if ws=='express' else 'Fastify' if ws=='fastify' else 'NestJS' if ws=='nest' else 'Next App Router / Pages API / Server Actions','Partial',str(workspace)+'; complete rg file list and search receipt in execution-commands.json',boundaries[ws]]]
    if ws=='next':coverage=[['Next App Router','Partial',str(workspace/'app')+' and '+str(workspace/'src/app'),'GET/POST declarations and const PATCH covered; re-export Partial; deployed root precedence untested'],['Next Pages API','Covered',str(workspace/'pages/api')+' and '+str(workspace/'src/pages/api'),'default declaration, local identifier, inline expression inspected'],['Next Server Actions','Partial',str(workspace/'src/app'),'file/function directives inspected; misplaced directive has no task; server entry points carry TODO']]
    write(docs/'project-overview.md','# '+slug+' — Project Overview\n\n> Generated by `docs-tasks-creator` on 2026-09-07. Static source inventory.\n\n'+summary([('Path',ws),('Stack(s)',ws),('Services','1 ('+ws+')'),('Entry points',str(len(entries))+' captured static execution boundaries')])+'## Top-level layout\n\n'+''.join('- `'+x['path']+'` — inspected source/config.\n' for x in snapshot(D) if x['path'].startswith(ws+'/'))+'\n## Build / Run\n\nNo scripts declared in the inspected package.json. Dependencies were not installed; framework runtime was not started.\n\n## Services\n\n### '+ws+'\n\n- Path: `.`\n- Entry points: '+str(len(entries))+'\n- Stack: '+ws+'\n\n## Scan coverage\n\n'+table(['Detector','State','Roots/patterns searched','Boundary'],coverage)+'\n## Notes\n\n'+boundaries[ws]+'\n')

# Real extant non-ancestor revision, preserving the original doc on an Unverifiable result.
N=R/'nonancestor';identity=json.loads((N/'identity.json').read_text());root=N/'source'
recorded=run(['git','-C',str(root),'show',identity['recorded']+':calc.py'])
oldhash=digest(recorded['stdout'].encode())
nonancestor_doc='# Calculate fee\n\n'+summary([('Created','2026-08-01'),('Last Updated','2026-08-01'),('Generated From',identity['recorded'][:12]),('Schema','v2'),('Source Root',root),('Docs Root',N/'docs'),('Workspace Root',root),('Mode','Backend'),('Trigger','Function call fee(amount)'),('Entry Point','calc.py:fee'),('Success Response','amount * 0.02'),('Cross-Service','No'),('Business Rules','Negative values rejected'),('Complex Logic','No')])+'## Source Evidence\n\n'+table(['Source ID','Full revision','Trace boundary','Dirty paths'],[['fee-source',identity['recorded'],'calc.py','none recorded']])+'\n## Source Files\n\n'+table(['Source ID','Role','Path','SHA-256'],[['fee-source','entry','calc.py',oldhash]])+'\n## Change Log\n\n| Date | Change |\n| --- | --- |\n| 2026-08-01 | Recorded negative-value guard. |\n'
write(N/'docs/fee.md',nonancestor_doc)
before=digest((N/'docs/fee.md').read_bytes())
obj=run(['git','-C',str(root),'cat-file','-t',identity['recorded']])
ancestor=run(['git','-C',str(root),'merge-base','--is-ancestor',identity['recorded'],'HEAD'])
write(N/'refresh-report.md','# Fee freshness result\n\n**Unverifiable**: the recorded full revision exists (`cat-file` returns commit), but is not an ancestor of current HEAD (`merge-base --is-ancestor` exit '+str(ancestor['exit_code'])+'). The source manifest is historical; no false Current classification and no incremental content edit. Full retrace is needed before a new current-state document.\n\nRecorded: `'+identity['recorded']+'`. Current: `'+identity['current']+'`.\n')

# Terraform destination variants and readable v3->v4 full regeneration.
T=R/'terraform';root=T/'source'
legacy=T/'legacy/overview.md';legacy_bytes=legacy.read_bytes()
write(T/'legacy/refresh-report.md','# Legacy freshness inspection\n\n**Unverifiable**: schema v3 has no Source Evidence or byte manifest. The old file remains readable and byte-identical. This refresh does not pretend to establish Current or perform an incremental schema edit. The separately authorized document-terraform full regeneration is staged under `regenerated-v4/`; its new Created date and Change Log identify prior schema v3.\n')
for docs,migration in [(root/'terraform-docs',False),(T/'external-docs',False),(T/'regenerated-v4',True)]:
    for scope in ['overview','root/dev','root/prod']:
        fields=[('Created','2026-09-07'),('Last Updated','2026-09-07'),('Generated From','unknown'),('Schema','v4'),('Scope',scope),('Source Root',root),('Docs Root',docs)]
        text='# Catalog infrastructure — '+scope+'\n\n'+summary(fields)
        text+='## Q1 on-ramp\n\nThe root accepts an environment label and passes `<environment>-catalog` to its one local catalog module (`main.tf:2–6`). The module declares `terraform_data.catalog` and returns its output (`modules/catalog/main.tf:1–3`); the root forwards that value (`main.tf:7`). This is declared local value storage in Terraform state, not a cloud service or evidence of an apply. Provider semantics: [HashiCorp terraform_data](https://developer.hashicorp.com/terraform/language/resources/terraform-data), inspected 2026-09-07.\n\n'
        text+=evidence(root)
        text+='## Topology and environment axis\n\n'+table(['Kind','Enumeration','Count'],[['Root','main.tf at source root',1],['Environment input files','dev.tfvars, prod.tfvars',2],['Package repositories','fixture-source',1],['Module source addresses','./modules/catalog',1],['Remote source@version pairs','none in all four HCL/tfvars files',0],['HCL/tfvars files','main.tf, dev.tfvars, prod.tfvars, modules/catalog/main.tf',4],['Declared resource bodies','modules/catalog/main.tf:2 terraform_data.catalog',1]])+'\nThe environment values below assume explicit selection of the named `-var-file`; these names are not auto-loaded tfvars names. No execution wrapper, backend block, test or staging input was found in the enumerated root. No inter-root ordering exists within this one-root fixture. Backend runtime configuration is unverified.\n\n'
        text+='## Module provenance tree\n\n```text\n[entry] main.tf\n└── module.catalog (×1) — source ./modules/catalog, local, source-resolved\n    └── [local] modules/catalog/main.tf:2 — terraform_data.catalog\n```\n\nContent identity for both local bodies is recorded in Source Files. No remote version is assigned to the local leaf.\n\n'
        envs=['dev','prod'] if scope=='overview' else [scope.split('/')[1]]
        text+='## Declared resources\n\n'+table(['Environment','Address','Resolved input (not cloud name)','Template / confidence','Origin / evidence','Deployment'],[[env,'module.catalog.terraform_data.catalog',env+'-catalog','${var.environment}-catalog; 95%, selected '+env+'.tfvars assumed','main.tf:3–6 → modules/catalog/main.tf:1–3 [local]','unknown'] for env in envs])+'\n'
        text+='## Role in this architecture\n\n```text\nProvides: the catalog module stores the supplied label in a terraform_data input (modules/catalog/main.tf:2).\nConsumes: root var.environment through module.catalog.label (main.tf:2–5).\nConsumed by: root output catalog_label via module.catalog.label (main.tf:7).\nBlast radius: this output depends on the local module output; no application consumer is present in the inspected files.\nPosture: dev and prod inputs select different label prefixes; no security posture is inferable (dev.tfvars:1, prod.tfvars:1).\n```\n\n'
        text+='## Integration & permissioning (incident-triage)\n\n'+table(['link/grant','mechanism','identity','target','exact role/perm','Declared','Deployment','Effective','Evidence'],[['root → catalog','module argument','deploy-time executor unknown','module.catalog.label','not an IAM grant','present','unknown','unknown','HCL main.tf:3–5'],['catalog → root output','output reference','runtime application identity not declared','catalog_label','not an IAM grant','present','unknown','unknown','HCL main.tf:7, modules/catalog/main.tf:3']])+'\nNo plan, applied-state or live evidence was supplied. Important unknown: whether any state instance exists; supply a provenance-bound state/run record to close deployment. There is no observed failure. No cloud authentication probe is relevant to this built-in-only fixture.\n\n'
        text+='## Q3 dependencies and external work\n\n`module.catalog.label → catalog_label` is an internal same-root dependency, confidence 95%, proven by the output references above. There are no data blocks, external IDs, remote module calls or grants in the four enumerated HCL/tfvars files. This bounded absence does not establish an external estate inventory.\n\n## Secrets\n\nNo secret-bearing inputs occur in those four files. Values documented here are the nonsecret environment labels supplied in this fixture.\n\n'
        text+=source_files(root)+'## Change Log\n\n'+table(['Date','Change'],[['2026-09-07','Full regeneration from prior Schema v3; legacy set preserved at ../legacy/overview.md.' if migration else 'Initial v4 generation.']])
        write(docs/(scope+'.md'),text)

# Refresh a seeded schema-v2 task doc: preserve all bytes outside inventory blocks.
G=R/'grouping';root=G/'source';docs=G/'docs'
seed=(G/'seed.md').read_text()
blocks={re.search(r'\*\*Workflow ID:\*\* `([^`]+)`',s).group(1):s for s in re.findall(r'## Task \d+.*?(?=\n## Task |\Z)',seed,re.S)}
group_entries=[('health','functions:http:get:/health','Health.cs:Utility.Health','REST GET /health',9),('heartbeat','functions:timer:0 */5 * * * *:Utility.Heartbeat','Health.cs:Utility.Heartbeat','Timer 0 */5 * * * *',8),('start-order','functions:http:post:/orders','Start.cs:OrderStart.Start','REST POST /orders',7)]
sections=[];preserved=[]
for name,identity,ref,trigger,n in group_entries:
    members='**Members:** `Start.cs:OrderStart.Start`, `Orchestration.cs:OrderFlow.Run`, `Activity.cs:OrderActivities.Record`\n**Grouping evidence:** `Start.cs:6` names ProcessOrder; `Orchestration.cs:6` calls RecordOrder; `Activity.cs:3` binds RecordOrder.\n' if name=='start-order' else ''
    inventory=inv(root,docs,root,ref,name,'functions',trigger,members)
    if identity in blocks:
        old=blocks[identity];new=re.sub(r'<!-- inventory:begin -->.*?<!-- inventory:end -->',lambda m:inventory,old,flags=re.S)
        scrub=lambda s:re.sub(r'<!-- inventory:begin -->.*?<!-- inventory:end -->','',s,flags=re.S)
        preserved.append({'workflow_id':identity,'outside_inventory_before_sha256':digest(scrub(old).encode()),'outside_inventory_after_sha256':digest(scrub(new).encode()),'unchanged':scrub(old)==scrub(new)})
        sections.append(new)
    else:sections.append('## Task '+str(n)+' — Document `'+name+'`\n\n**Status:** Todo\n**Workflow ID:** `'+identity+'`\n'+inventory+ac)
write(docs/'_docs-tasks.md',taskhead('Functions',root,docs,root)+'## Tasks overview\n\n'+table(['#','Title','Trigger','Service','Status'],[[n,'Document '+name,trigger,'functions','Done' if n==7 else 'Todo'] for name,identity,ref,trigger,n in group_entries])+'\n'+'\n'.join(sections))
(docs/'workflows').mkdir(exist_ok=True)
write(docs/'project-overview.md','# Functions — Project Overview\n\n'+summary([('Path',root),('Stack(s)','Azure Functions isolated / Durable declarations'),('Services','1 (functions)'),('Entry points','3 workflow boundaries: 2 HTTP, 1 timer; 5 decorated member functions')])+'## Top-level layout\n\n- `Start.cs` — HTTP starter.\n- `Orchestration.cs` — named orchestration.\n- `Activity.cs` — named activity.\n- `Health.cs` — unrelated HTTP and timer.\n- `Functions.csproj` — framework signal.\n\n## Build / Run\n\nNo execution undertaken; the source fixture does not supply a runnable Functions host or Durable storage.\n\n## Services\n\n### functions\n\n- Path: `.`\n- Entry points: 3 workflow boundaries.\n- Stack: Azure Functions isolated.\n\n## Scan coverage\n\n'+table(['Detector','State','Roots/patterns searched','Boundary'],[['Azure Functions isolated','Covered',str(root)+'/*.cs; Function, HttpTrigger, TimerTrigger, OrchestrationTrigger, ActivityTrigger, named call edges','Static attributes and named grouping edges inspected; FunctionName coverage remains in original trial, not claimed anew here']])+'\n## Notes\n\nHealth and Heartbeat share a file but have unrelated triggers; they remain separate. StartOrder, ProcessOrder and RecordOrder have two explicit named edges across three files, so they remain one workflow.\n')
write(G/'refresh-report.md','# Inventory refresh\n\nChanged `functions:http:post:/orders`: expanded the generated member references to include the observed RecordOrder activity. Existing task 7 remains Done with acceptance text, manual note and dated evidence unchanged. Existing timer remains task 8 Todo with its note unchanged. Added `functions:http:get:/health` as task 9, placed before the older tasks alphabetically without renumbering them. No retirement or possible rename. The earlier Done/Verify content is explicitly synthetic seeded history, preserved rather than interpreted as a real prior success.\n')

# Legacy workflow missing evidence: refresh diagnoses; full retrace generates separate v2.
L=R/'legacy-workflow';legacy_doc='# Get a widget\n\n## Summary\n\nCreated: 2026-08-01. Legacy schema unspecified.\n\nReturns a widget identifier. No source revision or byte manifest was recorded.\n'
write(L/'legacy/get-widget.md',legacy_doc)
legacy_read=(L/'legacy/get-widget.md').read_text()
write(L/'refresh-report.md','# Legacy workflow freshness\n\n**Unverifiable**: this readable legacy record lacks Source Evidence and Source Files. The update-workflow-docs refresh does not alter its sections or label it Current. An authorized full document-workflow retrace is supplied separately under `regenerated-v2/`, with a new Created date and explicit legacy transition.\n')
docs=L/'regenerated-v2';root=D;workspace=D/'express'
write(docs/'get-widget.md','# Get a widget\n\n'+summary([('Created','2026-09-07'),('Last Updated','2026-09-07'),('Generated From','unknown'),('Schema','v2'),('Source Root',root),('Docs Root',docs),('Workspace Root',workspace),('Mode','Backend'),('Trigger','REST GET /api/v1/widgets/:id'),('Entry Point','widgets.js:getWidget'),('Success Response','JSON { id: req.params.id }, default 200'),('Cross-Service','No observed outbound call'),('Business Rules','Echoes the route identifier'),('Complex Logic','No')])+'## Sequence of Calls\n\n```text\napp.use(/api, v1Router) [express/app.js:4]\n  → v1Router.use(/v1, widgetsRouter) [express/routes.js:4]\n    → widgetsRouter.get(/widgets/:id, getWidget) [express/widgets.js:5]\n      → res.json({id:req.params.id}) [express/widgets.js:3]\n```\n\n## Flow Description\n\nThe literal mounts compose `/api/v1/widgets/:id`. The handler returns the path identifier as JSON. There is no data lookup, explicit validation branch or outbound call in its body. Dynamic health mounting is outside this traced entry and remains unresolved.\n\n## Data Inventory\n\n### Inputs\n\n`req.params.id` is the route parameter.\n\n### Outputs\n\nJSON object with `id`. No data store access in this handler.\n\n## Business Rules\n\nThe supplied identifier is echoed without conversion (`express/widgets.js:3`).\n\n## Configuration\n\nLiteral mount prefixes `/api` and `/v1`; Express dependency declared in `express/package.json`. No auth middleware is present in the enumerated fixture source.\n\n## Dependencies\n\nExpress Router and response JSON API; package metadata only, dependency installation/runtime untested.\n\n'+evidence(root)+source_files(root)+'## Change Log\n\n| Date | Change |\n| --- | --- |\n| 2026-09-07 | Full retrace from legacy schema-unspecified record; original preserved at ../legacy/get-widget.md. |\n')

post=[]
for row in I['source_files']:
    path=Path(row['root'])/row['path'];actual=digest(path.read_bytes())
    post.append({**row,'after_sha256':actual,'unchanged':actual==row['sha256']})
destination_files=[str(p) for p in (T/'source/terraform-docs').rglob('*') if p.is_file()]+[str(p) for p in (T/'external-docs').rglob('*') if p.is_file()]
result={'completed_at':datetime.now(timezone.utc).isoformat(),'kind':'one informed local application of frozen prose procedures; not independent model success','nonancestor':{'recorded':identity if False else json.loads((N/'identity.json').read_text()),'object_type':obj['stdout'].strip(),'object_exit':obj['exit_code'],'ancestry_exit':ancestor['exit_code'],'classification':'Unverifiable','doc_before_sha256':before,'doc_after_sha256':digest((N/'docs/fee.md').read_bytes())},'legacy_terraform':{'old_sha256':digest(legacy_bytes),'after_sha256':digest(legacy.read_bytes()),'old_classification':'Unverifiable','new_schema':'v4','new_created':'2026-09-07','mode':'full regeneration; old retained'},'legacy_workflow':{'read_original_sha256':digest(legacy_read.encode()),'after_sha256':digest((L/'legacy/get-widget.md').read_bytes()),'classification':'Unverifiable','new_schema':'v2','mode':'full retrace; original retained'},'detector_counts':{k:len(v) for k,v in routes.items()},'task_preservation':preserved,'terraform_destinations':destination_files,'source_checks':post,'artifacts':[{'path':p,'sha256':digest(Path(p).read_bytes())} for p in outputs],'limitations':['Framework runtimes and Functions host not executed.','These are manually source-traced informed fixtures, not fresh model outcome trials.','New source roots have unborn Git history; revision freshness remains Unverifiable.','Terraform deployment and effectiveness remain unknown; no infrastructure tool/cloud calls.','Original trial coverage and limitations remain unchanged.']}
write(R/'execution-commands.json',json.dumps(commands,indent=2)+'\n')
write(R/'execution-results.json',json.dumps(result,indent=2)+'\n')
print(json.dumps({'source_files_checked':len(post),'source_files_unchanged':sum(x['unchanged'] for x in post),'detector_counts':result['detector_counts'],'nonancestor_ancestry_exit':ancestor['exit_code'],'artifact_count':len(result['artifacts']),'history_preserved':all(x['unchanged'] for x in preserved)},indent=2))
