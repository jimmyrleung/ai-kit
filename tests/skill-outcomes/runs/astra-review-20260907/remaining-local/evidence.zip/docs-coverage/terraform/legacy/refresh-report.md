# Legacy freshness inspection

**Unverifiable**: schema v3 has no Source Evidence or byte manifest. The old file remains readable and byte-identical. This refresh does not pretend to establish Current or perform an incremental schema edit. The separately authorized document-terraform full regeneration is staged under `regenerated-v4/`; its new Created date and Change Log identify prior schema v3.
