# Catalog infrastructure — overview

## Summary

| Field | Value |
| --- | --- |
| Created | 2026-09-07 |
| Last Updated | 2026-09-07 |
| Generated From | unknown |
| Schema | v4 |
| Scope | overview |
| Source Root | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/terraform/source |
| Docs Root | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/terraform/source/terraform-docs |

## Q1 on-ramp

The root accepts an environment label and passes `<environment>-catalog` to its one local catalog module (`main.tf:2–6`). The module declares `terraform_data.catalog` and returns its output (`modules/catalog/main.tf:1–3`); the root forwards that value (`main.tf:7`). This is declared local value storage in Terraform state, not a cloud service or evidence of an apply. Provider semantics: [HashiCorp terraform_data](https://developer.hashicorp.com/terraform/language/resources/terraform-data), inspected 2026-09-07.

## Source Evidence

| Source ID | Root / package | Subdirectory | Full revision | Trace boundary | Staged / unstaged / untracked | Manifest SHA-256 |
| --- | --- | --- | --- | --- | --- | --- |
| fixture-source | /tmp/astra-backlog-5VdqNm/remaining-local-20260907/docs-coverage/terraform/source | . | unknown (unborn Git repository) | All enumerated fixture files; static source only | staged none; unstaged none; untracked `AGENTS.md`, `dev.tfvars`, `main.tf`, `modules/catalog/main.tf`, `prod.tfvars` | 7f5313fd13c4949b8758880688c71129f835f35057c0b6f0e2dbfbc6b0096f76 |

Revision-based freshness: **Unverifiable**. The source-byte manifest is available; no ancestry or deployed-state claim is made. Manifest serialization: sorted source-relative path, TAB, SHA-256, LF.

## Topology and environment axis

| Kind | Enumeration | Count |
| --- | --- | --- |
| Root | main.tf at source root | 1 |
| Environment input files | dev.tfvars, prod.tfvars | 2 |
| Package repositories | fixture-source | 1 |
| Module source addresses | ./modules/catalog | 1 |
| Remote source@version pairs | none in all four HCL/tfvars files | 0 |
| HCL/tfvars files | main.tf, dev.tfvars, prod.tfvars, modules/catalog/main.tf | 4 |
| Declared resource bodies | modules/catalog/main.tf:2 terraform_data.catalog | 1 |

The environment values below assume explicit selection of the named `-var-file`; these names are not auto-loaded tfvars names. No execution wrapper, backend block, test or staging input was found in the enumerated root. No inter-root ordering exists within this one-root fixture. Backend runtime configuration is unverified.

## Module provenance tree

```text
[entry] main.tf
└── module.catalog (×1) — source ./modules/catalog, local, source-resolved
    └── [local] modules/catalog/main.tf:2 — terraform_data.catalog
```

Content identity for both local bodies is recorded in Source Files. No remote version is assigned to the local leaf.

## Declared resources

| Environment | Address | Resolved input (not cloud name) | Template / confidence | Origin / evidence | Deployment |
| --- | --- | --- | --- | --- | --- |
| dev | module.catalog.terraform_data.catalog | dev-catalog | ${var.environment}-catalog; 95%, selected dev.tfvars assumed | main.tf:3–6 → modules/catalog/main.tf:1–3 [local] | unknown |
| prod | module.catalog.terraform_data.catalog | prod-catalog | ${var.environment}-catalog; 95%, selected prod.tfvars assumed | main.tf:3–6 → modules/catalog/main.tf:1–3 [local] | unknown |

## Role in this architecture

```text
Provides: the catalog module stores the supplied label in a terraform_data input (modules/catalog/main.tf:2).
Consumes: root var.environment through module.catalog.label (main.tf:2–5).
Consumed by: root output catalog_label via module.catalog.label (main.tf:7).
Blast radius: this output depends on the local module output; no application consumer is present in the inspected files.
Posture: dev and prod inputs select different label prefixes; no security posture is inferable (dev.tfvars:1, prod.tfvars:1).
```

## Integration & permissioning (incident-triage)

| link/grant | mechanism | identity | target | exact role/perm | Declared | Deployment | Effective | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| root → catalog | module argument | deploy-time executor unknown | module.catalog.label | not an IAM grant | present | unknown | unknown | HCL main.tf:3–5 |
| catalog → root output | output reference | runtime application identity not declared | catalog_label | not an IAM grant | present | unknown | unknown | HCL main.tf:7, modules/catalog/main.tf:3 |

No plan, applied-state or live evidence was supplied. Important unknown: whether any state instance exists; supply a provenance-bound state/run record to close deployment. There is no observed failure. No cloud authentication probe is relevant to this built-in-only fixture.

## Q3 dependencies and external work

`module.catalog.label → catalog_label` is an internal same-root dependency, confidence 95%, proven by the output references above. There are no data blocks, external IDs, remote module calls or grants in the four enumerated HCL/tfvars files. This bounded absence does not establish an external estate inventory.

## Secrets

No secret-bearing inputs occur in those four files. Values documented here are the nonsecret environment labels supplied in this fixture.

## Source Files

| Source ID | Role | Path | SHA-256 |
| --- | --- | --- | --- |
| fixture-source | inspected source/config | AGENTS.md | 82682586b74a3c501467110f4078006ded3688f630431590f269cace95611e50 |
| fixture-source | inspected source/config | dev.tfvars | 7e22564892c5dae40e6ffab34b05fdb48442bca9429a32a727d232b385039386 |
| fixture-source | inspected source/config | main.tf | d964c0156aaf1b010d462e16f97fb661026792cff186989b49d21eed968710d8 |
| fixture-source | inspected source/config | modules/catalog/main.tf | 5a69c4dde68a25b9efa0659ba205586dd728113427764ef0b8edf6c449ae37cd |
| fixture-source | inspected source/config | prod.tfvars | 8390302be30728e8fb3a4d3999e8f0625e7281f40a8510b113e4a738cac12b55 |

## Change Log

| Date | Change |
| --- | --- |
| 2026-09-07 | Initial v4 generation. |
