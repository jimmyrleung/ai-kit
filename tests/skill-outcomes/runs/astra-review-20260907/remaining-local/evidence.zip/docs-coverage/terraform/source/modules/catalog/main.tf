variable "label" { type = string }
resource "terraform_data" "catalog" { input = var.label }
output "label" { value = terraform_data.catalog.output }
