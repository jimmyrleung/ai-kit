Documentation may be written under the supplied docs root, inside or outside this repository. Infrastructure source is read-only. Do not run init, plan, apply, or cloud probes.
