terraform { required_version = ">= 1.4.0" }
variable "environment" { type = string }
module "catalog" {
  source = "./modules/catalog"
  label  = "${var.environment}-catalog"
}
output "catalog_label" { value = module.catalog.label }
