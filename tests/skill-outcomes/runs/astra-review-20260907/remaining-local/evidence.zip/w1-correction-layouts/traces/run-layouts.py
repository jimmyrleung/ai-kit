from pathlib import Path
import hashlib,json,subprocess,time,datetime
R=Path('/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction-layouts')
P=R.parent/'w1-correction'
O=Path('/tmp/astra-backlog-5VdqNm/trials/final-focused/1')
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def snapshot(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_file():
   try:h=sha(p.read_bytes())
   except PermissionError:h=None
   out[str(p.relative_to(root))]={'sha256':h,'bytes':p.stat().st_size}
 return out
def cmd(args,cwd):
 t=time.monotonic();x=subprocess.run(args,cwd=cwd,text=True,capture_output=True)
 with (R/'traces/commands.jsonl').open('a') as f:f.write(json.dumps({'args':args,'cwd':str(cwd),'exit':x.returncode,'stdout':x.stdout,'stderr':x.stderr,'seconds':time.monotonic()-t})+'\n')
 if x.returncode:raise RuntimeError(str(args)+': '+x.stderr)
 return x.stdout.strip()
started=datetime.datetime.now(datetime.timezone.utc).isoformat();prior={str(p):snapshot(p) for p in [P,O]};dump(R/'inputs/prior-artifact-identities.json',prior)
bodypaths=[Path('<user-home>/ai-kit')/x for x in ['skills/document-workflow/SKILL.md','skills/document-workflow/references/output-template.md','skills/update-workflow-docs/SKILL.md','docs/contracts/documentation-evidence.md']]
sourcehashes={str(p):sha(p.read_bytes()) for p in bodypaths};dump(R/'inputs/loaded-body-hashes.json',sourcehashes)
generator=(P/'traces/generate.py').read_text();verifier=(P/'traces/verify.py').read_text();results=[]
for name in ['co-located','multi-workspace']:
 L=R/name;L.mkdir();(L/'traces').mkdir();(L/'inputs').mkdir()
 S=L/'repository';D=S if name=='co-located' else L/'documentation';W=S/'next'
 cmd(['git','clone','--local','--no-hardlinks',str(P/'source'),str(S)],R)
 if D!=S:cmd(['git','init',str(D)],R)
 (L/'inputs/output-template.md').write_bytes((P/'inputs/output-template.md').read_bytes())
 roots={'layout':name,'source_root':str(S),'docs_root':str(D),'workspace_root':str(W),'source_git_top_level':cmd(['git','rev-parse','--show-toplevel'],S),'docs_git_top_level':cmd(['git','rev-parse','--show-toplevel'],D),'selected_workspace':'next','available_workspace_roots':[str(S/x) for x in ['next','dotnet-web','functions']],'selection':'Explicit GET task selects next; sibling dotnet-web and functions are outside trace scope.'}
 dump(L/'roots.json',roots)
 print(json.dumps({'resolved_before_trace':roots,'entry_reference':'src/app/(ops)/api/widgets/[id]/route.ts:GET','mode':'Backend','resolved_output':str(D/'workflows/widgets-web/get-widgets-by-id.md')}),flush=True)
 g=generator.replace("R=Path('/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction');S=R/'source';D=R/'docs';W=S/'next'",f"R=Path({str(L)!r});S=Path({str(S)!r});D=Path({str(D)!r});W=S/'next'")
 g=g.replace("if p.is_file() and '.git' not in p.parts}","if p.is_file() and '.git' not in p.parts and str(p.relative_to(root)) != '_docs-tasks.md' and p.relative_to(root).parts[0] != 'workflows'}")
 g=g.replace('First version at this corrected output location; original failed trial preserved separately','First version')
 (L/'traces/generate.py').write_text(g);cmd(['python',str(L/'traces/generate.py')],L)
 v=verifier[:verifier.index("old=Path('/tmp/astra-backlog")]
 v=v.replace("R=Path('/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction')",f"R=Path({str(L)!r})")
 v=v.replace("if p.is_file() and '.git' not in p.parts}","if p.is_file() and '.git' not in p.parts and str(p.relative_to(root)) != '_docs-tasks.md' and p.relative_to(root).parts[0] != 'workflows'}")
 oldcheck="sourcegit.returncode==docsgit.returncode==0 and Path(sourcegit.stdout.strip())==source and Path(docsgit.stdout.strip())==docs and source!=docs and not source.is_relative_to(docs) and not docs.is_relative_to(source)"
 newcheck="sourcegit.returncode==docsgit.returncode==0 and Path(sourcegit.stdout.strip())==source and Path(docsgit.stdout.strip())==docs"+(" and source==docs" if name=='co-located' else " and source!=docs and not source.is_relative_to(docs) and not docs.is_relative_to(source)")
 v=v.replace(oldcheck,newcheck).replace('independent actual source/docs Git roots','actual source/docs Git roots match layout')
 v += "\ncheck('explicit workspace selection has distinct sibling workspaces',workspace==source/'next' and all((source/x).is_dir() for x in ['next','dotnet-web','functions']),'roots.json')\n"
 v += "check('fresh change log literal metadata',rows(section(doc,'Change Log'))[1][1:]==['Initial documentation pass','First version'],str(p)+'#Change Log')\n"
 v += "dump(R/'verification.json',{'checks':checks,'passed':sum(x['status']=='pass' for x in checks),'failed':sum(x['status']=='fail' for x in checks),'conditional_omissions':conditional,'refresh_executed_once':True,'source_code_invariance':sourcebefore==sourceafter,'snapshot_exclusions':['.git','_docs-tasks.md','workflows/'],'runtime_framework_proof':False})\nprint(json.dumps({'passed':sum(x['status']=='pass' for x in checks),'failed':sum(x['status']=='fail' for x in checks),'refresh':refresh['bucket']}))\n"
 (L/'traces/verify.py').write_text(v);cmd(['python',str(L/'traces/verify.py')],L)
 # Check every pre-existing source file plus all permitted additions separately.
 before=json.loads((L/'inputs/source-before.json').read_text());after={str(p.relative_to(S)):sha(p.read_bytes()) for p in S.rglob('*') if p.is_file() and '.git' not in p.parts};added=sorted(set(after)-set(before));allowed=['_docs-tasks.md','workflows/widgets-web/get-widgets-by-id.md'] if D==S else []
 population={'preexisting_files_unchanged':all(after.get(k)==v for k,v in before.items()),'added_paths':added,'permitted_documentation_additions':allowed,'unexpected_additions':sorted(set(added)-set(allowed))};dump(L/'source-population.json',population)
 verification=json.loads((L/'verification.json').read_text());refresh=json.loads((L/'refresh.json').read_text());gen=json.loads((L/'generation.json').read_text());results.append({'layout':name,'roots':roots,'output':gen['target'],'doc_bytes':Path(gen['target']).stat().st_size,'doc_sha256':sha(Path(gen['target']).read_bytes()),'verification':verification,'refresh':refresh,'source_population':population})
identities=[]
for path,old in prior.items():
 after=snapshot(Path(path));identities.append({'root':path,'files_before':len(old),'files_after':len(after),'identical':old==after,'differing_paths':[k for k in set(old)|set(after) if old.get(k)!=after.get(k)]})
dump(R/'prior-artifact-invariance.json',identities)
sourceunchanged={p:sha(Path(p).read_bytes())==h for p,h in sourcehashes.items()};dump(R/'loaded-body-invariance.json',sourceunchanged)
run={'kind':'informed corrective layout coverage','started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'layouts':results,'prior_artifacts':identities,'loaded_sources_unchanged':sourceunchanged,'tokens':None,'cost':None,'effective_model':None,'full_trace':None,'new_trials':False,'commits_created':False,'source_skill_edits':[],'limitations':['Known prior failure informs these artifacts; not independent outcome improvement.','Next.js runtime and framework dispatch were not executed.','Each layout executes one selected next GET task; other workflows are outside requested bounded coverage.']};dump(R/'run.json',run)
passed=sum(x['verification']['passed'] for x in results);failed=sum(x['verification']['failed'] for x in results)
report='# W1 additional informed layouts\n\nCompleted one generated GET workflow task in each requested layout and executed its actual Source Files refresh once. This finishes local co-located and explicit multi-workspace layout coverage alongside the earlier separate-docs correction. These are informed corrections, not new trials or independent improvement evidence.\n\n| Layout | Source Root and actual source Git top-level | Docs Root and actual docs Git top-level | Selected Workspace Root | Refresh | Checks |\n|---|---|---|---|---|---|\n'
for x in results:
 q=x['roots'];report+=f"| {x['layout']} | `{q['source_root']}` | `{q['docs_root']}` | `{q['workspace_root']}` | {x['refresh']['bucket']} | {x['verification']['passed']} pass / {x['verification']['failed']} fail |\n"
report+='\nEach fixture was locally cloned with existing history; no commits were created. Co-located documentation lives in the actual source Git root. Multi-workspace documentation has its own actual Git root; the task explicitly selects `next` among `next`, `dotnet-web`, and `functions`. Source Root stays the repository root, and Source Files retain the `next/` prefix. Each generated task carries the five authoritative handoff values and is parsed before the exact output is written.\n\n'
for x in results:
 path=Path(x['output']).relative_to(R);report+=f"- [{x['layout']} generated document]({path}) — {x['doc_bytes']} bytes. Evidence: [{x['layout']} verification]({x['layout']}/verification.json), [actual refresh]({x['layout']}/refresh.json), [roots]({x['layout']}/roots.json), [source population]({x['layout']}/source-population.json).\n"
report+=f"\n{passed} template, path, root, metadata, source and refresh checks passed; {failed} failed. All applicable Summary fields and sections are present, and conditional omissions carry reasons. Every pre-existing source file remains byte-identical; only the permitted task/doc files were added in the co-located source root. Refresh leaves both documents byte-identical. The original final-focused trial and first correction have identical file populations and byte identities (including their recorded inaccessible-file state). No skill/template source changed. Exact commands and timings are saved in traces/commands.jsonl and each layout's traces/commands.jsonl.\n\n## Confidence & unverified\n\nConfidence: 98% for the bounded documentation and local refresh evidence. The unpinned Next.js framework was not executed; this does not prove runtime dispatch or another host. The known failed trial remains unchanged and these corrections cannot be counted as independent positive outcomes.\n"
(R/'report.md').write_text(report)
manifest=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(R.rglob('*')) if p.is_file() and '.git' not in p.parts and p.name!='artifact-hashes.json'];dump(R/'artifact-hashes.json',manifest)
print(json.dumps({'passed':passed,'failed':failed,'prior_artifacts_identical':all(x['identical'] for x in identities),'report':str(R/'report.md')}))
