from pathlib import Path
import hashlib,json,subprocess,time,datetime
R=Path('/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction-layouts/co-located');S=Path('/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction-layouts/co-located/repository');D=Path('/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction-layouts/co-located/repository');W=S/'next'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def dump(p,v):write(p,json.dumps(v,indent=2)+'\n')
def cmd(a,cwd):
 t=time.monotonic();x=subprocess.run(a,cwd=cwd,text=True,capture_output=True)
 with (R/'traces/commands.jsonl').open('a') as f:f.write(json.dumps({'args':a,'cwd':str(cwd),'exit':x.returncode,'stdout':x.stdout,'stderr':x.stderr,'seconds':time.monotonic()-t})+'\n')
 return x
def snapshot(root):return {str(p.relative_to(root)):sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file() and '.git' not in p.parts and str(p.relative_to(root)) != '_docs-tasks.md' and p.relative_to(root).parts[0] != 'workflows'}
def boundary():return sorted(str(p.relative_to(S)) for p in W.rglob('*') if p.is_file())
head=cmd(['git','rev-parse','HEAD'],S).stdout.strip();short=cmd(['git','rev-parse','--short','HEAD'],S).stdout.strip();today=datetime.datetime.now(datetime.timezone.utc).date().isoformat();sourcebefore=snapshot(S);dump(R/'inputs/source-before.json',sourcebefore)
rows=[]
for p,role in [(W/'next.config.mjs','Registration/config'),(W/'package.json','Registration/config'),(W/'src/app/(ops)/api/widgets/[id]/route.ts','Entry point')]:
 b=p.read_bytes();rows.append({'source_id':'app','role':role,'path':str(p.relative_to(S)),'sha256':sha(b)});dump(R/'inputs/source-reads'/(p.name+'.json'),{'path':str(p),'text':b.decode(),'sha256':sha(b)})
rows.sort(key=lambda x:(x['source_id'],x['path'],x['role']));canonical=''.join('\t'.join([x['source_id'],x['path'],x['role'],x['sha256']])+'\n' for x in rows);digest=sha(canonical.encode());write(R/'inputs/source-manifest.tsv',canonical);dump(R/'inputs/source-boundary.json',boundary())
output=D/'workflows/widgets-web/get-widgets-by-id.md';ref='src/app/(ops)/api/widgets/[id]/route.ts:GET';handoff={'Source root':str(S),'Docs root':str(D),'Workspace root':str(W),'Reference':ref,'Resolved output':str(output),'Workflow ID':'widgets-web:http:get:/api/widgets/[id]'};dump(R/'handoff.json',handoff)
task='# Documentation Tasks — widgets-web\n\n> Inventory Schema: v2\n> Corrected task handoff for the original GET workflow.\n\n## Handoff\n\n| Field | Value |\n|---|---|\n'+''.join(f'| {k} | `{handoff[k]}` |\n' for k in ['Source root','Docs root','Workspace root'])+'\n## Tasks overview\n\n| # | Title | Trigger | Service | Status |\n|---|---|---|---|---|\n| 1 | Document get-widgets-by-id | REST GET /api/widgets/[id] | widgets-web | Todo |\n\n## Task 1 — Document get-widgets-by-id\n\n**Status:** Todo\n**Workflow ID:** `widgets-web:http:get:/api/widgets/[id]`\n<!-- inventory:begin -->\n'+''.join(f'**{k}:** `{handoff[k]}`\n' for k in ['Source root','Docs root','Workspace root','Reference'])+'**Files affected:** `workflows/widgets-web/get-widgets-by-id.md`\n'+f'**Resolved output:** `{output}`\n**Trigger:** REST GET /api/widgets/[id]\n<!-- inventory:end -->\n\n**Acceptance criteria:**\n- A workflow doc exists exactly at Resolved output.\n- The doc follows the complete current document-workflow template, with all applicable Summary fields and sections.\n- Backend mode.\n';write(D/'_docs-tasks.md',task)
# Consume the actual generated task rather than a separately derived destination.
import re
actualtask=(D/'_docs-tasks.md').read_text();resolved={k:re.search(r'\*\*'+re.escape(k)+r':\*\* `([^`]+)`',actualtask).group(1) for k in ['Source root','Docs root','Workspace root','Reference','Resolved output']};assert resolved=={k:handoff[k] for k in resolved};target=Path(resolved['Resolved output']);assert target.is_relative_to(Path(resolved['Docs root']));dump(R/'traces/executed-handoff.json',resolved)
summary=[('Created',today),('Last Updated',today),('Generated From',f'`{short}` (display only; see Source Evidence)'),('Schema','v2'),('Source Root',f'`{S}`'),('Docs Root',f'`{D}`'),('Workspace Root',f'`{W}`'),('Mode','Backend'),('Trigger','REST GET `/api/widgets/[id]`'),('Entry Point',f'`{ref}`'),('Success Response','JSON response containing `{ "ok": true }`'),('Cross-Service','No — no outgoing service calls in the handler'),('Business Rules','No — no domain rules declared in the handler'),('Complex Logic','No — a constant JSON response')]
doc='# widgets-web:http:get:/api/widgets/[id]\n\n## Summary\n\n| Field | Value |\n|---|---|\n'+''.join(f'| {k} | {v} |\n' for k,v in summary)+'''\n## Sequence of Calls

```text
REST GET /api/widgets/[id]
└── GET (exported async function-valued constant)
    └── Response.json({ ok: true })
```

## Flow Description

1. **Entry** — The Next.js App Router route file exports `GET`. The `(ops)` directory is a route group; the operation's recorded route is `/api/widgets/[id]`. The `[id]` path segment is present, but this function declares no parameters and reads no request input. Source: `next/src/app/(ops)/api/widgets/[id]/route.ts:1`.
2. **Response** — The handler calls `Response.json` with the literal object `{ ok: true }` and returns that response. The async function returns it through its promise. No branches, validation, persistence or outgoing calls appear in this handler.
3. **Boundary** — The same file also exports `POST` at line 3; it is a separate operation. This document traces GET only. Framework request dispatch and exception handling are outside the inspected handler; no runtime execution is claimed.

## Data Inventory

### Request / Response

| Direction | Type | Description |
|---|---|---|
| Input | HTTP GET request | Route includes `[id]`; this handler does not read a path value, request body or query. |
| Output | JSON response | Literal payload `{ "ok": true }`; constructed at `route.ts:1`. |

## Business Rules

No domain-specific business rules are declared in this bounded handler.

## Configuration

| Setting | Purpose |
|---|---|
| `next/package.json` → `dependencies.next` | Declares Next.js with value `latest`; no resolved installed version is supplied. |
| `next/next.config.mjs` | Exports an empty configuration object; no additional routing options are declared here. |
| `next/src/app/(ops)/api/widgets/[id]/route.ts` | File location and exported GET symbol provide the static route registration inspected for this operation. |

## Dependencies

- **Next.js App Router** — Framework dispatch to the exported handler, as represented by the route file and package declaration; installed runtime behavior is unverified.
- **Response.json** — Response construction called at `route.ts:1`. No external service, repository or database dependency is called in the inspected function.

## Source Evidence

'''+f'''Source ID `app` resolves at Source Root `{S}`. Workspace-relative task references translate to repository-relative Source Files paths with the `next/` prefix. Manifest SHA-256 uses UTF-8 lines sorted by Source ID, path and role: `source_id<TAB>path<TAB>role<TAB>sha256<LF>`. The correction evidence directory retains the exact manifest and initial boundary enumeration.

| Source ID | Repository/source identity | Full revision | Trace boundary | Relevant dirty paths | Manifest SHA-256 |
|---|---|---|---|---|---|
| app | fixture-widgets-source; root `{S}` | `{head}` | `next/**` file enumeration; registration/configuration bytes: `next/package.json`, `next/next.config.mjs`, `next/src/app/(ops)/api/widgets/[id]/route.ts` | none | sha256:{digest} |

## Source Files

Paths below resolve from the Source Root for `app`, including its workspace prefix. Each listed hash was computed from the actual file bytes read for this trace. Other workspace filenames are inventoried only for the bounded freshness check; their uninspected contents are not documented here.

| Source ID | Role | Path | SHA-256 |
|---|---|---|---|
'''+''.join(f'| {x["source_id"]} | {x["role"]} | `{x["path"]}` | {x["sha256"]} |\n' for x in rows)+f'''
## Change Log

| Date | Change | Reason |
|---|---|---|
| {today} | Initial documentation pass | First version |

Confidence: 95% for this bounded source trace. The package declares an unpinned version and the Next.js runtime was not executed, so runtime dispatch and framework behavior remain unverified.
'''
write(target,doc);dump(R/'generation.json',{'source_root':str(S),'docs_root':str(D),'workspace_root':str(W),'target':str(target),'summary_fields':[x[0] for x in summary],'source_manifest':rows,'manifest_digest':digest,'source_unchanged_after_write':sourcebefore==snapshot(S),'doc_sha256':sha(target.read_bytes()),'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(str(target))
