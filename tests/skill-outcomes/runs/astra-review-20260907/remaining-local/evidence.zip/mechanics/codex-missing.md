Synthetic private conventions sentinel: preserve exactly.
Synthetic trailing private sentinel.
