# Repository-only fixture tasks

## Task R1 — Expose the check action
Status: Done
Dependencies: none
Files: index.html

### Acceptance criteria
- AC-R1: The rendered page exposes a visible button named Run checks.
- AC-R2: Clicking that button changes the visible status to Checks requested.

### Tests
Run the browser check against the actual index.html bytes. No server, credentials or deployment is needed for this standalone fixture.

### Verify — 2026-09-07

<!-- evidence:begin repo-only-R1-verify-20260907 -->
Task gates 1–3 passed using task-verification.json and matching browser-check-reuse-20260907-r1. Both original ACs passed. No identical browser command was rerun. Repository review then QA remain the next steps; owner GO is pending.
<!-- evidence:end repo-only-R1-verify-20260907 -->
<!-- evidence:begin repo-only-prefix-review-20260907 -->
## Review — 2026-09-07

One independent native worker reviewed all R1 implementation/test bytes and dependency identities under the supplied empty-tree base. Source verdict PASS, no supported findings. Parent recomputed all reviewed and output hashes: no drift. Full report: independent-review/report.md. Owner GO remains pending.
<!-- evidence:end repo-only-prefix-review-20260907 -->
<!-- evidence:begin repo-only-prefix-qa-20260907 -->
## QA — 2026-09-07

- [x] Gate 1 — executed browser suite PASS, reused browser-check-reuse-20260907-r1 with matching source/test/environment/complete two-AC scope. No rerun. No other build/unit/integration tier applies to this standalone fixture.
- [x] Gate 2 — AC-R1 visible exact button and AC-R2 click/status response PASS via current rendered browser evidence and screenshots. Subjective wording is not an AC and has no fabricated approval.
- [x] Gate 3 — standalone source declares no external settings, pinned SDK, line budget, migration or release task. Source and test hashes match; network was disabled.
- [x] Gate 4 — repository-only R1 is Done with original ACs preserved. No deploy/live tasks were added or inferred. No other task or sibling specification exists inside this explicitly enumerated fixture root. Remaining unchecked box below is the real owner decision.
- [ ] Gate 5 — owner GO pending. No approval or operation is simulated as achieved.

Normal repository-only path executed: implement → task verification → Done → one independent source review → repository QA → owner decision pending. This informed fixture is not a comparative model success trial. New delimited review/QA records are excluded only from their own subject digest; original tasks.md bytes remain the dependency identity recorded before these markers. Parent validation did not invent an operational dependency or change the task status vocabulary.
<!-- evidence:end repo-only-prefix-qa-20260907 -->
