# Repository-only fixture tasks

## Task R1 — Expose the check action
Status: Not Started
Dependencies: none
Files: index.html

### Acceptance criteria
- AC-R1: The rendered page exposes a visible button named Run checks.
- AC-R2: Clicking that button changes the visible status to Checks requested.

### Tests
Run the browser check against the actual index.html bytes. No server, credentials or deployment is needed for this standalone fixture.
