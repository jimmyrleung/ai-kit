from pathlib import Path
import os,subprocess,json,selectors,time,hashlib,datetime
r=Path(__file__).parent;home=r/'isolated-home';project=home/'sample';env={'PATH':os.environ['PATH'],'HOME':str(home),'XDG_CONFIG_HOME':str(home/'.config'),'XDG_CACHE_HOME':str(home/'.cache'),'LANG':'C.UTF-8'}
requests=[];responses=[];cmd=['codex','app-server','--stdio'];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'discovery-stderr.txt').open('w') as errors:
 p=subprocess.Popen(cmd,cwd=project,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors,text=True,bufsize=1)
 selector=selectors.DefaultSelector();selector.register(p.stdout,selectors.EVENT_READ)
 def send(obj):requests.append(obj);p.stdin.write(json.dumps(obj)+'\n');p.stdin.flush()
 def read_id(wanted):
  until=time.monotonic()+20
  while time.monotonic()<until:
   if not selector.select(max(0,until-time.monotonic())):break
   line=p.stdout.readline()
   if not line:break
   value=json.loads(line);responses.append(value)
   if value.get('id')==wanted:return value
  return {'missing_response_id':wanted}
 send({'id':0,'method':'initialize','params':{'clientInfo':{'name':'ai-kit-isolated-discovery-probe','version':'1'}}});init=read_id(0)
 send({'method':'initialized','params':{}})
 send({'id':1,'method':'skills/list','params':{'cwds':[str(project)],'forceReload':True}});listed=read_id(1)
 p.stdin.close()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=5)
(r/'discovery-requests.json').write_text(json.dumps(requests,indent=2)+'\n');(r/'discovery-responses.json').write_text(json.dumps(responses,indent=2)+'\n')
expected={x.name:str((x/'SKILL.md').resolve()) for x in (home/'.agents/skills').iterdir()};entries=listed.get('result',{}).get('data',[]);skills=[s for e in entries for s in e.get('skills',[])];matches=[];missing=[]
for name,target in sorted(expected.items()):
 candidates=[s for s in skills if s['name']==name and str(Path(s['path']).resolve())==target and s['enabled']]
 (matches if candidates else missing).append(name)
record={'kind':'actual native app-server discovery in isolated unauthenticated home','started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'initialize_received':'result' in init,'skills_response_received':'result' in listed,'catalog_entries':len(skills),'expected_canonical_skills':len(expected),'matched_enabled_canonical_skills':matches,'missing':missing,'errors':[x for e in entries for x in e.get('errors',[])],'source_identity':{name:hashlib.sha256(Path(target).read_bytes()).hexdigest() for name,target in expected.items()},'model_execution':'none; native discovery API only, earlier model attempt unavailable without authentication','subprocess_exit_code':p.returncode,'schema_source':'installed codex app-server generate-json-schema output'}
(r/'native-discovery-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['initialize_received','skills_response_received','catalog_entries','expected_canonical_skills','missing','errors','subprocess_exit_code']}))
if missing or not record['skills_response_received']:raise SystemExit(1)
