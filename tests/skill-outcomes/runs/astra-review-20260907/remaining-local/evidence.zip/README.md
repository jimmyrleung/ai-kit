# Remaining local acceptance work

Started 2026-09-07T11:33:27.849392+00:00. Prior trials remain immutable. This is corrective/coverage work after recorded failures, not an independent comparison or savings trial.

- final_focused_regressions: diagnose W1 output omission; repair only a proven source gap, otherwise complete corrected artifact separately with exact template verification. Own only document-workflow body/template if justified; no other repo writes.
- acceptance_grounding: execute missing bounded documentation fixtures for freshness/legacy/detector mounts/destination topology/cross-file flow; scratch only; use frozen final source.
- parent: mechanics-drift and engineering repository-only/browser coverage; all shared evidence/ledger writes.

Workers retain requested gpt-6-astra/high for contract-sensitive correction/grounding. Effective runtime proof unavailable. Shell tools available. No new agents within workers; no live-home writes or ai-kit commits.
