# Documentation Tasks — widgets-web

> Inventory Schema: v2
> Corrected task handoff for the original GET workflow.

## Handoff

| Field | Value |
|---|---|
| Source root | `/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction/source` |
| Docs root | `/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction/docs` |
| Workspace root | `/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction/source/next` |

## Tasks overview

| # | Title | Trigger | Service | Status |
|---|---|---|---|---|
| 1 | Document get-widgets-by-id | REST GET /api/widgets/[id] | widgets-web | Todo |

## Task 1 — Document get-widgets-by-id

**Status:** Todo
**Workflow ID:** `widgets-web:http:get:/api/widgets/[id]`
<!-- inventory:begin -->
**Source root:** `/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction/source`
**Docs root:** `/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction/docs`
**Workspace root:** `/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction/source/next`
**Reference:** `src/app/(ops)/api/widgets/[id]/route.ts:GET`
**Files affected:** `workflows/widgets-web/get-widgets-by-id.md`
**Resolved output:** `/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction/docs/workflows/widgets-web/get-widgets-by-id.md`
**Trigger:** REST GET /api/widgets/[id]
<!-- inventory:end -->

**Acceptance criteria:**
- A workflow doc exists exactly at Resolved output.
- The doc follows the complete current document-workflow template, with all applicable Summary fields and sections.
- Backend mode.
