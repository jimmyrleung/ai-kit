from pathlib import Path
import hashlib,json,re,datetime,subprocess,time
R=Path('/tmp/astra-backlog-5VdqNm/remaining-local-20260907/w1-correction')
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def cmd(a,cwd):
 t=time.monotonic();x=subprocess.run(a,cwd=cwd,text=True,capture_output=True)
 with (R/'traces/commands.jsonl').open('a') as f:f.write(json.dumps({'args':a,'cwd':str(cwd),'exit':x.returncode,'stdout':x.stdout,'stderr':x.stderr,'seconds':time.monotonic()-t})+'\n')
 return x
def section(text,name,level=2):
 marker='#'*level+' '+name;start=text.index(marker+'\n')+len(marker)+1;end=re.search(r'^#{1,'+str(level)+r'} ',text[start:],re.M);return text[start:start+end.start()] if end else text[start:]
def rows(text):return [[x.strip().strip('`') for x in line.strip().strip('|').split('|')] for line in text.splitlines() if line.startswith('|') and not re.match(r'^\|\s*[-: ]+\|',line)]
def snap(root):return {str(p.relative_to(root)):sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file() and '.git' not in p.parts}
handoff=json.loads((R/'handoff.json').read_text());p=Path(handoff['Resolved output']);before=p.read_bytes();doc=before.decode();template=(R/'inputs/output-template.md').read_text();summary=dict(rows(section(doc,'Summary'))[1:]);checks=[]
def check(name,passed,evidence):checks.append({'check':name,'status':'pass' if passed else 'fail','evidence':evidence})
required=[x[0] for x in rows(section(template,'Summary')) if x[0] and x[0]!='Client']; required=[x for x in required if x!='']
for field in required:check('Summary: '+field,field in summary and bool(summary[field]),str(p)+'#Summary')
ordered=['Summary','Sequence of Calls','Flow Description','Data Inventory','Business Rules','Configuration','Dependencies','Source Evidence','Source Files','Change Log'];actual=re.findall(r'^## (.+)$',doc,re.M);check('applicable top-level sections and order',actual==ordered,str(p))
conditional={'Summary Client':'Backend task; no client entry or full-stack signal.','Complex Logic Breakdown':'GET body contains only a constant Response.json return; no branching/calculation.','Database':'No data access in GET.','Events / Messages':'No event operations in GET.','External APIs':'No outbound API operations in GET.','Client State':'Backend mode.','Wire Contract':'Backend mode.','Async Push-Back':'Backend mode.','Client-Visible Outcomes':'Backend mode.','Cross-Cutting Concerns':'Backend mode.'};dump(R/'conditional-requirements.json',conditional)
for name,columns in [('Data Inventory',['Direction','Type','Description']),('Configuration',['Setting','Purpose']),('Source Evidence',['Source ID','Repository/source identity','Full revision','Trace boundary','Relevant dirty paths','Manifest SHA-256']),('Source Files',['Source ID','Role','Path','SHA-256']),('Change Log',['Date','Change','Reason'])]:check(name+' table columns',rows(section(doc,name))[0]==columns,str(p)+'#'+name)
source=Path(summary['Source Root']);docs=Path(summary['Docs Root']);workspace=Path(summary['Workspace Root']);sourcegit=cmd(['git','rev-parse','--show-toplevel'],source);docsgit=cmd(['git','rev-parse','--show-toplevel'],docs);check('independent actual source/docs Git roots',sourcegit.returncode==docsgit.returncode==0 and Path(sourcegit.stdout.strip())==source and Path(docsgit.stdout.strip())==docs and source!=docs and not source.is_relative_to(docs) and not docs.is_relative_to(source),'traces/commands.jsonl')
check('Summary roots agree with generated handoff',str(source)==handoff['Source root'] and str(docs)==handoff['Docs root'] and str(workspace)==handoff['Workspace root'],'handoff.json + document Summary')
check('generated task exact output path',p.is_relative_to(docs) and p.exists() and str(p) in (docs/'_docs-tasks.md').read_text(),'traces/executed-handoff.json')
ref=handoff['Reference'].rsplit(':',1)[0];entry=workspace/ref;check('entry reference resolves to actual GET declaration','export const GET = async () => Response.json({ ok: true })' in entry.read_text(),str(entry)+':1');check('bounded flow preserves GET/POST distinction','POST' in doc and 'separate operation' in doc and 'Response.json({ ok: true })' in doc,str(p)+'#Flow Description')
# Execute update-workflow-docs Current path from the actual document fields.
sourcefiles=rows(section(doc,'Source Files'))[1:];evidence=rows(section(doc,'Source Evidence'))[1:];record=evidence[0];recordedhead=record[2];reads=[];manifest=[]
for sid,role,path,oldhash in sourcefiles:
 actualpath=source/path;b=actualpath.read_bytes();reads.append({'source_id':sid,'path':path,'resolved_path':str(actualpath),'sha256':sha(b),'expected':oldhash,'matches':sha(b)==oldhash});manifest.append({'source_id':sid,'path':path,'role':role,'sha256':sha(b)})
manifest.sort(key=lambda x:(x['source_id'],x['path'],x['role']));canonical=''.join('\t'.join([x['source_id'],x['path'],x['role'],x['sha256']])+'\n' for x in manifest);newdigest=sha(canonical.encode());oldboundary=json.loads((R/'inputs/source-boundary.json').read_text());boundary=sorted(str(q.relative_to(source)) for q in workspace.rglob('*') if q.is_file());ancestor=cmd(['git','merge-base','--is-ancestor',recordedhead,'HEAD'],source);head=cmd(['git','rev-parse','HEAD'],source).stdout.strip();dirty=cmd(['git','status','--short','--','next'],source);staged=cmd(['git','diff','--cached','--name-only','--','next'],source);unstaged=cmd(['git','diff','--name-only','--','next'],source);untracked=cmd(['git','ls-files','--others','--exclude-standard','-z','--','next'],source);history=cmd(['git','log',recordedhead+'..HEAD','--oneline','--','next'],source)
current=ancestor.returncode==0 and head==recordedhead and all(x['matches'] for x in reads) and newdigest==record[5].split(':',1)[1] and boundary==oldboundary and not dirty.stdout and not staged.stdout and not unstaged.stdout and not untracked.stdout
refresh={'doc':str(p),'bucket':'Current' if current else 'Unverifiable','source_root_resolved_from':'document Summary / Source Evidence app','source_root':str(source),'recorded_revision':recordedhead,'current_revision':head,'ancestor_exit':ancestor.returncode,'actual_source_reads':reads,'manifest_sha256':newdigest,'boundary_before':oldboundary,'boundary_after':boundary,'dirty':dirty.stdout,'staged':staged.stdout,'unstaged':unstaged.stdout,'untracked':untracked.stdout,'history_context':history.stdout,'doc_before_sha256':sha(before),'doc_after_sha256':sha(p.read_bytes()),'document_writes':0,'runtime_framework_proof':False};dump(R/'refresh.json',refresh);check('refresh actually reads SourceID-root relative paths',all(x['matches'] and x['path'].startswith('next/') for x in reads),'refresh.json:actual_source_reads');check('unchanged actual refresh is Current and byte-preserving',current and before==p.read_bytes(),'refresh.json');check('source manifest digest and registration boundary match',newdigest==record[5].split(':',1)[1] and boundary==oldboundary,'refresh.json');check('metadata generation date and change log',summary['Created']==summary['Last Updated']==datetime.datetime.now(datetime.timezone.utc).date().isoformat() and len(rows(section(doc,'Change Log')))==2 and summary['Schema']=='v2' and cmd(['git','rev-parse','--short','HEAD'],source).stdout.strip() in summary['Generated From'],str(p)+'#Change Log')
sourcebefore=json.loads((R/'inputs/source-before.json').read_text());sourceafter=snap(source);dump(R/'source-invariance.json',{'before':sourcebefore,'after':sourceafter,'equal':sourcebefore==sourceafter});check('all source file bytes invariant',sourcebefore==sourceafter,'source-invariance.json')
old=Path('/tmp/astra-backlog-5VdqNm/trials/final-focused/1');oldhash=json.loads((R/'inputs/prior-trial-hashes.json').read_text());differences=[]
for x in oldhash:
 q=old/x['path']
 try:new=sha(q.read_bytes())
 except PermissionError:new=None
 if new!=x['sha256'] or q.stat().st_size!=x['bytes']:differences.append(x['path'])
oldpaths={str(q.relative_to(old)) for q in old.rglob('*') if q.is_file()};check('prior trial entire file population and bytes preserved',not differences and oldpaths=={x['path'] for x in oldhash},'prior-trial-invariance.json');dump(R/'prior-trial-invariance.json',{'checked_files':len(oldhash),'differences':differences,'population_matches':oldpaths=={x['path'] for x in oldhash},'unreadable_expected':[x['path'] for x in oldhash if x['sha256'] is None]})
run=json.loads((R/'run.json').read_text());unchanged={path:sha(Path(path).read_bytes())==digest for path,digest in run['source_hashes'].items()};check('skill/template and inspected failed inputs unchanged',all(unchanged.values()),'source-identity-check.json');dump(R/'source-identity-check.json',unchanged)
# Preserve every old external/embedded/wiki reference; none are present in failed doc.
oldtext=(R/'inputs/failed-doc.md').read_text();refs=re.findall(r'https?://[^\s)>]+|\[\[[^]]+\]\]|!\[[^]]*\]\([^)]*\)',oldtext);dump(R/'reference-preservation.json',{'old_external_embedded_wiki_refs':refs,'all_retained':all(x in doc for x in refs),'source_locators':'intentionally translated to new actual Source Root with next/ workspace prefix','old_source_file_paths': [x[2] for x in rows(section(oldtext,'Source Files'))[1:]],'new_source_file_paths':[x['path'] for x in manifest]});check('external references preserved and source locators explicitly translated',all(x in doc for x in refs),'reference-preservation.json')
dump(R/'verification.json',{'checks':checks,'conditional_omissions':conditional,'passed':sum(x['status']=='pass' for x in checks),'failed':sum(x['status']=='fail' for x in checks),'refresh_executed_once':True,'source_edits':[],'old_trial_edits':[],'runtime_tests':'not applicable to documentation correction; no framework runtime proof claimed'})
script=(R/'inputs/execute.py').read_text().splitlines();diagnosis={'executor_summary_constructor_line':next(i for i,line in enumerate(script,1) if "doc=f'#" in line),'executor_initial_checks_line':next(i for i,line in enumerate(script,1) if "finish(id,t,[check('original W1" in line),'template_fields':[{'field':f,'line':next(i for i,line in enumerate(template.splitlines(),1) if re.match(r'^\| '+re.escape(f)+r'\s+\|',line))} for f in ['Source Root','Docs Root','Workspace Root','Trigger','Entry Point','Success Response']],'cause':'Manual shortened Summary construction omitted fields; initial artifact checks did not compare full template. Template and skill already require exact shape.','source_change_warranted':False};dump(R/'diagnosis.json',diagnosis)
run.update({'status':'complete-correction-and-verification','finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'output':str(p),'checks_passed':sum(x['status']=='pass' for x in checks),'checks_failed':sum(x['status']=='fail' for x in checks),'source_changes':[],'prior_trial_byte_invariance':not differences,'refresh':'Current' if current else 'Unverifiable','remaining_gaps':['Next.js runtime not executed and dependency declares latest; source documentation only.','Corrective artifact uses knowledge of prior failure; not independent outcome or improvement-rate evidence.']});dump(R/'run.json',run)
report=f'''# W1 informed correction

Completed the workflow documentation task at [the exact generated destination](docs/workflows/widgets-web/get-widgets-by-id.md). This is informed corrective work, not a new trial, a regrade, or independent outcome-improvement evidence.

## Cause and source decision

The previous executor manually constructed a shortened Summary at `execute.py:{diagnosis['executor_summary_constructor_line']}` and checked file existence, IDs and source refresh without complete template validation at `execute.py:{diagnosis['executor_initial_checks_line']}`. It omitted Source Root, Docs Root, Workspace Root, Trigger, Entry Point and Success Response. The inspected current template already requires each field (exact lines in diagnosis.json), and the skill's Output section requires the exact template. No skill or template source edit was warranted or made.

## Corrected work

- Generated a concrete documentation task and consumed its actual handoff before writing the corrected GET document.
- Confirmed separate actual source/docs Git roots with git rev-parse. The source repository was locally cloned with its existing history; no commits were created. Docs repository is unborn. Source Root is the repository root; Workspace Root is its next/ child.
- Included every applicable Summary field and template section, with explicit reasons for backend-only conditional omissions in conditional-requirements.json.
- Executed the refresh path by parsing the actual document's Source Files and Source Evidence, opening those source paths, recomputing hashes, checking the source revision and all Git dirty layers, and re-enumerating the bounded workspace filenames. Verdict: {run['refresh']}; document writes during refresh: 0.

## Verification

{run['checks_passed']} checks passed; {run['checks_failed']} failed (verification.json). Source byte invariance, exact output path, Summary/handoff/root consistency, full applicable template shape, manifest and reference preservation are recorded individually. The previous final-focused run's file population and readable bytes remain unchanged; its deliberately unreadable fixture remains unreadable. No prior failure or grade was rewritten.

Evidence: [verification](verification.json), [refresh](refresh.json), [diagnosis](diagnosis.json), [source invariance](source-invariance.json), [prior trial invariance](prior-trial-invariance.json), [commands](traces/commands.jsonl).

## Confidence & unverified

Confidence: 98% for the diagnosed executor omission and verified corrective artifact. Current skill/template source is unchanged. The Next.js runtime was not executed and its dependency is unpinned; this verifies bounded source documentation and actual local freshness checks, not runtime dispatch or behavior on another host. The correction is informed by the known failure and cannot be counted as an independent improved outcome.
''';(R/'report.md').write_text(report)
manifest=[]
for q in sorted(R.rglob('*')):
 if q.is_file() and '.git' not in q.parts and q.name!='artifact-hashes.json':manifest.append({'path':str(q.relative_to(R)),'sha256':sha(q.read_bytes()),'bytes':q.stat().st_size})
dump(R/'artifact-hashes.json',manifest)
print(json.dumps({'passed':run['checks_passed'],'failed':run['checks_failed'],'refresh':run['refresh'],'old_trial_unchanged':not differences,'report':str(R/'report.md')},indent=2))
