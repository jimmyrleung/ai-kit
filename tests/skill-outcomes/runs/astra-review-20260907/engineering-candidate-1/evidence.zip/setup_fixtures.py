#!/usr/bin/env python3
"""Materialize the predeclared case fixtures for candidate repeat 1."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CASES_PATH = ROOT / "input-snapshots" / "cases.json"
FIXTURES = ROOT / "fixtures"
SELECTED = [
    "dirty-review",
    "unborn-short-history",
    "review-invalidation",
    "task-reverification",
    "consumer-closure",
    "completion-resources",
    "existing-test-home",
    "convention-new-test",
    "no-suitable-test-home",
    "unneeded-helper",
    "authorization-cadence",
    "review-depth-severity",
    "check-reuse",
    "intent-routing",
    "incident-causality",
]


def write(path: Path, data: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data, encoding="utf-8")


def run(cwd: Path, *args: str) -> str:
    result = subprocess.run(args, cwd=cwd, check=True, text=True, capture_output=True)
    return result.stdout.strip()


def git_init(path: Path) -> None:
    run(path, "git", "init", "-q")
    run(path, "git", "config", "user.email", "trial@example.invalid")
    run(path, "git", "config", "user.name", "Trial Fixture")


def materialize(case: dict, path: Path) -> None:
    path.mkdir(parents=True, exist_ok=False)
    for rel, content in case.get("files", {}).items():
        write(path / rel, content)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    corpus = json.loads(CASES_PATH.read_text(encoding="utf-8"))
    by_id = {case["id"]: case for case in corpus["cases"]}
    FIXTURES.mkdir(parents=True, exist_ok=False)
    setup_log: list[dict] = []

    for case_id in SELECTED:
        case = by_id[case_id]
        case_root = FIXTURES / case_id
        materialize(case, case_root)
        setup_log.append({"case_id": case_id, "action": "materialize corpus files", "state_recipe": case.get("state", {}).get("recipe")})

    dirty = FIXTURES / "dirty-review"
    write(dirty / "calc.py", "def fee(amount):\n    return amount * 0.02\n")
    write(dirty / "old.md", "old documentation\n")
    write(dirty / "unrelated.txt", "Task B baseline\n")
    git_init(dirty)
    run(dirty, "git", "add", "calc.py", "old.md", "unrelated.txt", "tasks.md")
    run(dirty, "git", "commit", "-q", "-m", "initial fixture")
    write(dirty / "unrelated.txt", "Task B earlier unrelated work\n")
    run(dirty, "git", "add", "unrelated.txt")
    run(dirty, "git", "commit", "-q", "-m", "earlier unrelated Task B work")
    run(dirty, "git", "tag", "fixture-base")
    write(dirty / "calc.py", "def fee(amount):\n    if amount < 0:\n        raise ValueError(\"negative amount\")\n    return amount * 0.02\n")
    run(dirty, "git", "add", "calc.py")
    run(dirty, "git", "commit", "-q", "-m", "Task A committed guard")
    write(dirty / "calc.py", "def fee(amount):\n    if amount < 0:\n        raise ValueError(\"amount must be nonnegative\")\n    return amount * 0.02\n")
    run(dirty, "git", "add", "calc.py")
    run(dirty, "git", "mv", "old.md", "new.md")
    write(dirty / "calc.py", "def fee(amount):\n    if amount < 0:\n        raise ValueError(\"amount must be nonnegative\")\n    # Preserve the established percentage.\n    return amount * 0.02\n")
    write(dirty / "fresh.txt", "Task A fresh note\n")

    unborn_root = FIXTURES / "unborn-short-history"
    for variant in ("unborn", "single-commit"):
        target = unborn_root / variant
        target.mkdir()
        shutil.copy2(unborn_root / "tasks.md", target / "tasks.md")
        git_init(target)
        if variant == "single-commit":
            write(target / "value.py", "def value():\n    return 1\n")
            run(target, "git", "add", "tasks.md", "value.py")
            run(target, "git", "commit", "-q", "-m", "baseline")
            write(target / "value.py", "def value():\n    return 3\n")
            run(target, "git", "add", "value.py")
        else:
            write(target / "value.py", "def value():\n    return 3\n")
            run(target, "git", "add", "tasks.md", "value.py")
        write(target / "value.py", "def value():\n    return 2\n")

    invalid = FIXTURES / "review-invalidation"
    git_init(invalid)
    run(invalid, "git", "add", "spec.md", "source.py")
    run(invalid, "git", "commit", "-q", "-m", "fixture base")
    ac_bytes = "## Task A requirements\n- Return a nonnegative amount.\n".encode()
    record = {
        "schema_version": 1,
        "record_id": "initial-approved-task-a",
        "kind": "artifact-review",
        "verdict": "Approved",
        "scope": {"task": "Task A", "paths": ["source.py"], "base": run(invalid, "git", "rev-parse", "HEAD")},
        "manifest": {"source.py": digest(invalid / "source.py")},
        "dependencies": {"spec.md#Task A requirements": hashlib.sha256(ac_bytes).hexdigest()},
        "evidence_exclusion": "Only exact evidence marker regions are excluded from subject bytes.",
    }
    write(invalid / "change-evidence.md", "<!-- evidence:begin initial-approved-task-a -->\n```json\n" + json.dumps(record, indent=2) + "\n```\n<!-- evidence:end initial-approved-task-a -->\n")
    for variant in ("matching", "same-head-dirty", "edited-ac", "task-b-requested", "rejected", "evidence-only-append", "unrelated-edit", "missing-identities"):
        target = invalid / "variants" / variant
        shutil.copytree(invalid, target, ignore=shutil.ignore_patterns("variants", ".git"))
        if variant == "same-head-dirty":
            write(target / "source.py", "def amount():\n    return -1\n")
        elif variant == "edited-ac":
            write(target / "spec.md", "# Spec\n## Task A requirements\n- Return a strictly positive amount.\n## Task B requirements\n- Add a receipt.\n")
        elif variant == "rejected":
            write(target / "change-evidence.md", (target / "change-evidence.md").read_text().replace('"Approved"', '"Rejected"'))
        elif variant == "evidence-only-append":
            with (target / "change-evidence.md").open("a", encoding="utf-8") as fh:
                fh.write("<!-- evidence:begin later-note -->\nLater evidence note only.\n<!-- evidence:end later-note -->\n")
        elif variant == "unrelated-edit":
            write(target / "unrelated.txt", "outside Task A scope\n")
        elif variant == "missing-identities":
            write(target / "change-evidence.md", "## Review\nApproved, but no content or dependency identities.\n")

    verify = FIXTURES / "task-reverification"
    write(verify / "supplied-runner-result.json", json.dumps({
        "evidence_kind": "supplied synthetic evidence",
        "run_id": "fixture-success-1",
        "command": "python3 -c 'assert 2 == 2'",
        "exit_code": 0,
        "suite_scope": "fixture value behavior only",
        "output": "synthetic runner: success",
        "source_identity": "supplied fixture identity",
        "config_identity": "none",
        "environment_identity": "synthetic fixture runner",
    }, indent=2) + "\n")

    auth = FIXTURES / "authorization-cadence"
    for variant in ("A-file", "B-inline", "C-retention", "D-walkthrough"):
        target = auth / "variants" / variant
        target.mkdir(parents=True)
        shutil.copy2(auth / "request.md", target / "request.md")
        shutil.copy2(auth / "findings.md", target / "findings.md")

    depth = FIXTURES / "review-depth-severity"
    for variant in ("small-fee", "cross-service-auth"):
        target = depth / "variants" / variant
        target.mkdir(parents=True)
        for rel in ("calc.py", "tests/test_calc.py", "README.md", ".github/workflows/test.yml", "auth.py", "proposal.md"):
            src = depth / rel
            if src.exists():
                dst = target / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)

    reuse = FIXTURES / "check-reuse"
    fee = by_id["existing-test-home"]
    base = reuse / "variants" / "matching"
    materialize(fee, base)
    write(base / "commands.json", (reuse / "commands.json").read_text())
    write(base / "calc.py", "def fee(amount):\n    if amount < 0:\n        raise ValueError(\"amount must be nonnegative\")\n    return amount * 0.02\n")
    write(base / "tests/test_calc.py", "import unittest\nfrom calc import fee\n\nclass FeeTests(unittest.TestCase):\n    def test_negative(self):\n        with self.assertRaises(ValueError):\n            fee(-1)\n\n    def test_zero(self):\n        self.assertEqual(fee(0), 0)\n\n    def test_positive(self):\n        self.assertEqual(fee(100), 2)\n")
    for variant in ("source-changed", "config-changed", "blocked-integration", "successful-subset", "staging-only-difference", "missing-prod-key", "browser-unavailable"):
        target = reuse / "variants" / variant
        shutil.copytree(base, target)
        if variant == "source-changed":
            write(target / "calc.py", (target / "calc.py").read_text() + "\n# relevant source mutation\n")
        elif variant == "config-changed":
            write(target / "test-config.json", '{"rate": 0.03}\n')
        elif variant == "blocked-integration":
            write(target / "integration.status", "BLOCKED: required database unavailable\n")
        elif variant == "successful-subset":
            write(target / "subset.status", "PASS: one focused test only; full suite not run\n")
        elif variant == "staging-only-difference":
            write(target / "staging.env.example", "OPTIONAL_BANNER=staging\n")
        elif variant == "missing-prod-key":
            write(target / "requirements.env", "PROD_SIGNING_KEY is required\n")
        elif variant == "browser-unavailable":
            write(target / "browser.status", "No supplied browser screenshot or current-build browser observation.\n")

    incident = FIXTURES / "incident-causality"
    for variant in ("A", "B", "C"):
        target = incident / "variants" / variant
        target.mkdir(parents=True)
        for rel in ("source.py", "race.py", "incident.log"):
            shutil.copy2(incident / rel, target / rel)
    write(incident / "variants" / "C" / "synthetic-runtime-transcript.txt", """SYNTHETIC FIXTURE EVIDENCE — not a live-system observation
request_id=req-c-001 input={key:order-42} config=dedupe-v1 build=build-candidate-7
2026-09-06T10:00:00.100Z worker-1 apply(order-42): key absent
2026-09-06T10:00:00.101Z worker-2 apply(order-42): key absent
2026-09-06T10:00:00.102Z worker-1 side_effect=applied
2026-09-06T10:00:00.103Z worker-2 side_effect=applied
Observed duplicate application for the same request key in the named build/config.
Competing timeout-only hypothesis refuted for this synthetic variant: duplicate side effects precede the timeout and have distinct worker traces.
""")

    manifests = []
    for path in sorted(FIXTURES.rglob("*")):
        if path.is_file() and ".git" not in path.parts:
            manifests.append({"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": digest(path)})
    write(ROOT / "evidence" / "fixture-input-manifest.json", json.dumps({"files": manifests}, indent=2) + "\n")
    write(ROOT / "evidence" / "setup-record.json", json.dumps({"script": "setup_fixtures.py", "selected_order": SELECTED, "actions": setup_log}, indent=2) + "\n")


if __name__ == "__main__":
    main()
