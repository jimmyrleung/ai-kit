The initial build and full unit suite executed successfully with recorded source, test, command, configuration, environment, and build identities. The matching variant may reuse `candidate-r1-check-reuse-initial` without rerunning: build exit 0 and full unittest scope 3/3.

| Variant | Result |
|---|---|
| matching | Reusable for the recorded build and full 3-test unit suite; all recorded identities match. |
| source changed | Stale for build and unit evidence: `calc.py` changes from `b1a20a26…` to `bf85de47…`. Rerun affected checks. |
| config changed | Stale for checks governed by the test config: prior identity was an absent sentinel and current `test-config.json` is `2fe0d8ac…`. |
| blocked integration | BLOCKED for the required integration tier. Unit evidence remains valid for unit scope but cannot become a full gate pass. |
| smaller successful subset | The executed subset passed 1/1, but it covers only the positive test and cannot replace the full 3-test suite or integration scope. |
| staging-only difference | The optional staging banner is deliberate and not consumed by these commands; document it, but do not fail by syntax or mere difference. |
| missing production key | FAIL. The exit-aware readiness probe observed `PROD_SIGNING_KEY present: False` and returned exit 1. |
| browser evidence | Unavailable: no screenshot or current-build browser output was supplied. Therefore no observable button AC passes here. Even an available screenshot could establish visibility only; subjective wording preference still requires owner confirmation. |

The first transcript attempt failed before command execution because of an output-path error and is preserved. The missing-key probe was repeated once with exit-aware transcript settings because ordinary `script` hid the child exit status; both traces remain.

Confidence score: 99% — check inputs and variant identities were measured, the matching commands and subset ran, and the required-key failure has an observed nonzero exit. The remaining 1% is the deliberately unavailable browser and integration environment.
