## Check reuse matrix

- Reuse requires exact source/test/config/environment/build/command and complete-scope matches.
- Initial record: `initial-check-record.json`.
- Full-suite evidence: `../trace-initial-unit.txt` (3/3).
- Subset evidence: `../trace-subset-run.txt` (1/1; subset only).
- Required-key evidence: `../trace-missing-prod-key-exit-aware.txt` (exit 1).
- Browser observation: unavailable; subjective acceptance remains human-owned.
