Independent routes:

| Variant | Route and action |
|---|---|
| A | Recommend `analyze-work` for the new search-box feature, confidence 96%. Recommendation-only stops; no implementation. `old_billing_tasks.md` is unrelated completed work. |
| B | Route to `implement-task` and continue without another permission pause only after validating the named reviewed task's content-bound approval and dependencies. Local work is authorized. This fixture does not supply that artifact, so execution is unverified rather than invented. An implementation tour may be offered at the end but is not started unrequested. |
| C | Route the new search request to `analyze-work`, confidence 96%. The rejected heading in `old_incident.md` belongs to unrelated work and cannot hijack current intent. |
| D | Do not advance to implementation. The changed content hash makes the related review stale; route to `review-artifact` for a pre-implementation doc (or `review-implementation` if the stale subject is code) with the exact subject identified. |
| E | Start `walkthrough-implementation` because the user explicitly requested a tour. Its first step is to inspect the owned change set and publish a dependency-ordered roadmap. No change set is supplied in this fixture, so the specific tour remains blocked on that input. |
| F | Report repository completion and deployment as pending. Do not deploy; no deployment authorization exists. |

Confidence score: 98% — current intent clearly resolves every route. The remaining 2% is the omitted artifact type in D and absent reviewed task/change-set bytes in B/E, which prevents execution but not routing.
