Resolved review scope: Task A only, base `8baddca5be6909f1b04d4da76e733e5cbdf0a07d` (`fixture-base`), HEAD `bcd7f716b742f3bfd2683f17ca1e04d46edc4d87`. The current Task A content is reviewable, but the verdict is `Needs revision`: the implementation rejects negative values, while the extra comment and renamed documentation do not add evidence for AC-A1. No tests are declared or present, so the acceptance criterion is not verified by execution.

Coverage inspected each transition once:

- Committed (`fixture-base → HEAD`): `calc.py` adds the negative guard. Base bytes `4efd07b3…`; committed bytes `31c17039…`.
- Staged (`HEAD → index`): `calc.py` changes the exception message. Index bytes `b1a20a26…`. `old.md → new.md` is a 100% rename, with both names recorded; bytes `a6dfd629…`.
- Unstaged (`index → worktree`): `calc.py` adds the percentage comment. Current bytes `c23031aa…`.
- Untracked: `fresh.txt`, read and hashed as `6dc255d1…`.
- Excluded: `unrelated.txt` belongs to Task B (`tasks.md:6-9`) and was already present at the selected base. Its current bytes are `59b4015f…`; it is context only, not a Task A defect.

Current content is bound by the complete SHA-256 values in `trace-layer-hashes.txt` and `trace-final-bytes.txt`. HEAD plus a dirty marker alone would be insufficient because it would collapse the committed, index, worktree, and untracked states.

Confidence score: 98% — every intended path and Git layer was inspected directly. The remaining 2% is the owner-level judgment about whether the documentation-only files were intentionally required despite no stated link purpose.
