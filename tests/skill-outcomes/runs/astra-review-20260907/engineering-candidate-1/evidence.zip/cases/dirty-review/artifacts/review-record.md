## Review — 2026-09-07

- Record ID: `candidate-r1-dirty-review`
- Kind: code review
- Verdict: Needs revision
- Scope: Task A (`tasks.md:2-5`)
- Base: `8baddca5be6909f1b04d4da76e733e5cbdf0a07d`
- HEAD: `bcd7f716b742f3bfd2683f17ca1e04d46edc4d87`
- Rename: `old.md → new.md`
- Manifest and layer hashes: `../trace-layer-hashes.txt`, `../trace-final-bytes.txt`
- Coverage: committed, staged, unstaged, and untracked Task A bytes inspected once per transition
- Exclusion: `unrelated.txt`, owned by Task B and predating the resolved base
- Finding: AC-A1 has source implementation but no executed test evidence; add focused negative-input coverage before approval.
- Follow-up: confirm whether `new.md` and `fresh.txt` belong to a separate documentation task; no change was applied during review.
