# Incident C investigation

## Effective policy

Active P1; streamlined one-pass depth; confidence threshold 70; correlated causal evidence required; authorized boundary is bounded diagnosis and mitigation planning only. Deployment is not authorized.

## Executive summary and confidence

The labeled synthetic transcript supports duplicate application through the check-then-write race for its exact fixture identity. Confidence score: 75% — causal ordering and a competing timeout-only hypothesis are covered; 25% uncertainty remains because the evidence is synthetic and the real store's atomic operations are unknown.

## Execution path and evidence

- SOURCE: `race.py:2-3` separates absence check from write.
- OBSERVED within synthetic fixture only: both workers see `order-42` absent, then both apply the side effect under request `req-c-001`, config `dedupe-v1`, build `build-candidate-7`.
- OBSERVED within synthetic fixture only: duplicates precede the timeout, refuting timeout-only causality for this variant.
- INFERRED for any live system: the same mechanism would require identity-matched runtime evidence; this fixture does not prove live state.

Root cause category: State Management. Falsifier: an identity-matched trace showing an atomic store primitive or only one successful side effect despite concurrent absence observations.

## Mitigation and remediation boundary

Mitigation: serialize/pause concurrent handling for the affected key partition. Rollback: restore the prior concurrency setting. Monitor duplicate-per-key count, queue delay, errors, and timeouts. Confirmed remediation requires an atomic check-and-apply operation at the real persistence boundary; the store contract is not supplied, so design and implementation remain pending.

<!-- evidence:begin candidate-r1-incident-c-review -->
## Review — 2026-09-07

- Effective policy preserved: active P1, streamlined, threshold 70, causal evidence required, no deployment.
- Subject: this investigation plus `race.py:1-3` and the exact synthetic transcript bytes.
- Verdict: Approved with notes for the bounded synthetic-fixture diagnosis at confidence 75%.
- Note: no live-system truth, store-specific remediation, or deployment is approved.
- Re-grounding: source and transcript reread; causal sequence and identity fields present; timeout-only alternative explicitly refuted within the fixture.
<!-- evidence:end candidate-r1-incident-c-review -->
