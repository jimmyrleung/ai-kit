# Incident A investigation

## Effective policy

Active P1; streamlined depth; threshold 70; causal runtime evidence required; no deployment authorization.

## Executive summary and confidence

The source admits a race, but the incident cause is unconfirmed. Confidence score: 45% — SOURCE shows a plausible mechanism; 55% uncertainty is the missing evidence that the branch ran and produced this timeout.

## Trace and root-cause status

- SOURCE: `race.py:1-3` checks absence before writing, leaving a concurrency window.
- OBSERVED: `incident.log:1` records a timeout at 10:00Z.
- OBSERVED: `incident.log:2` says no key-level trace or branch execution is captured.
- INFERRED: concurrent callers may both pass line 2. This is a candidate, not confirmed causality.

Falsifier/next probe: capture complete per-key, per-worker check/write traces for the affected request/build/config after a positive-control event proves the channel works. A single apply path with the timeout arising elsewhere refutes this hypothesis.

## Mitigation boundary

An authorized mitigation could serialize the affected key partition, with rollback to the prior concurrency setting and monitoring for duplicates, queue delay, errors, and timeouts. No such action or deployment is authorized here.
