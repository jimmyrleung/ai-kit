# Negative fee investigation

## Effective policy

Normal local-defect depth; threshold 90; no production linkage or deployment authorization.

## Executive summary and confidence

Negative input returns a negative fee because validation is absent at `source.py:1-2`. Confidence score: 99% — the deterministic local reproduction returned `-0.02`; 1% uncertainty is the unstated numeric-type policy beyond the tested integer.

## Evidence and minimal solution

- SOURCE: `source.py:1-2` multiplies every amount without a guard.
- OBSERVED: `source.fee(-1)` returned `-0.02` in `../trace-variant-b.txt`.
- Expected: the supplied contract forbids a negative result.

Root cause category: Data Validation. Falsifier: a current-build reproduction that rejects `-1` would disprove this diagnosis. Minimal fix: reject `amount < 0` at `source.py:1-2`, with negative, zero, and positive tests. This proves a local defect only; no production incident relationship is asserted.
