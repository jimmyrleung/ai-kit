## Verification

- `calc.py`: focused negative-value guard.
- `tests/test_calc_validation.py`: justified new file; `AGENTS.md:1` requires validation failures here.
- `tests/test_calc.py`: existing normal-behavior home, extended for zero and retains positive.
- Command: `python3 -m unittest discover -s tests`.
- Result: PASS, 3/3 tests.
- Scope: no speculative abstraction or unrelated edits.
