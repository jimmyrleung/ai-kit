Implemented the focused guard and created `tests/test_calc_validation.py` because `AGENTS.md` explicitly assigns validation-failure scenarios to that file. Normal zero and positive behavior remains in the existing `tests/test_calc.py`.

The documented/CI command executed successfully: 3/3 unittest cases passed. Negative input raises `ValueError`; zero returns `0`; positive `100` returns `2`. No helper, plugin, refactor, or unrelated cleanup was added.

Confidence score: 100% — the new file is required by a direct repository convention and every requested behavior was executed.
