# Executable task graph

Source: `requirements.md:1-2`. Approach: smallest spec-carrying graph for the supplied lifecycle and resource constraints.

| Task | Work | Depends on | Lifecycle | Resource | Status | Ready now |
|---|---|---|---|---|---|---|
| 1 | Implement shared-code change A and its tests | — | pre-merge | writes `shared.py` | Not Started | yes |
| 2 | Implement shared-code change B and its tests | 1 | pre-merge | writes `shared.py` | Not Started | no |
| 3 | Validate migration A | — | pre-merge | writes scratch DB | Not Started | yes |
| 4 | Validate migration B | 3 (resource serialization) | pre-merge | writes same scratch DB | Not Started | no |
| 5 | Read-only inspection A | — | pre-merge | read-only | Not Started | yes |
| 6 | Read-only inspection B | — | pre-merge | read-only | Not Started | yes |
| 7 | Inspect completed shared-code result | 2 | pre-merge | read-only, consumes Task 2 | Not Started | no |
| 8 | Repository review, tests, QA, and GO | 2, 3, 4, 5, 6, 7 | pre-merge | repository evidence | Not Started | no |
| 9 | Deploy approved repository result | 8 | deploy | deployment target | Not Started | no |
| 10 | Live rehearsal | 9 | live | deployed environment | Not Started | no |

Dependency flow: `(1 → 2 → 7) + (3 → 4) + 5 + 6 → 8 repository GO → 9 deploy → 10 live rehearsal`.

Potential concurrency is distinct from readiness. Tasks 1, 3, 5, and 6 can start and overlap. Tasks 3 and 4 are serialized because separate branches do not isolate one mutable scratch database. Tasks 1 and 2 are serialized because they write the same file.

Each task retains its own status and evidence. Task 8 requires repository build/test results plus both scratch migration results; it never claims Task 9 or 10 complete. Task 9 requires the recorded repository GO. Task 10 requires observed deployed state. If the repository-only variant omits Tasks 9–10, the normal completion path ends at Task 8 after implementation review and repository QA.

Locked decisions are the lifecycle rules stated in `requirements.md:2` and the explicit resource constraints in the user prompt; no deployment is executed or implied.
