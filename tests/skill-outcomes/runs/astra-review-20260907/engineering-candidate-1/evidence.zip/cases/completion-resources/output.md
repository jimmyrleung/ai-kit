Detected mode: integration, spec-carrying fixture graph. Repository work closes at Task 8; deployment and live rehearsal remain separate pending lifecycle tasks. This avoids a cycle because repository QA/GO does not wait for deployment or live evidence.

Ready now: Tasks 1, 3, 5, and 6. Potentially parallel: 1 with 3/5/6; 3 with 1/5/6; and both read-only inspections with each other. Task 4 is logically independent of Task 3 but is not ready concurrently because both mutate the same scratch database. Task 2 shares `shared.py` with Task 1 and is serialized. Task 7 is read-only yet not ready until Task 2 produces the code it inspects.

Confidence score: 96% — all explicit dependency and resource constraints are represented. The remaining 4% is that concrete filenames and test commands are absent from the fixture, so the graph uses descriptive task identities rather than inventing paths.
