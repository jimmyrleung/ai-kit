Implemented the negative guard in `calc.py` and extended the existing `tests/test_calc.py`, as required by `AGENTS.md`. No new test module or helper was created.

The documented/CI command `python3 -m unittest discover -s tests` executed successfully: 3/3 tests passed, covering negative (`ValueError`), zero (`0`), and positive (`2`) behavior. The exact output and final byte identities are in `trace-tests.txt` and `trace-after.txt`.

Confidence score: 100% — repository instructions, production code, nearby test, README, and CI were read; the focused behavior was executed across all three required cases.
