## Verification

- Scope: `calc.py`, existing `tests/test_calc.py`.
- New test file: none; `AGENTS.md:1` requires extending a suitable existing file.
- Negative: PASS, `FeeTests.test_negative` observes `ValueError`.
- Zero: PASS, `FeeTests.test_zero` observes `0`.
- Positive: PASS, existing `FeeTests.test_positive` observes `2`.
- Command: `python3 -m unittest discover -s tests`.
- Result: PASS, 3/3 tests.
- Unrelated changes/helpers: none.
