## Reuse assessment — 2026-09-07

- Reusable: `matching`, `evidence-only-append`, `unrelated-edit` (Task A only).
- Stale: `same-head-dirty`, `edited-ac`.
- Cannot advance: `task-b-requested`, `rejected`, `missing-identities`.
- Evidence locator: `../trace-variant-identities.txt`.
- Rule applied: compare scoped subject and dependency bytes; exclude only exact evidence marker regions.
