Evidence reuse results:

| Variant | Result | Reason |
|---|---|---|
| matching | reusable | Approved record, Task A scope, `source.py` hash `9c86f318…`, and Task A requirement hash `34a3ca7f…` all match. |
| same-HEAD dirty source edit | stale | `source.py` is now `9e09c649…`; unchanged HEAD cannot preserve affected content identity. |
| edited reviewed AC | stale | Task A dependency hash changes from `34a3ca7f…` to `b67bae8d…`. |
| Task B requested | unverified for Task B | The record names Task A only; it cannot cover another task even though the bytes it did cover still match. |
| rejected verdict | rejected / cannot advance | Content matches, but the recorded verdict is Rejected. |
| evidence-only append | reusable | Subject and Task A dependency hashes match. The appended note is wholly inside exact evidence delimiters, so it does not self-invalidate the subject. |
| unrelated file edit | reusable for Task A | `unrelated.txt` is outside the record's path and dependency scope; Task A identities still match. |
| missing identities | unverified | Approval prose without a scoped manifest and dependency identity is not reusable. |

The exact recomputed hashes are in `trace-variant-identities.txt`; no timestamp, filename, or same-HEAD shortcut was used. Confidence score: 100% — each row is resolved directly from the version-1 record and recomputed scoped bytes.
