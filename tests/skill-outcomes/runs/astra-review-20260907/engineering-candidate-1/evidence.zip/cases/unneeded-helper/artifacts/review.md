## Review — 2026-09-07

Verdict: Needs revision.

| Proposed addition | Disposition | Evidence |
|---|---|---|
| Negative guard in `fee` | retain | `calc.py:1-2`; `README.md:1` |
| Meaningful tests in existing home | retain and extend | `tests/test_calc.py:1-5`; CI command at `.github/workflows/test.yml:7` |
| `ValidationFactory` | remove | no repository use or multi-strategy requirement found |
| Plugin registry | remove | no plugin boundary or consumer found |
| Duplicate test module | remove | existing test file is suitable; duplication adds no behavior |
| Reformat all modules | remove | unrelated to requested validation |

Review depth: one independent pass, justified by the small isolated scope. No cosmetic refactor was requested.
