Recommendation: keep the one-function guard and extend the existing `tests/test_calc.py`; reject the other additions.

- Focused guard: needed. `calc.py:1-2` currently accepts negatives, while `README.md:1` requires `ValueError`.
- Existing test home: needed and suitable. `tests/test_calc.py:1-5` already uses unittest and imports `fee`; add negative and zero coverage there while preserving the positive test.
- `ValidationFactory` and plugin registry: unsupported abstraction. The supplied repository has one two-line function, no validation framework, and no plugin call site (`trace-inspection.txt`).
- `tests/duplicate_test_calc.py`: duplicated coverage with no convention or separate concern. A new file would be acceptable when a repository convention requires it or no suitable home exists, but neither condition holds in this fixture.
- Reformat every module: unrelated cosmetic work. It adds review surface without helping the negative-input contract.

No source changes were applied because the request is a review. Confidence score: 99% — every supplied code, test, documentation, CI, and proposal file was inspected; 1% remains because the proposed abstractions have no implementation diff to review beyond their stated intent.
