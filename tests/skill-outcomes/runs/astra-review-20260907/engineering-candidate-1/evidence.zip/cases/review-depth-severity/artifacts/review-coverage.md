## Review coverage — 2026-09-07

### Small isolated fee guard

- Depth: one combined correctness/convention/simplicity pass.
- Grounded source: `calc.py:1-2`, `tests/test_calc.py:1-5`, README and CI.
- Observed: current full supplied unittest suite passes 1/1 positive test.
- Verdict: unverified implementation; no guard diff or negative/zero execution supplied.

### Cross-service authorization change

- Depth: two separate sequential passes due auth and cross-service risk. Native workers are callable but explicitly unauthorized by the trial dispatch; independence is weaker than separate agents.
- Lane 1, highest-risk layer: token issuer → claims/role → `allow` decision. Supplied issuer/role code is absent.
- Lane 2: `allow` → resource-policy consumers and runtime matrix. Search found no consumer in the supplied root beyond duplicate fixture copies.
- Parent re-grounding: `auth.py:1-2` and `proposal.md:1-2` read directly; current baseline executed (`same_tenant=True`, `cross_tenant=False`).
- Finding: High severity, INFERRED potential cross-tenant bypass; certainty is limited, issue retained with exact next probe.
- No unrelated refactor or automatic fix was requested or applied.
