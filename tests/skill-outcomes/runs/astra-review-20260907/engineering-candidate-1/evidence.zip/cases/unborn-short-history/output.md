Both repositories resolve without a parent-window assumption.

- Unborn: `HEAD` is absent, proven by the failed `git rev-parse --verify HEAD` probe. The explicit base is the Git empty tree `4b825dc642cb6eb9a060e54bf8d69288fbee4904`, computed with empty standard input. Against that base, the index contains `tasks.md` and a `value.py` that returns `3`; the worktree then changes `value.py` to return `2`. The executed probe prints `2`, satisfying AC-1 for the current worktree.
- Single commit: `git rev-list --count HEAD` is exactly `1`; HEAD is `7dbc169391174f1788bf1bf231297ec8bde00962`. The staged transition changes `value()` from `1` to `3`; the unstaged transition changes it from `3` to `2`. No `HEAD^`, `HEAD~N`, or fixed ancestor window was called. The current behavior probe prints `2`.

In both variants, current `value.py` bytes are `d3fe3723…`, and the staged and unstaged contents are separately accounted for. Confidence score: 100% — history length, absent/present HEAD, both layer diffs, byte identities, and current behavior were all observed directly.
