## Verification — candidate repeat 1

| Variant | Base | HEAD | Staged | Unstaged | Current AC-1 |
|---|---|---|---|---|---|
| unborn | empty tree `4b825dc…` | absent | `value()` returns 3 | `value()` returns 2 | PASS (executed, output `2`) |
| single-commit | HEAD `7dbc169…` | one commit | `value()` returns 3 | `value()` returns 2 | PASS (executed, output `2`) |

Evidence: `../trace-unborn-empty-tree.txt`, `../trace-unborn-head-probe.txt`, `../trace-unborn-scope.txt`, and `../trace-single-scope.txt`.
