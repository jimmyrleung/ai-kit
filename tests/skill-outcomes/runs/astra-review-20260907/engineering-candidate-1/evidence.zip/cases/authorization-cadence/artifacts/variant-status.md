## Variant status

| Variant | Artifact | Permission interruption | Status |
|---|---|---|---|
| A file input | `fixtures/authorization-cadence/variants/A-file/search_box_analysis.md` | none | bounded draft written |
| B inline input | `fixtures/authorization-cadence/variants/B-inline/search_box_analysis.md` | none | bounded draft written |
| C retention-dependent | `fixtures/authorization-cadence/variants/C-retention/search_box_analysis.md` | none; one required clarification recorded | blocked only on retention-dependent conclusions |
| D walkthrough | `fixtures/authorization-cadence/variants/D-walkthrough/findings.md` | item 1 question pending | stopped before item 2 |
