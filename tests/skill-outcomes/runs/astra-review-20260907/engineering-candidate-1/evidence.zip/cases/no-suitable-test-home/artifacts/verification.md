## Verification

- New file: `tests/test_calc.py`, justified because `tests/test_label.py` is unrelated and `AGENTS.md:1` directs a focused new unittest module.
- Negative: PASS (`ValueError`).
- Zero: PASS (`0`).
- Positive: PASS (`2`).
- Command: `python3 -m unittest discover -s tests`.
- Result: PASS, 4/4 tests across the full discovered suite.
