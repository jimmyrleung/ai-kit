Implemented the negative guard and created `tests/test_calc.py`. The only existing test module, `tests/test_label.py`, covers unrelated label formatting, and `AGENTS.md` explicitly says no existing module covers `fee`; it is not a suitable home.

The documented/CI unittest command executed successfully: 4/4 tests passed, including negative, zero, and positive fee behavior plus the unchanged label test. No helper, refactor, or unrelated cleanup was introduced.

Confidence score: 100% — the absence of a suitable existing home is explicit in repository instructions and confirmed by reading the only nearby test module.
