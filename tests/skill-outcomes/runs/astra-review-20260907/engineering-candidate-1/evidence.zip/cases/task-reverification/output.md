Task 1 resolves to the `### Task 1` section ending immediately before `### Task 2`. Its authoritative AC source contains exactly one item: `AC-1: returns 2`. The testing checkbox, old generated `AC #9`, and Task 2's `AC-2` are excluded. Two new delimited Verify records were appended inside that boundary and the older run was preserved.

The supplied successful runner result was used as clearly labeled synthetic evidence. Run 1 cites it; run 2 reuses it with matching supplied identities and does not claim a new execution.

Additional scope resolutions:

- Numbered item: Task 1 begins at `numbered.md:2` and ends before peer item 2 at line 5. Its AC set is only `AC-1: returns 2`.
- Tasks-doc-less fix: task ID `BUG-1`; task locator `investigation.md:4-5` (`## Proposed fix`); expected-behavior source `investigation.md:2-3`; designated fix AC source `fix-techspec.md:2-4`. The deduplicated handoff is expected `returns 2`, `AC-F1: returns 2`, and `AC-F2: negative input raises ValueError`, with both source locators retained.
- Task QA handoff remains scoped to Task 1. A later prefix QA call must derive the broader prefix independently and cannot inherit this one-task bundle.

Confidence score: 99% — all boundaries and input bytes were inspected. The remaining 1% reflects that the runner result is intentionally synthetic rather than an execution of project code.
