## Scope handoffs

### Heading Task 1

- task_id: `Task 1`
- task_locator: `tasks.md:2` through before `tasks.md:10`
- ac_source: `tasks.md:6-7`
- acceptance_criteria: [`AC-1: returns 2`]
- evidence records: `candidate-r1-task1-run1`, `candidate-r1-task1-run2` in the produced fixture `tasks.md`

### Numbered Task 1

- task_id: `Task 1`
- task_locator: `numbered.md:2-4`
- ac_source: `numbered.md:3-4`
- acceptance_criteria: [`AC-1: returns 2`]

### Tasks-doc-less BUG-1 fix

- task_id: `BUG-1`
- tasks_doc_path: `investigation.md`
- task_locator: `investigation.md:4-5`
- ac_source: `investigation.md:2-3` plus `fix-techspec.md:2-4`
- acceptance_criteria: [`Expected: returns 2`, `AC-F1: returns 2`, `AC-F2: negative input raises ValueError`]
