#!/usr/bin/env python3
"""Preserve per-case prompts and exact loaded candidate procedure bytes."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SNAP = ROOT / "input-snapshots"
BODIES = SNAP / "frozen-bodies"
CASES = json.loads((SNAP / "cases.json").read_text(encoding="utf-8"))["cases"]
ORDER = [
    "dirty-review", "unborn-short-history", "review-invalidation", "task-reverification",
    "consumer-closure", "completion-resources", "existing-test-home", "convention-new-test",
    "no-suitable-test-home", "unneeded-helper", "authorization-cadence", "review-depth-severity",
    "check-reuse", "intent-routing", "incident-causality",
]
CONTRACTS = ["authorized-work", "engineering-change", "change-evidence", "feedback"]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    by_id = {case["id"]: case for case in CASES}
    for case_id in ORDER:
        case = by_id[case_id]
        case_root = ROOT / "cases" / case_id
        inputs = case_root / "inputs"
        loaded = inputs / "loaded-bodies"
        loaded.mkdir(parents=True, exist_ok=False)
        (inputs / "prompt.md").write_text(case["prompt"] + "\n", encoding="utf-8")
        shutil.copy2(SNAP / "cases.json", inputs / "cases.json")
        manifest = []
        for skill in case["skills"]:
            source = BODIES / "skills" / skill / "SKILL.md"
            if source.exists():
                dest = loaded / "skills" / skill / "SKILL.md"
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, dest)
                manifest.append({"kind": "skill", "name": skill, "path": dest.relative_to(case_root).as_posix(), "sha256": sha(dest), "bytes": dest.stat().st_size, "availability": "available"})
            else:
                manifest.append({"kind": "skill", "name": skill, "path": None, "sha256": None, "bytes": None, "availability": "unavailable", "reason": "Missing from frozen candidate body set; no substitution."})
        for contract in CONTRACTS:
            source = BODIES / "docs" / "contracts" / f"{contract}.md"
            dest = loaded / "docs" / "contracts" / source.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
            manifest.append({"kind": "reference", "name": contract, "path": dest.relative_to(case_root).as_posix(), "sha256": sha(dest), "bytes": dest.stat().st_size, "availability": "available"})
        (inputs / "loaded-manifest.json").write_text(json.dumps({"condition": "candidate", "repeat": 1, "execution_kind": "supplied-body-procedure", "files": manifest}, indent=2) + "\n", encoding="utf-8")

    for name, case_id, prompt in (
        ("consumer-closure-complex", "consumer-closure", "Analyze changing fetch() to return Result(value, error). Produce a reference map only; do not provide an implementation recipe.\n"),
        ("existing-test-home-small", "existing-test-home", "Analyze rejecting negative amounts in fee(). Produce a reference map only; do not implement.\n"),
    ):
        root = ROOT / "additional-analysis" / name
        inputs = root / "inputs"
        loaded = inputs / "loaded-bodies"
        loaded.mkdir(parents=True, exist_ok=False)
        (inputs / "prompt.md").write_text(prompt, encoding="utf-8")
        source = BODIES / "skills" / "analyze-work" / "SKILL.md"
        dest = loaded / "skills" / "analyze-work" / "SKILL.md"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
        manifest = [{"kind": "skill", "name": "analyze-work", "path": dest.relative_to(root).as_posix(), "sha256": sha(dest), "bytes": dest.stat().st_size, "availability": "available"}]
        for contract in ("authorized-work", "engineering-change"):
            source = BODIES / "docs" / "contracts" / f"{contract}.md"
            dest = loaded / "docs" / "contracts" / source.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
            manifest.append({"kind": "reference", "name": contract, "path": dest.relative_to(root).as_posix(), "sha256": sha(dest), "bytes": dest.stat().st_size, "availability": "available"})
        (inputs / "loaded-manifest.json").write_text(json.dumps({"condition": "candidate", "repeat": 1, "fixture_case": case_id, "execution_kind": "supplied-body-procedure", "files": manifest}, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
