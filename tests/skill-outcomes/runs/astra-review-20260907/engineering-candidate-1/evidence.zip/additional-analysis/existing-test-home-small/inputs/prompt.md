Analyze rejecting negative amounts in fee(). Produce a reference map only; do not implement.
