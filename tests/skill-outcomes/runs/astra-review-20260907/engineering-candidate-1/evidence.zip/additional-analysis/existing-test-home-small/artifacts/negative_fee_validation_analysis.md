# Negative fee validation — analysis

## Overview

Mode: integration. The requested behavior is to reject negative amounts while preserving zero and positive results. Scope is the existing `fee` function and its existing unittest home.

Confidence score: 98% — repository instructions, implementation, tests, documentation, and CI were inspected. 2% uncertainty remains because the required exception message and numeric-type policy are unstated; neither blocks locating the change and test surface.

## Entry point and current flow

`calc.py:1-2` defines `fee(amount)` and returns `amount * 0.02` for every input, so negative values currently produce negative fees. The only supplied caller is `tests/test_calc.py:5`, which checks the positive path. Repository search `rg -n "fee\(" . --glob "*.py" --glob "*.md" --glob "*.yml"` found one definition and one test call.

## Reuse and test home

`tests/test_calc.py` already imports and tests `fee`, uses `unittest.TestCase`, and is explicitly the suitable home under `AGENTS.md:1`. Extend it for negative and zero cases; no new test file or helper is justified. The required command is identical in `README.md:1` and `.github/workflows/test.yml:7`: `python3 -m unittest discover -s tests`.

## Essential files

| File | Role |
|---|---|
| `calc.py` | Existing production entry point for the validation boundary |
| `tests/test_calc.py` | Existing suitable unittest home for negative, zero, and positive behavior |

## Risks and constraints

- Preserve `fee(0) == 0` and current positive multiplication behavior.
- Test the negative exception plus zero and positive results with the repository's full discovery command.
- Keep the change local to the existing function and test module; there is no evidence for a reusable validation abstraction.
- Rollback is bounded to restoring the prior `calc.py` behavior and corresponding assertions together. The change does not touch stored data or external resources.

## Confidence & unverified

The mapped source, test home, and command are inspected facts. Unverified decisions for the design/implementation phase: exact exception message and behavior for nonnumeric inputs. Those questions do not require a larger reference map.
