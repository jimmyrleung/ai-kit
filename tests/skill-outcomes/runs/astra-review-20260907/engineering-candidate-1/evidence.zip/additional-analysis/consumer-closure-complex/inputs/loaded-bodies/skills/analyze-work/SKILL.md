---
name: analyze-work
description: "Pre-implementation analysis of upcoming work — a reference map (entry points, patterns to follow, similar features, scope boundaries, risks), not a design doc. Detects and adapts to the work type: integrating a feature into an existing codebase, starting a new project / greenfield build (vertical-slice guarded), or a refactor / tech-debt request. Produces {work_name}_analysis.md. Use when asked to analyze, audit, scope, or map a feature integration, a new project, or a refactor / tech debt before designing or implementing it."
---

# analyze-work — pre-implementation reference map

Map where the requested work lands, which existing patterns it should follow, and what it
could affect. Locate and reference; leave design decisions to `techspec`. If the output is an
implementation recipe, it is too detailed. Bug diagnosis belongs to `bug-investigation`;
unfamiliar territory without a defined change belongs to `lay-of-the-land`.

Apply [engineering change](../../docs/contracts/engineering-change.md) and
[authorized work](../../docs/contracts/authorized-work.md). Resolve these references from the
canonical skill directory through deployment links. Inspect repository instructions and nearby
production code, tests, docs, and CI; identify suitable reuse and test homes before proposing files.

## Inputs and mode

Accept a description file, inline request, PRD, context folder, reference implementation, or
recon map. Inspect supplied files and every named source before relying on them. Derive
`{work_name}` from the input family or a clear topic name; echo the name, output path, and mode.
Ask only if the work boundary or destination is ambiguous. Record clarified requirements in the
analysis (and a source description's Clarifications section when authorized); file and inline
inputs follow the same path.

- **integration**: a capability in existing code (default); map consumer-defined coverage.
- **greenfield**: no existing implementation; apply the Slice requirement contract below.
- **refactor**: preserve behavior while restructuring; map preserved contracts and risks.

For mixed work use the dominant mode and state the secondary lens. An XL scope with no useful
bounded map needs a scope decision; do not silently substitute a smaller objective.

## Evidence and exploration

1. Establish the requested outcome, constraints, edge/error cases, dependencies, and exclusions.
   Resolve missing load-bearing facts; other unknowns remain explicit open questions while useful
   independent exploration continues. Do not manufacture clarification rounds for clear requests.
2. Locate entry points, similar features, reusable helpers/services, configuration, and feature
   boundaries. Trace entry → output, transformations, state changes, side effects and integrations.
   In greenfield, inspect chosen-stack conventions and comparable examples instead of inventing
   existing code. Verify unstable library/framework facts with available current documentation.
3. Map architecture, auth/logging/caching where relevant, convention consistency, documentation
   gaps, and clarity. Describe a concrete weakness and its impact; poor style alone does not justify
   an unrelated prerequisite refactor. Map affected files, APIs, tables/models and external services.
4. **Consumer closure:** for every touched symbol/file, search the whole repository for callers
   and consumers; record the command, enumerated results and derived count. For missing
   proxies/routes/handlers/subscribers, start from the consumer call list and map each literal
   `consumer file:line → URL/signature/topic → provider route/handler`. Shared handlers do not
   merge distinct contracts. Inspect consumers on unchanged lines too.
5. **Conditional checks:** when copying a reference branch, diff every named entry-point file
   against it. For migrations/manifests registered by filename, compare base-branch history and
   content for same-name collisions. Carry relevant configuration/environment differences and
   dependency gaps forward; do not claim complete coverage from a partial search.
6. Re-ground findings against actual source. Distinguish inspected facts from inference; absence
   claims name searched roots, command, and remaining coverage limits. Record disagreement by
   the conflicting evidence and consequence, not vote count or a numeric confidence difference.

## Optional independent exploration

Small scope stays on the main thread. For distinct larger areas, use authorized native workers
when available; otherwise perform separate scoped passes and state the independence limit.
Each worker receives the work boundary and returns references, not a design: no implementation
recipe, at most two lines of code when needed to explain current behavior, no further delegation
or artifact writes, and a `## Confidence & unverified` footer naming gaps and absence-search scope.
Parent reads each output, verifies load-bearing sources, and tracks missing charter coverage.

## Mode-specific obligations

**Greenfield:** identify the smallest user-observable first slice and proposed reference-level
entry/structure, with ecosystem examples. Keep a stable `## Slice requirement` section containing
**Goal**, testable **Done-when** checkboxes (including errors/empty states), **Building on**, and
**Constraints**. If a supplied PRD owns this contract, link it and preserve its boundaries.
State **Deliberately NOT building yet** and what earns each deferred capability a place. Reject
horizontal scaffolding before a slice needs it, setup-only goals, speculative monitoring/security
sections, and invented success baselines. Do not design classes or the whole future system.

**Refactor:** state **Scope definition** (in/out/gray areas requiring decision), **Preserved
contracts**, good patterns and **Anti-patterns found** with locations/impact, and **Risk
classification** (breaking/non-breaking/unknown). Summary carries complexity, risk, and scope.
Identify behavior/test coverage that protects the transition and existing rollback constraints;
transition design belongs to the techspec. Integration needs no extra mode fields.

## Output and handoff

Write `{work_name}_analysis.md` alongside the supplied description or at the requested destination.
Use concise sections with real evidence; combine related fields when they repeat the same facts:

- **Overview**, mode, outcome and scope; **Confidence score** plus `Confidence & unverified`.
- **Entry points**, **Similar features / examples**, and **Execution flow** with source anchors.
- **Key components & responsibilities**, **Architecture insights**, and **Dependencies**.
- **Observations**, **Side effects / impact**, **Risks & considerations** (severity), and open questions.
- **Essential files** with suitable existing code/test homes and any justified new-file need.
- When applicable, keep **Files to Modify** (File/Purpose/Changes Needed), **Files to Create**
  (File/Purpose/Type), **APIs Affected** (Endpoint/Method/Changes), and **Database Changes**
  (Table/Change Type/Details). Omit empty tables; never invent rows to fill the shape.
- The mode-specific fields above and the consumer coverage ledger whenever that contract applies.

Keep source references and scope boundaries, not signatures, algorithms, error-handling recipes,
migration scripts or API schemas. A code quote is allowed only when it explains current state more
briefly than prose. For example: point at the existing export/permission pattern and its source;
do not prescribe an endpoint's validation/query/format implementation sequence.

Check the final map against the request and evidence coverage. A missing load-bearing fact blocks
a dependent recommendation; preserve it as an open question with the next probe. Confidence is a
reported assessment, not proof or permission. Write the authorized bounded draft, clearly marking
unverified portions, then offer `review-artifact` before design or implementation relies on it.
