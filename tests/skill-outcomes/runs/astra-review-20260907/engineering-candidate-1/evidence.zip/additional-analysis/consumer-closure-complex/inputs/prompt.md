Analyze changing fetch() to return Result(value, error). Produce a reference map only; do not provide an implementation recipe.
