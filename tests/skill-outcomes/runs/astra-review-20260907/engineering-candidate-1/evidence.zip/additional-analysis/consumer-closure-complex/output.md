Mode: integration. Work name: `fetch_result`. Output: `artifacts/fetch_result_analysis.md`. The map covers the requested return-contract change only; it contains no implementation recipe.
