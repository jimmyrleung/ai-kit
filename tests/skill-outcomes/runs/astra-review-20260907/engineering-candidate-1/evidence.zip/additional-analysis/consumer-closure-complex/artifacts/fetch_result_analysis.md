# Fetch result return contract — analysis

## Overview

Mode: integration. The requested outcome changes `client.fetch()` from a scalar return to a result object while keeping all executable consumers correct. This is a cross-module contract change; implementation details for the `Result` shape are deliberately unresolved.

Confidence score: 94% — producer, all Python consumers, the existing worker test, and the proposed plan were inspected. 6% uncertainty remains because no result type, API error contract, or API test convention is supplied; those facts block a techspec, not this reference map.

## Entry points and execution flow

- Producer: `client.py:1-2` returns integer `4`.
- API path: `api.py:1-3` imports `fetch` and computes `fetch() + 1`.
- Worker path: `worker.py:1-3` imports `fetch` and computes `fetch() * 2`.
- Existing observable check: `test_worker.py:1-3` imports `run` and expects `8`.

Current flow: `client.fetch → api.request` or `client.fetch → worker.run → test_worker.test_run`. A direct execution of `test_worker.test_run` passed. The attempted pytest invocation failed because pytest is not installed; both outcomes are preserved in the case traces.

## Consumer coverage ledger

Search command: `rg -n "fetch\(" --glob "*.py" .` at the fixture root.

| Result | Role | Contract impact |
|---|---|---|
| `client.py:1` | definition | return shape changes |
| `api.py:3` | consumer | scalar addition cannot consume a result object unchanged |
| `worker.py:3` | consumer | scalar multiplication cannot consume a result object unchanged |

Derived count: 2 executable consumers plus 1 definition. The unchanged worker line is included. The consumer-closure pass covers all supplied Python files; code outside this isolated fixture is unavailable.

## Similar features, reuse, and test homes

No comparable result wrapper or reusable helper exists in the supplied fixture; the search surface contains only these four Python files. `test_worker.py` is the suitable existing home for worker behavior and should be extended rather than replaced. No API test file is supplied, so the appropriate API test location remains an open convention question for the design phase.

## Essential files and ownership boundary

| File | Purpose in the change |
|---|---|
| `client.py` | owns the producer return contract |
| `api.py` | owns API-side consumption of success/error results |
| `worker.py` | owns worker-side consumption; omission would break arithmetic |
| `test_worker.py` | existing test home for preserved worker behavior and new error handling |

The owning contract task must include both consumers and the existing worker test. The proposed `plan.md` omits two of those files and cannot claim completion from “Test the API.”

## Risks and test constraints

- High: partial rollout leaves one consumer performing arithmetic on a result object. Consumer updates and producer activation need one coordinated compatibility boundary.
- Medium: error results may be interpreted differently by API and worker paths; the intended behavior must be specified before design.
- Testing must preserve the current worker success result and add error-result coverage. API success/error coverage needs a confirmed repository test home.
- Rollback must restore a mutually compatible producer/consumer set. Reverting only `client.py` or only one consumer could preserve the mismatch.

## Confidence & unverified

Inspected facts are grounded in the source and search trace. Unverified: result-object fields/semantics, API error behavior, API test conventions, and any consumers outside the supplied fixture. Next probe: supply or locate the result contract and repository-wide test conventions before technical design.
