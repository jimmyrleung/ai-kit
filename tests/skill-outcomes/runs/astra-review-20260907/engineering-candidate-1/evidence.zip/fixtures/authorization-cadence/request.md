Add a search box to filter the existing list by name. Keep existing data source.
