# Tasks
### Task A
Files: calc.py, old.md -> new.md, fresh.txt
#### Acceptance criteria
- AC-A1: reject negative amounts.
### Task B
Files: unrelated.txt
#### Acceptance criteria
- AC-B1: update other documentation.
