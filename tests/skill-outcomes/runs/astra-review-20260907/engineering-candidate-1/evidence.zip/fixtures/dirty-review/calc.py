def fee(amount):
    if amount < 0:
        raise ValueError("amount must be nonnegative")
    # Preserve the established percentage.
    return amount * 0.02
