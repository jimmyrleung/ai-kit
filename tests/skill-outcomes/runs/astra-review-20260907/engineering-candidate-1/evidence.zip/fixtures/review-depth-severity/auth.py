def allow(user, resource):
    return user.tenant == resource.tenant
