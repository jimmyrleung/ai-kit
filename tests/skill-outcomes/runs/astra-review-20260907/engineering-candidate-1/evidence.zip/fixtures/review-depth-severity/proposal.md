# Authorization change
Allow support users across tenants; token issuer and resource policy consumers require inspection.
