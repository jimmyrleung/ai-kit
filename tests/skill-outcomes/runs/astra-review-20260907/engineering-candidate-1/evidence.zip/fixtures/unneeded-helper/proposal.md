# Proposed change
Guard fee against amount < 0. Also add ValidationFactory, a plugin registry, duplicate tests/test_calc.py into tests/duplicate_test_calc.py, and reformat all modules.
