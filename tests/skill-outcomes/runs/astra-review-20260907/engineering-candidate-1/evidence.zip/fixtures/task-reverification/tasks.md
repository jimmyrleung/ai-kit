# Tasks
### Task 1
Files: value.py
#### Testing requirements
- [ ] Existing test green
#### Acceptance criteria
- [ ] AC-1: returns 2
#### Verify — old run
- [x] AC #9 old generated evidence
#### Verify — candidate repeat 1, run 1
<!-- evidence:begin candidate-r1-task1-run1 -->
- record_id: `candidate-r1-task1-run1`
- task_id: `Task 1`
- task_locator: `tasks.md` heading `### Task 1` through before `### Task 2`
- ac_source: `tasks.md` → `### Task 1` → `#### Acceptance criteria`
- acceptance_criteria: [`AC-1: returns 2`]
- base: `unavailable — this non-Git fixture supplies no repository base`
- declared_files: [`value.py`]
- observed_changes: `unavailable — value.py is not supplied in this fixture`
- budgets: `no budget pinned (acceptable)`
- test_commands: [`python3 -c 'assert 2 == 2'`]
- dependencies: `tasks.md AC source identity 8ecfce1c… before evidence append; supplied runner identities in supplied-runner-result.json`
- check_evidence: `fixture-success-1` — supplied synthetic evidence, not executed by this trial
- [x] Gate 1 — build/test: pass from supplied synthetic runner result `fixture-success-1` (exit 0; fixture value behavior only; no new execution claimed)
- [x] Gate 2 — AC checklist (1 item)
  - [x] AC-1 — returns 2: pass in supplied synthetic runner scope
- [x] Gate 3 — cross-cutting: pass (no pinned budget/version/config requirement in supplied fixture)
<!-- evidence:end candidate-r1-task1-run1 -->
#### Verify — candidate repeat 1, run 2
<!-- evidence:begin candidate-r1-task1-run2 -->
- record_id: `candidate-r1-task1-run2`
- task_id: `Task 1`
- task_locator: `tasks.md` heading `### Task 1` through before `### Task 2`
- ac_source: `tasks.md` → `### Task 1` → `#### Acceptance criteria`
- acceptance_criteria: [`AC-1: returns 2`]
- base: `unavailable — this non-Git fixture supplies no repository base`
- declared_files: [`value.py`]
- observed_changes: `unavailable — value.py is not supplied in this fixture`
- budgets: `no budget pinned (acceptable)`
- test_commands: [`python3 -c 'assert 2 == 2'`]
- dependencies: same Task 1 source bytes after excluding exact evidence regions; supplied runner identities unchanged
- check_evidence: reused `fixture-success-1` with matching supplied identities; not rerun and not claimed as a new execution
- [x] Gate 1 — build/test: pass from reusable supplied synthetic result `fixture-success-1`
- [x] Gate 2 — AC checklist (1 item)
  - [x] AC-1 — returns 2: pass in supplied synthetic runner scope
- [x] Gate 3 — cross-cutting: pass (no pinned budget/version/config requirement in supplied fixture)
<!-- evidence:end candidate-r1-task1-run2 -->
### Task 2
#### Acceptance criteria
- [ ] AC-2: returns 3
