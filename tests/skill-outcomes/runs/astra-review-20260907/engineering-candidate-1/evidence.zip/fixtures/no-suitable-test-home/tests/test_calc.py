import unittest

from calc import fee


class FeeTests(unittest.TestCase):
    def test_negative(self):
        with self.assertRaises(ValueError):
            fee(-1)

    def test_zero(self):
        self.assertEqual(fee(0), 0)

    def test_positive(self):
        self.assertEqual(fee(100), 2)
