def apply(key, store):
    if key not in store:
        store[key] = "applied"
