# Spec
## Task A requirements
- Return a strictly positive amount.
## Task B requirements
- Add a receipt.
