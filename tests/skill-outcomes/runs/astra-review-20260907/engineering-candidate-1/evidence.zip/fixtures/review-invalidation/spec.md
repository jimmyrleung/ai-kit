# Spec
## Task A requirements
- Return a nonnegative amount.
## Task B requirements
- Add a receipt.
