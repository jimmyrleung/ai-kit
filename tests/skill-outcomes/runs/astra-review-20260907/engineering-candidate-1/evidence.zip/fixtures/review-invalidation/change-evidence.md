<!-- evidence:begin initial-approved-task-a -->
```json
{
  "schema_version": 1,
  "record_id": "initial-approved-task-a",
  "kind": "artifact-review",
  "verdict": "Approved",
  "scope": {
    "task": "Task A",
    "paths": [
      "source.py"
    ],
    "base": "54b1b0ed0d99dcfcbbc77d125b256be15f3ac555"
  },
  "manifest": {
    "source.py": "9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9"
  },
  "dependencies": {
    "spec.md#Task A requirements": "34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30"
  },
  "evidence_exclusion": "Only exact evidence marker regions are excluded from subject bytes."
}
```
<!-- evidence:end initial-approved-task-a -->
