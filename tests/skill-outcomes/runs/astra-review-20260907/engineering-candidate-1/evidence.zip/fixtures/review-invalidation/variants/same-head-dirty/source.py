def amount():
    return -1
