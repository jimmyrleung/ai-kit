# Tasks
### Task 1
Files: value.py
#### Acceptance criteria
- AC-1: value() returns 2.
