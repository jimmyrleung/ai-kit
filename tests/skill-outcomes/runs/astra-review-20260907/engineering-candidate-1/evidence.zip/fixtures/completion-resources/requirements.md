# Required outcomes
Code + tests pass in repository. Scratch migration validation runs before repository GO. Deploy only after repository GO. Live rehearsal depends on deployed state.
