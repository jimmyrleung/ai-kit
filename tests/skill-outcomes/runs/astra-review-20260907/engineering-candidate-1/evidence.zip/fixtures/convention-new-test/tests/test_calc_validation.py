import unittest

from calc import fee


class FeeValidationTests(unittest.TestCase):
    def test_negative(self):
        with self.assertRaises(ValueError):
            fee(-1)
