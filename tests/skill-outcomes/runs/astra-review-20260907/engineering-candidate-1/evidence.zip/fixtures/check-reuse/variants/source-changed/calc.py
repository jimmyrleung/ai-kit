def fee(amount):
    if amount < 0:
        raise ValueError("amount must be nonnegative")
    return amount * 0.02

# relevant source mutation
