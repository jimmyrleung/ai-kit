def fetch():
    return 4
