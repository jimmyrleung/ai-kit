from client import fetch
def request():
    return fetch() + 1
