from client import fetch
def run():
    return fetch() * 2
