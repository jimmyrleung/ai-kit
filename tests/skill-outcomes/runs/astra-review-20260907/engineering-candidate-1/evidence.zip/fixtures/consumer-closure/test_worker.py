from worker import run
def test_run():
    assert run() == 8
