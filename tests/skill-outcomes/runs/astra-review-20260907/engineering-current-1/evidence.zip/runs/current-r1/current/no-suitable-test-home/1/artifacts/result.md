# Result

Implemented only the negative-amount guard in calc.py. Created focused tests/test_calc.py because the only existing module, tests/test_label.py, covers unrelated label behavior and AGENTS.md says no existing fee test home exists. The file follows the existing unittest pattern. Executed unittest discovery: 4/4 passed, including negative, zero, positive, and the existing label test. Executed compileall: exit 0. No helper, cleanup, or refactor was added.

Confidence score: 99% — the absence of a suitable home and the test convention were directly inspected.
1% uncertainty — no type contract beyond numeric fixture inputs is specified.
