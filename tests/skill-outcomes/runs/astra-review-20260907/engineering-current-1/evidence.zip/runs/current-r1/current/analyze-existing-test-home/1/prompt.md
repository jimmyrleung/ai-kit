Analyze rejecting negative amounts
