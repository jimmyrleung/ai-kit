# Available tool trace

## Setup commands
Both repos: git init; configure fixture identity. Unborn: git add tasks.md value.py, no commit. Single: git add tasks.md value.py; git commit -m baseline; stage return-2 change. Both: apply additional unstaged comment.

## unborn
$ git rev-parse --verify HEAD
exit=128
fatal: Needed a single revision

## unborn
$ git hash-object -t tree /dev/null
exit=0
4b825dc642cb6eb9a060e54bf8d69288fbee4904

## unborn
$ git status --short
exit=0
A  tasks.md
AM value.py

## unborn
$ git diff --cached --no-ext-diff 4b825dc642cb6eb9a060e54bf8d69288fbee4904
exit=0
diff --git c/tasks.md i/tasks.md
new file mode 100644
index 0000000..e7f22bf
--- /dev/null
+++ i/tasks.md
@@ -0,0 +1,5 @@
+# Tasks
+### Task 1
+Files: value.py
+#### Acceptance criteria
+- AC-1: value() returns 2.
diff --git c/value.py i/value.py
new file mode 100644
index 0000000..be082e7
--- /dev/null
+++ i/value.py
@@ -0,0 +1,2 @@
+def value():
+    return 2

## unborn
$ git diff --no-ext-diff
exit=0
diff --git i/value.py w/value.py
index be082e7..4aeb24d 100644
--- i/value.py
+++ w/value.py
@@ -1,2 +1,3 @@
 def value():
+    # additional unstaged edit
     return 2

## single
$ git rev-list --count HEAD
exit=0
1

## single
$ git status --short
exit=0
MM value.py

## single
$ git diff --cached HEAD -- value.py
exit=0
diff --git c/value.py i/value.py
index 041b5f7..be082e7 100644
--- c/value.py
+++ i/value.py
@@ -1,2 +1,2 @@
 def value():
-    return 1
+    return 2

## single
$ git diff -- value.py
exit=0
diff --git i/value.py w/value.py
index be082e7..4aeb24d 100644
--- i/value.py
+++ w/value.py
@@ -1,2 +1,3 @@
 def value():
+    # additional unstaged edit
     return 2

