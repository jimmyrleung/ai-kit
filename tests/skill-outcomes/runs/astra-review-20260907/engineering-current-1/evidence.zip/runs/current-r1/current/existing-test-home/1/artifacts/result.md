# Result

Implemented only the negative-amount guard in calc.py and extended the suitable existing tests/test_calc.py, as AGENTS.md requires. The existing unittest style and CI command were reused. Executed unittest discovery: 3/3 passed (negative, zero, positive). Executed compileall: exit 0. No helper, new test file, cleanup, or refactor was added.

Confidence score: 99% — source, repository instructions, docs, CI, tests, and executed results agree.
1% uncertainty — no type contract beyond numeric fixture inputs is specified.
