# Consumer-contract review

Finding: the plan is incomplete.

- client.py:1-2 currently returns an integer.
- api.py:1-3 consumes fetch() arithmetically with + 1.
- worker.py:1-3 is an unchanged consumer that consumes fetch() arithmetically with * 2.
- test_worker.py:1-3 owns the current worker contract and asserts run() == 8.
- Repository search found all three fetch call/definition sites in client.py, api.py, and worker.py.
- The executed contract-shape probe replaced worker.fetch with a Result-shaped object and worker.run raised TypeError: unsupported operand type(s) for *: Result and int.

Ownership correction: the task that changes fetch() owns client.py, both arithmetic consumers api.py and worker.py, and their existing tests, including test_worker.py. The worker test must be updated to prove the intended Result unwrapping/error behavior. A plan citation alone is not execution or coverage evidence.

The initial pytest command failed because pytest is unavailable; the existing test function was then executed directly and passed. Both attempts are preserved in trace.md.

Confidence score: 98% — caller closure and the break were verified from current source and an executed probe.
2% uncertainty — the desired Result error semantics and API test home are not supplied.
