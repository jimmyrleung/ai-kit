def value():
    # additional unstaged edit
    return 2
