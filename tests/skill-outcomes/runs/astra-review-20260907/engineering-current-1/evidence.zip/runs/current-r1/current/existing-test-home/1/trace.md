# Available tool trace

$ sed -n '1,200p' AGENTS.md calc.py tests/test_calc.py README.md .github/workflows/test.yml
exit=0
Extend suitable existing test files.
def fee(amount):
    if amount < 0:
        raise ValueError("amount must be nonnegative")
    return amount * 0.02
import unittest
from calc import fee
class FeeTests(unittest.TestCase):
    def test_negative(self):
        with self.assertRaises(ValueError):
            fee(-1)

    def test_zero(self):
        self.assertEqual(fee(0), 0)

    def test_positive(self):
        self.assertEqual(fee(100), 2)
Run python3 -m unittest discover -s tests. Reject negative amounts with ValueError.
name: test
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: python3 -m unittest discover -s tests

$ python3 -m unittest discover -s tests -v
exit=0
test_negative (test_calc.FeeTests.test_negative) ... ok
test_positive (test_calc.FeeTests.test_positive) ... ok
test_zero (test_calc.FeeTests.test_zero) ... ok

----------------------------------------------------------------------
Ran 3 tests in 0.000s

OK

$ python3 -m compileall -q calc.py tests
exit=0

$ sha256sum calc.py tests/*.py
exit=0
b1a20a26bad303f0e94126b078e80082148e4f1122ea0b1f14463a695fa77d33  calc.py
09543fe808401678db6bd6133f7035fe65c88aa48f3b5903a0f64b10dc694c05  tests/test_calc.py

