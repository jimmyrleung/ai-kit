# Available tool trace

$ sed -n '1,220p' AGENTS.md calc.py tests/test_label.py tests/test_calc.py README.md .github/workflows/test.yml
exit=0
No existing test module covers fee; introduce a focused module using unittest.
def fee(amount):
    if amount < 0:
        raise ValueError("amount must be nonnegative")
    return amount * 0.02
import unittest
class LabelTests(unittest.TestCase):
    def test_label(self):
        self.assertEqual("receipt".upper(), "RECEIPT")
import unittest

from calc import fee


class FeeTests(unittest.TestCase):
    def test_negative(self):
        with self.assertRaises(ValueError):
            fee(-1)

    def test_zero(self):
        self.assertEqual(fee(0), 0)

    def test_positive(self):
        self.assertEqual(fee(100), 2)
Run python3 -m unittest discover -s tests. Reject negative amounts with ValueError.
name: test
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: python3 -m unittest discover -s tests

$ python3 -m unittest discover -s tests -v
exit=0
test_negative (test_calc.FeeTests.test_negative) ... ok
test_positive (test_calc.FeeTests.test_positive) ... ok
test_zero (test_calc.FeeTests.test_zero) ... ok
test_label (test_label.LabelTests.test_label) ... ok

----------------------------------------------------------------------
Ran 4 tests in 0.000s

OK

$ python3 -m compileall -q calc.py tests
exit=0

$ sha256sum calc.py tests/*.py
exit=0
b1a20a26bad303f0e94126b078e80082148e4f1122ea0b1f14463a695fa77d33  calc.py
86c1093c5fb1265acb231c9455fb6f10f30fa266b0c6106e85e77d8e0e9ff637  tests/test_calc.py
5b8e6096cdbb716839c39b9694c3f0f02688b3bc9c0186bfa55476877cafe383  tests/test_label.py

