# Variant B — deterministic local defect

Confidence score: 98% — source.fee(-1) was executed and returned -0.02, contradicting the supplied nonnegative contract.
2% uncertainty — no production request/log links this local defect to a live incident.

VERIFIED path: source.py:1-2 receives -1, multiplies by 0.02 without validation, and returns -0.02. Category: Data Validation.

Falsifier: an execution of these exact bytes where fee(-1) raises the required error would disprove the diagnosis; the preserved execution observed -0.02.

Minimal local fix: add the negative-input guard at source.py:1-2 and cover negative, zero, and positive behavior. This supports a local fix only, not a production-causality claim. No deployment is authorized.
