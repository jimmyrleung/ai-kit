def fee(amount):
    if amount < 0:
        raise ValueError("negative amount")
    return amount * 0.02
