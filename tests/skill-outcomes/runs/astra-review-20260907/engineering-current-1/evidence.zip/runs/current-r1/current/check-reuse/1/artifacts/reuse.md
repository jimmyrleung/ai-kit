# Check reuse decisions

Baseline executed on Python 3.14.7 / Linux 7.1.9-arch1-2 x86_64. compileall exited 0 and the complete three-test unittest suite passed. Bound identities: calc.py b1a20a26…, tests a2c067e3…, config 233c5a23…, commands 6f803ff1….

| Variant | Decision |
| --- | --- |
| exact match | Reuse build/unit evidence: command, source, tests, config, environment, and complete suite scope match. |
| source changed | Stale for build/unit: calc.py is 31c17039…, so rerun affected checks. |
| config changed | Stale for config-dependent checks: config is 7057efcb…. |
| blocked integration | BLOCKED, not pass: no integration target/runner was supplied. |
| smaller successful subset | The executed 1/1 focused test may prove that case only; it cannot become a full-suite pass. |
| deliberate staging-only difference | Does not fail the test-target result: the required test key probe passed and staging.json labels the out-of-scope asymmetry. It also does not reuse evidence for a staging deployment. |
| required missing prod key | FAIL: executed readiness assertion exited 1 with required prod key missing. |
| browser screenshot | unavailable: no screenshot or browser output was supplied. No observable-button pass is claimed; a subjective wording preference would require human confirmation even with a screenshot. |

Confidence score: 98% — execution, hashes, and failure outputs are preserved.
2% uncertainty — integration and browser producers were unavailable.
