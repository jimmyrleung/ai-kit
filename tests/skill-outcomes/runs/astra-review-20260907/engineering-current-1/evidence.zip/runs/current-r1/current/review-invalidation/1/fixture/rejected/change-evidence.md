# Change evidence
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: rejected
source_path: source.py
source_sha256: 9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9
ac_source: spec.md:2-3
ac_section_sha256: 34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30
<!-- evidence:end -->
