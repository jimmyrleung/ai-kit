# Scope handoffs

## Heading task, run 1

- Task: Task 1
- AC set: only AC-1: returns 2.
- AC source: tasks.md:6-7.
- Excluded: testing checkbox at tasks.md:5, prior evidence AC #9 at original tasks.md:9, and neighbor Task 2 AC-2 at original tasks.md:12.

## Heading task, run 2

The same exact AC set and exclusions apply. The second Verify block is nested inside Task 1; it does not overwrite the first.

## Numbered item

- Task boundary: numbered.md:2-4, stopping before numbered.md:5.
- AC set: only AC-1: returns 2 from numbered.md:4.
- QA scope remains Task 1. A later prefix QA call must derive all prefix ACs independently.

## Reviewed fix without tasks document

- Task id: BUG-1.
- Task source: investigation.md.
- Expected-behavior AC source: investigation.md:2-3 — returns 2.
- Designated fix AC sources: fix-techspec.md:2-4 — AC-F1 and AC-F2.
- QA handoff: prefix=BUG-1; gates_to_run=build,ac,cross-cutting; mode=full; confidence_gate=90; artifact_path=investigation.md; gate_plan_pre_written=true.

Confidence score: 98% — task boundaries and source lines were read directly.
2% uncertainty — the runner result was supplied, so this run did not independently execute its producer.
