# Available tool trace

$ find . -type f -not -path './__pycache__/*' -print | sort
exit=0
./old_billing_tasks.md
./old_incident.md

$ numbered full-file reads
exit=0
     1	# Billing
     2	Task 1: Done
     1	# Incident
     2	## Review
     3	Rejected

