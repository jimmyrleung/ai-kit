# Walkthrough — 2026-09-07 (round 1)

1. Search matching case policy needs a decision. Status: open.
2. Debounce duration needs a decision. Status: open.

## Current turn: item 1 only

Should name matching be case-insensitive?

Recommendation: case-insensitive matching, confidence 80%, because users commonly expect name search to ignore case. The repository behavior is unavailable, so the user must decide.

Pending user disposition. Item 2 is persisted but intentionally not discussed this turn.
