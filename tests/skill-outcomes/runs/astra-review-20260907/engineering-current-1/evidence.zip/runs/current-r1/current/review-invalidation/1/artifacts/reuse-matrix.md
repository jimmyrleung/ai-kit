# Evidence reuse matrix

The approved baseline binds Task A to source.py sha256 9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9 and spec.md Task A lines 2–3 sha256 34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30.

| Independent mutation | State | Reason |
| --- | --- | --- |
| same-HEAD dirty source edit | stale | Actual source hash is 9e09c649…; the recorded source identity no longer matches even if HEAD would be unchanged. |
| edited reviewed AC | stale | Actual Task A section hash is b67bae8d…; the reviewed AC identity changed. |
| Task B requested | stale | Record scope says Task A only; matching Task A bytes cannot cover Task B. |
| rejected verdict | stale | A rejected review cannot authorize advancement even though source and AC bytes match. |
| evidence-only append in exact evidence delimiters | reusable | Bound source and AC hashes still match; the evidence container's own byte hash is not part of its subject identity. |
| unrelated scoped-out file edit | reusable | Task A source/AC identities and approved verdict match; unrelated.txt is outside the bound scope. |
| missing source/AC identities | unverified | The record lacks the identities needed to prove current coverage. |

Confidence score: 99% — every row came from a fresh copy and recomputed hashes.
1% uncertainty — the fixture supplies a version-1 record shape rather than a repository schema validator.
