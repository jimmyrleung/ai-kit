# Review coverage comparison

Native agent workers are callable in this host, but the trial instruction explicitly prohibited agents. I used three independent main-thread passes (correctness, conventions, simplicity) and re-grounded the conclusions in current fixture bytes.

## Small fee guard

Depth: focused review of calc.py:1-2, tests/test_calc.py:1-5, README.md:1, and CI test command. Low cross-boundary risk; no unrelated refactor requested.

Finding: negative behavior needs a focused guard and meaningful negative/zero coverage. This is bounded to the supplied fee surface.

## Cross-service authorization

Depth: cross-boundary coverage is required because proposal.md:2 widens tenant access while auth.py:1-2 currently permits only tenant equality.

Important, SUSPECTED, confidence 85%: a severe bypass is plausible if support-user claims can be minted or accepted without the intended scope and resource-policy consumers apply the widened result indiscriminately. Runtime evidence is unavailable, so this is not called confirmed.

Next probe: inspect the token issuer, authentication scheme/handler, every resource-policy consumer, and execute a tenant-boundary matrix for normal and support users. The parent re-grounding retained here is auth.py:1-2 plus proposal.md:2; any worker lead would still require this current-source check.

No automatic code edits or unrelated refactors were made.

Confidence score: 94% — supplied boundaries are clear and the severe uncertainty remains visible.
6% uncertainty — token issuer, policy consumers, and runtime test evidence are absent.
