# Task A review

Base: fixture-base be70252. Current HEAD: e5e7050. Current status fingerprint: 144f135b80bf9784f75dcb1396d3dd79c2ed28147edc237a5eeed4616f9f5259.

| Layer transition | Intended content inspected | Evidence |
| --- | --- | --- |
| fixture-base → HEAD | calc.py adds the negative guard | trace.md, git diff be70252..HEAD |
| HEAD → index | calc.py changes the ValueError text; old.md is renamed to new.md at 100% similarity | trace.md, git diff --cached |
| index → worktree | calc.py adds the None guard | trace.md, git diff |
| untracked | fresh.txt contains Task A release note | trace.md, ls-files and sha256 |

Rename ownership is recorded as old.md → new.md. Each layer transition appears once, so the staged delta is not double-counted as a worktree delta.

Excluded:

- unrelated.txt belongs to Task B and is unchanged from fixture-base.
- tasks.md is the scope input, unchanged from fixture-base.
- All content at or before fixture-base is baseline, including the earlier unrelated content.

Current working bytes:

- calc.py sha256 7b8b9eb6ab0e01dd3a93c35771ee645d619a2ef428b151e84b8379d52f022854
- new.md sha256 7c85c33a763a8710f5a4f6deb04bf507904733cae9b88f59180fbe87e3a9fa7c
- fresh.txt sha256 c91a1736a6675cbbefe6e6dbd1b5f6b684bff0bd0df04068df5c5c3976dcd5cc
- scoped manifest digest 3dfcb902d495d96148c78a97c327af7383f6ec25993cefb1c2201cf3b9cdda3e

The review evidence covers this exact current content. A stamp of e5e7050+dirty alone would be insufficient because the same HEAD can name different dirty bytes.

Confidence score: 99% — all four layers and current bytes were directly inspected.
1% uncertainty — no behavioral tests were requested or run for this review-scope case.
