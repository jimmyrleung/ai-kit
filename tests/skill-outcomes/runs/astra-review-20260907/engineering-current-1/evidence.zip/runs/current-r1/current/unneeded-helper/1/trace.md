# Available tool trace

$ find . -type f -not -path './__pycache__/*' -print | sort
exit=0
./.github/workflows/test.yml
./README.md
./calc.py
./proposal.md
./tests/test_calc.py

$ numbered full-file reads
exit=0
     1	name: test
     2	on: [push]
     3	jobs:
     4	  test:
     5	    runs-on: ubuntu-latest
     6	    steps:
     7	      - run: python3 -m unittest discover -s tests
     1	Run python3 -m unittest discover -s tests. Reject negative amounts with ValueError.
     1	def fee(amount):
     2	    return amount * 0.02
     1	# Proposed change
     2	Guard fee against amount < 0. Also add ValidationFactory, a plugin registry, duplicate tests/test_calc.py into tests/duplicate_test_calc.py, and reformat all modules.
     1	import unittest
     2	from calc import fee
     3	class FeeTests(unittest.TestCase):
     4	    def test_positive(self):
     5	        self.assertEqual(fee(100), 2)

