# Change evidence
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: approved
source_path: source.py
ac_source: spec.md:2-3
<!-- evidence:end -->
