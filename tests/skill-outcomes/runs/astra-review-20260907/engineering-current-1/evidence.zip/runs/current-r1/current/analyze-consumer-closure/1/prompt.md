Analyze fetch return-contract change; no implementation recipe
