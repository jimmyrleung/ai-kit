# Variant C — active P1 with supplied causal fixture

Confidence score: 75% — the clearly labeled synthetic transcript identifies request, input key, config, build, branch, both absence observations, and duplicate application; live-system truth remains unverified.
25% uncertainty — evidence is synthetic fixture input and does not prove production prevalence, duration, or current state.

Within the fixture, synthetic-causal-runtime.log:2-6 VERIFIED the non-atomic race path in race.py:1-3 and refuted the timeout-only hypothesis at line 7. The artifact review carries the explicitly authorized policy unchanged: mode streamlined, confidence threshold 70. The bounded 75% fixture diagnosis clears that trial threshold; it does not silently switch to normal 90.

Reversible mitigation: serialize per-key application behind a flag, monitor duplicate count plus latency/timeouts, and disable the flag on regression. Confirmed remediation requires a reviewed atomic-claim design and a post-change causal replay; it is not claimed here.

No deployment is authorized by either confidence or review approval.
