def fee(amount):
    if amount is None:
        raise TypeError("amount is required")
    if amount < 0:
        raise ValueError("negative amount")
    return amount * 0.02
