# Independent routes

| Variant | Route/outcome |
| --- | --- |
| A | Recommend analyze-work for the new search box; do not execute. The old completed billing doc is unrelated. |
| B | Continue the explicitly authorized reviewed implementation with implement-task once its current review stamp and dependencies are verified. |
| C | Recommend analyze-work for the new search request; the unrelated rejected incident artifact does not control it. |
| D | Do not advance. Re-run the review owning the stale content hash before continuing implementation. |
| E | Execute walkthrough-implementation because the tour was explicitly requested; follow its dependency-ordered, one-step-per-turn cadence. |
| F | Report repository scope complete and deployment pending. No deployment action is authorized. |

No unrequested tour is started in A–D/F; at most it may be offered after owned implementation is ready.

Confidence score: 97% — current intent and approval freshness determine each route.
3% uncertainty — variant B/D do not supply the actual reviewed artifact bytes needed for the prerequisite probe.
