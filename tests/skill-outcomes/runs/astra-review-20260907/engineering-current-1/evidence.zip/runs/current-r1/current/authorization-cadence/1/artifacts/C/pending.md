# Pending clarification

What exact retention rule must the analysis preserve: retention duration, deletion trigger, and the records it applies to? This is load-bearing because it changes scope, state transitions, and tests. No default is inferred.

Confidence score: 99% — the missing decision is explicit.
1% uncertainty — the fixture does not identify the owning policy document.
