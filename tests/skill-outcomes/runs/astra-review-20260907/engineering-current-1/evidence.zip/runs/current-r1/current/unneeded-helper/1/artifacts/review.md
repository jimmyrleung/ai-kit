# Proposed-fix review

The focused amount < 0 guard is required by README.md:1 and belongs in calc.py:1-2. Meaningful negative, zero, and positive cases can extend the existing unittest home at tests/test_calc.py:1-5 in this fixture.

ValidationFactory and a plugin registry are not required by the one-function requirement or any supplied repository pattern. Duplicating tests/test_calc.py adds redundant ownership without new coverage. Reformatting every module is unrelated to the requested behavior and should be excluded.

This judgment is fixture-specific. A new test file is justified when repository instructions require it or when no suitable test home exists, as in the comparison fixtures; new-file status alone is not a defect.

Confidence score: 98% — every proposed addition was checked against the supplied code, tests, README, and CI.
2% uncertainty — no actual proposed diff was supplied, so line-level review is limited to proposal.md:2.
