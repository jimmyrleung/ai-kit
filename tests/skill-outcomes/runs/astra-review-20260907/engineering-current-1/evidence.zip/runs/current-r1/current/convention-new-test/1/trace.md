# Available tool trace

$ sed -n '1,220p' AGENTS.md calc.py tests/test_calc.py tests/test_calc_validation.py README.md .github/workflows/test.yml
exit=0
Repository convention: validation failure scenarios belong in tests/test_calc_validation.py, separate from normal calculation tests.
def fee(amount):
    if amount < 0:
        raise ValueError("amount must be nonnegative")
    return amount * 0.02
import unittest
from calc import fee
class FeeTests(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(fee(100), 2)
import unittest

from calc import fee


class FeeValidationTests(unittest.TestCase):
    def test_negative(self):
        with self.assertRaises(ValueError):
            fee(-1)

    def test_zero(self):
        self.assertEqual(fee(0), 0)

    def test_positive(self):
        self.assertEqual(fee(100), 2)
Run python3 -m unittest discover -s tests. Reject negative amounts with ValueError.
name: test
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: python3 -m unittest discover -s tests

$ python3 -m unittest discover -s tests -v
exit=0
test_positive (test_calc.FeeTests.test_positive) ... ok
test_negative (test_calc_validation.FeeValidationTests.test_negative) ... ok
test_positive (test_calc_validation.FeeValidationTests.test_positive) ... ok
test_zero (test_calc_validation.FeeValidationTests.test_zero) ... ok

----------------------------------------------------------------------
Ran 4 tests in 0.000s

OK

$ python3 -m compileall -q calc.py tests
exit=0

$ sha256sum calc.py tests/*.py
exit=0
b1a20a26bad303f0e94126b078e80082148e4f1122ea0b1f14463a695fa77d33  calc.py
40ce2c2932df03f4521e3ff02788541414709c2791131708e43f64bed66ac569  tests/test_calc.py
11821f3c581a4c4e3decdb791c1ccac5ba97612c68f3d17e727cf267a81c1f6f  tests/test_calc_validation.py

