# Available tool trace

## Setup
Computed baseline hashes, wrote the version-1 approved record, then created seven fresh independent copies before mutation.

## same-head-source
$ sha256sum source.py spec.md change-evidence.md
sed -n '/^## Task A requirements/,/^## Task B requirements/p' spec.md | sed '$d' | sha256sum
sed -n '/<!-- evidence:start -->/,/<!-- evidence:end -->/p' change-evidence.md
exit=0
9e09c649598e0a36e474329991b4d301564b82c9719ede042f5aeae19387cf3f  source.py
6941d29e0228bb8c64ad52899284b936300ebf4f5ba351e7aa699d4b12fc6844  spec.md
a16f55e81bb205a88b196c8c8f4b1d78f28f624b3908ca35e10aaeee3496d303  change-evidence.md
34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30  -
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: approved
source_path: source.py
source_sha256: 9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9
ac_source: spec.md:2-3
ac_section_sha256: 34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30
<!-- evidence:end -->

## edited-ac
$ sha256sum source.py spec.md change-evidence.md
sed -n '/^## Task A requirements/,/^## Task B requirements/p' spec.md | sed '$d' | sha256sum
sed -n '/<!-- evidence:start -->/,/<!-- evidence:end -->/p' change-evidence.md
exit=0
9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9  source.py
1e1f4cf1694b41dec68c8ec5bb8234d62322b6d9c1935ad0ed1f9b4dddddf471  spec.md
a16f55e81bb205a88b196c8c8f4b1d78f28f624b3908ca35e10aaeee3496d303  change-evidence.md
b67bae8d18af8066d6e15cd14ea482601f633b2117608959b1b52c3d2f36838b  -
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: approved
source_path: source.py
source_sha256: 9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9
ac_source: spec.md:2-3
ac_section_sha256: 34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30
<!-- evidence:end -->

## task-b
$ sha256sum source.py spec.md change-evidence.md
sed -n '/^## Task A requirements/,/^## Task B requirements/p' spec.md | sed '$d' | sha256sum
sed -n '/<!-- evidence:start -->/,/<!-- evidence:end -->/p' change-evidence.md
exit=0
9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9  source.py
6941d29e0228bb8c64ad52899284b936300ebf4f5ba351e7aa699d4b12fc6844  spec.md
a16f55e81bb205a88b196c8c8f4b1d78f28f624b3908ca35e10aaeee3496d303  change-evidence.md
34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30  -
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: approved
source_path: source.py
source_sha256: 9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9
ac_source: spec.md:2-3
ac_section_sha256: 34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30
<!-- evidence:end -->

## rejected
$ sha256sum source.py spec.md change-evidence.md
sed -n '/^## Task A requirements/,/^## Task B requirements/p' spec.md | sed '$d' | sha256sum
sed -n '/<!-- evidence:start -->/,/<!-- evidence:end -->/p' change-evidence.md
exit=0
9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9  source.py
6941d29e0228bb8c64ad52899284b936300ebf4f5ba351e7aa699d4b12fc6844  spec.md
3ae94d9693984d44fd2be7de1ec84288109ba767335c3f79eee9c24bb98dcddf  change-evidence.md
34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30  -
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: rejected
source_path: source.py
source_sha256: 9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9
ac_source: spec.md:2-3
ac_section_sha256: 34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30
<!-- evidence:end -->

## evidence-append
$ sha256sum source.py spec.md change-evidence.md
sed -n '/^## Task A requirements/,/^## Task B requirements/p' spec.md | sed '$d' | sha256sum
sed -n '/<!-- evidence:start -->/,/<!-- evidence:end -->/p' change-evidence.md
exit=0
9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9  source.py
6941d29e0228bb8c64ad52899284b936300ebf4f5ba351e7aa699d4b12fc6844  spec.md
d6806b17ab8f0527523cbd58ba2f5e244f79c600837ac716c4d1771586bcddf9  change-evidence.md
34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30  -
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: approved
source_path: source.py
source_sha256: 9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9
ac_source: spec.md:2-3
ac_section_sha256: 34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30
<!-- evidence:end -->
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: approved
note: evidence-only append; source and AC identities unchanged
<!-- evidence:end -->

## unrelated-edit
$ sha256sum source.py spec.md change-evidence.md
sed -n '/^## Task A requirements/,/^## Task B requirements/p' spec.md | sed '$d' | sha256sum
sed -n '/<!-- evidence:start -->/,/<!-- evidence:end -->/p' change-evidence.md
exit=0
9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9  source.py
6941d29e0228bb8c64ad52899284b936300ebf4f5ba351e7aa699d4b12fc6844  spec.md
a16f55e81bb205a88b196c8c8f4b1d78f28f624b3908ca35e10aaeee3496d303  change-evidence.md
34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30  -
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: approved
source_path: source.py
source_sha256: 9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9
ac_source: spec.md:2-3
ac_section_sha256: 34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30
<!-- evidence:end -->

## missing-identities
$ sha256sum source.py spec.md change-evidence.md
sed -n '/^## Task A requirements/,/^## Task B requirements/p' spec.md | sed '$d' | sha256sum
sed -n '/<!-- evidence:start -->/,/<!-- evidence:end -->/p' change-evidence.md
exit=0
9c86f318c9a665a30c527efcde84b0442fce7f29b8d8708cf01c43fda411c8f9  source.py
6941d29e0228bb8c64ad52899284b936300ebf4f5ba351e7aa699d4b12fc6844  spec.md
75c03c4cc31bfdfaea8c78747a8437e2a1c99f7baa063dc29dcde4c5eb6ff549  change-evidence.md
34a3ca7f47f2aaa769ae1ec1bfc5509f0b69410e2b0b68bf74427e36a1bf2a30  -
<!-- evidence:start -->
record_version: 1
task: Task A
verdict: approved
source_path: source.py
ac_source: spec.md:2-3
<!-- evidence:end -->

