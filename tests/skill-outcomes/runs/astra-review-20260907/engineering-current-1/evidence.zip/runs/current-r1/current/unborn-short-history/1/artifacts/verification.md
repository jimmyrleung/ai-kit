# Task 1 scope verification

## Unborn repository

- HEAD is absent: git rev-parse --verify HEAD exited 128.
- Explicit base: empty tree 4b825dc642cb6eb9a060e54bf8d69288fbee4904.
- Index scope: tasks.md and the supplied two-line value.py are added.
- Worktree-only scope: the comment in value.py is the additional unstaged edit.
- Status A tasks.md and AM value.py accounts for both layers.

## Single-commit repository

- History count is exactly one.
- Scope was resolved with git diff --cached HEAD and git diff, with no fixed HEAD ancestor expression.
- Index scope changes value.py from return 1 to return 2.
- Worktree-only scope adds the comment.
- Status MM value.py accounts for both layers.

Confidence score: 99% — absent HEAD, empty-tree identity, one-commit count, and both diffs were observed.
1% uncertainty — the comment is intentionally behavior-neutral and was not separately tested.
