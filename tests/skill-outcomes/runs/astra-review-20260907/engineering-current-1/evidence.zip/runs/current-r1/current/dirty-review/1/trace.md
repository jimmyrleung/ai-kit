# Available tool trace

## Setup commands
$ git init
$ git config user.name 'Fixture Runner'
$ git config user.email 'fixture@example.invalid'
$ git add calc.py old.md unrelated.txt tasks.md
$ git commit -m fixture-base
created fixture-base be70252
$ git add calc.py
$ git commit -m 'implement Task A guard'
created e5e7050
$ mv old.md new.md
$ git add calc.py old.md new.md
$ git add calc.py

$ git log --oneline --decorate --all
exit=0
e5e7050 (HEAD -> master) implement Task A guard
be70252 fixture-base

$ git status --short
exit=0
MM calc.py
R  old.md -> new.md
?? fresh.txt

$ git diff be70252..HEAD -- calc.py old.md new.md fresh.txt
exit=0
diff --git a/calc.py b/calc.py
index 9f1ccea..d7d8c51 100644
--- a/calc.py
+++ b/calc.py
@@ -1,2 +1,4 @@
 def fee(amount):
+    if amount < 0:
+        raise ValueError("amount must be nonnegative")
     return amount * 0.02

$ git diff --cached -- calc.py old.md new.md fresh.txt
exit=0
diff --git c/calc.py i/calc.py
index d7d8c51..3e5799f 100644
--- c/calc.py
+++ i/calc.py
@@ -1,4 +1,4 @@
 def fee(amount):
     if amount < 0:
-        raise ValueError("amount must be nonnegative")
+        raise ValueError("negative amount")
     return amount * 0.02
diff --git c/old.md i/new.md
similarity index 100%
rename from old.md
rename to new.md

$ git diff -- calc.py old.md new.md fresh.txt
exit=0
diff --git i/calc.py w/calc.py
index 3e5799f..ad6cc3d 100644
--- i/calc.py
+++ w/calc.py
@@ -1,4 +1,6 @@
 def fee(amount):
+    if amount is None:
+        raise TypeError("amount is required")
     if amount < 0:
         raise ValueError("negative amount")
     return amount * 0.02

$ git ls-files --others --exclude-standard
exit=0
fresh.txt

$ sha256sum calc.py new.md fresh.txt tasks.md unrelated.txt
exit=0
7b8b9eb6ab0e01dd3a93c35771ee645d619a2ef428b151e84b8379d52f022854  calc.py
7c85c33a763a8710f5a4f6deb04bf507904733cae9b88f59180fbe87e3a9fa7c  new.md
c91a1736a6675cbbefe6e6dbd1b5f6b684bff0bd0df04068df5c5c3976dcd5cc  fresh.txt
00c5ee5256e4817f2d6807844fb4535bb42d90901e6e4f2809d21867f710dc52  tasks.md
4ee3b919a5a0b026dcad664850a526059a32b9183f27969b4428b9e3f2094af3  unrelated.txt

$ git show HEAD:calc.py | sha256sum
exit=0
b1a20a26bad303f0e94126b078e80082148e4f1122ea0b1f14463a695fa77d33  -

$ git show :calc.py | sha256sum
exit=0
31c17039c0b3705d1816ae7f918560685f9b5e3fa4616a3fb7e0af5f90a96214  -

$ sha256sum calc.py new.md fresh.txt | sha256sum
exit=0
3dfcb902d495d96148c78a97c327af7383f6ec25993cefb1c2201cf3b9cdda3e  -

$ git status --porcelain=v1 -z | sha256sum
exit=0
144f135b80bf9784f75dcb1396d3dd79c2ed28147edc237a5eeed4616f9f5259  -

