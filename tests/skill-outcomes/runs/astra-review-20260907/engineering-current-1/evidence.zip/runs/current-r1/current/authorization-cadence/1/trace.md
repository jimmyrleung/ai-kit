# Available tool trace

$ find . -type f -not -path './__pycache__/*' -print | sort
exit=0
./findings.md
./request.md

$ numbered full-file reads
exit=0
     1	# Findings
     2	1. Search matching case policy needs a decision.
     3	2. Debounce duration needs a decision.
     1	Add a search box to filter the existing list by name. Keep existing data source.

