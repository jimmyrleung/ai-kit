# Result

Implemented only the negative-amount guard in calc.py. Created tests/test_calc_validation.py because AGENTS.md assigns validation-failure scenarios there, separate from tests/test_calc.py. The new file follows the repository's unittest style. Executed unittest discovery: 4/4 passed, including negative, zero, and positive validation coverage. Executed compileall: exit 0. No helper, cleanup, or refactor was added.

Confidence score: 99% — the new test home is explicitly required and all behavior was executed.
1% uncertainty — no type contract beyond numeric fixture inputs is specified.
