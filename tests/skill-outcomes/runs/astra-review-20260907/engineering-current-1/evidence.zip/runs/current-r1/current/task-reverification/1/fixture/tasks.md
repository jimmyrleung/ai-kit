# Tasks
### Task 1
Files: value.py
#### Testing requirements
- [ ] Existing test green
#### Acceptance criteria
- [ ] AC-1: returns 2
#### Verify — old run
- [x] AC #9 old generated evidence
#### Verify — 2026-09-07 (run 1)
- [x] Gate 1 — build/test: supplied successful runner result (not executed in this run)
- [x] Gate 2 — AC checklist (1 item)
  - [x] AC-1: returns 2 — source: tasks.md:7
- [x] Gate 3 — cross-cutting: no budget or SDK pin supplied
- QA handoff: prefix=task-reverification; gates_to_run=build,ac,cross-cutting; mode=full; confidence_gate=90; artifact_path=tasks.md#Task-1; gate_plan_pre_written=true
#### Verify — 2026-09-07 (run 2)
- [x] Gate 1 — build/test: supplied successful runner result (not executed in this run)
- [x] Gate 2 — AC checklist (1 item)
  - [x] AC-1: returns 2 — source: tasks.md:7
- [x] Gate 3 — cross-cutting: no budget or SDK pin supplied
- QA handoff: prefix=task-reverification; gates_to_run=build,ac,cross-cutting; mode=full; confidence_gate=90; artifact_path=tasks.md#Task-1; gate_plan_pre_written=true
### Task 2
#### Acceptance criteria
- [ ] AC-2: returns 3
