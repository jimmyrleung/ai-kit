# Available tool trace

$ find . -type f -not -path './__pycache__/*' -print | sort
exit=0
./requirements.md

$ numbered full-file reads
exit=0
     1	# Required outcomes
     2	Code + tests pass in repository. Scratch migration validation runs before repository GO. Deploy only after repository GO. Live rehearsal depends on deployed state.

