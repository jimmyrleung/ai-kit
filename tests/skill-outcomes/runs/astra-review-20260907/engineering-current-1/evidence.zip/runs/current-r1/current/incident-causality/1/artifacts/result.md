# Incident result

A remains candidate-only with an exact next probe. B proves a local validation defect without false production linkage. C carries streamlined/70 through review and keeps synthetic fixture evidence separate from live truth. All variants separate reversible mitigation from confirmed remediation and infer no deployment authority.

Confidence score: 98% — distinctions are explicit and backed by preserved probe output.
2% uncertainty — live systems were intentionally outside the fixture.
