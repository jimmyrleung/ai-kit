# Executable task graph

| ID | Boundary | Work/resource | Depends on | Status | Evidence when complete |
| --- | --- | --- | --- | --- | --- |
| I1 | pre-merge | read-only inspection A | — | Ready | inspection notes |
| I2 | pre-merge | read-only inspection B | — | Ready | inspection notes |
| C1 | pre-merge | implementation A edits shared.py | — | Ready | focused tests/build |
| C2 | pre-merge | implementation B edits shared.py | C1 | Pending | focused tests/build |
| M1 | pre-merge | migration validation A on scratch DB | C1 | Pending | executed migration log |
| M2 | pre-merge | migration validation B on same scratch DB | M1 | Pending | executed migration log |
| I3 | pre-merge | read-only inspection of completed code | C2 | Pending | inspection notes |
| T1 | pre-merge | repository build and tests | C2, M1, M2 | Pending | complete runner result |
| GO | pre-merge | repository QA/go decision | T1 | Pending | recorded repository verdict |
| D1 | deploy | deploy | GO | Pending | deployment receipt |
| L1 | live | live rehearsal | D1 | Pending | rehearsal record |

C1 and C2 are serialized because both edit shared.py. M1 and M2 are logically independent but serialized because they share one scratch database; true parallelism would require isolated databases plus explicit reconciliation, which this smallest graph does not add.

Potentially parallel:

- I1, I2, and C1 may overlap.
- After C1, M1 may overlap with C2 because they use different resources.
- I3 may overlap with M1/M2 once C2 is complete.

Ready now: I1, I2, C1. I3 is potentially parallel later but is not ready now because C2 is unfinished.

Repository-only completion follows C1 → C2; C1 → M1 → M2; then T1 → GO. GO does not wait for D1 or L1, so there is no QA/deployment cycle. D1 and L1 remain named pending operations with their own evidence.

Confidence score: 97% — dependencies and shared resources are explicit and acyclic.
3% uncertainty — the fixture gives no concrete migration runner or deployment platform.
