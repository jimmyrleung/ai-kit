# Fetch return-contract change — analysis

Mode: integration. Resolved work name: fetch_return_contract.

## Overview

Changing fetch() affects unchanged arithmetic consumers as well as the named client/API files. This map identifies consumer closure and test ownership without choosing a new return shape or giving an implementation recipe.

## Confidence score

Confidence score: 93% — every file and fetch consumer in the fixture was read and enumerated.
7% uncertainty — the new shape, error semantics, API test home, runner, compatibility window, and rollback trigger are unspecified; these constrain design and verification.

## Entry points and execution flow

- client.py:1-2 defines fetch() and returns an integer.
- api.py:1-3 imports fetch and adds 1 to its result.
- worker.py:1-3 imports fetch and multiplies its result by 2.
- test_worker.py:1-3 imports run and pins the worker result to 8.
- Repository search found three fetch( sites: definition plus the API and worker consumers; import search confirmed both consumers.

## Consumer closure

| Consumer | Current contract use | Ownership impact |
| --- | --- | --- |
| api.py:1-3 | arithmetic + 1 | Must be covered by the contract-change work |
| worker.py:1-3 | arithmetic * 2 | Must be covered even though its source line was unchanged in the proposal |
| test_worker.py:1-3 | asserts worker returns 8 | Existing consumer test belongs with the worker contract update |

plan.md:1-2 cites only client.py/API testing. Citations do not prove worker compatibility or test execution.

## Patterns, test home, and context

test_worker.py is the existing worker test home and should be assessed before creating another. No AGENTS.md, README, CI configuration, API test, or runner configuration is supplied, so broader repository conventions and executable suite scope are unknown.

## Change surface

| File | Purpose | Changes Needed |
| --- | --- | --- |
| client.py | Provider contract | Return contract changes here |
| api.py | Direct arithmetic consumer | Adapt/verify against the chosen contract |
| worker.py | Unchanged direct arithmetic consumer | Adapt/verify against the chosen contract |
| test_worker.py | Existing consumer contract test | Preserve intended output/error behavior |

## Risks and constraints

- High: either arithmetic consumer breaks if it receives a non-numeric object without adaptation.
- Mid: error propagation may diverge between API and worker; exact behavior is an open design decision.
- Test constraint: execute both consumer paths; the fixture only supplies an existing worker test and no runnable pytest dependency.
- Rollback constraint: provider and both consumers form one compatibility unit unless the design adds an explicit transition contract. The rollback trigger and compatibility window remain open.

## Needed references

Loaded analyze-work body, exact prompt, client.py, api.py, worker.py, test_worker.py, and plan.md. No additional supplied baseline reference is named. Repository convention/runner documents are unavailable in this fixture and were not substituted from the live ai-kit tree.

## Confidence & unverified

Unverified: chosen return representation, error meanings, API tests, external callers beyond the complete fixture, and deployment compatibility. The analysis deliberately leaves those for design.
