# Available tool trace

## baseline
$ python3 --version
exit=0
Python 3.14.7

## baseline
$ uname -srm
exit=0
Linux 7.1.9-arch1-2 x86_64

## baseline
$ python3 -m compileall calc.py
exit=0

## baseline
$ python3 -m unittest discover -s tests -v
exit=0
test_negative (test_calc.FeeTests.test_negative) ... ok
test_positive (test_calc.FeeTests.test_positive) ... ok
test_zero (test_calc.FeeTests.test_zero) ... ok

----------------------------------------------------------------------
Ran 3 tests in 0.000s

OK

## baseline
$ sha256sum calc.py tests/test_calc.py config.json commands.json
exit=0
b1a20a26bad303f0e94126b078e80082148e4f1122ea0b1f14463a695fa77d33  calc.py
a2c067e34698d73733e892e080eb82b0001c1d78de0513f8b9b7468804cf2d36  tests/test_calc.py
233c5a234b1bca8beb977a28773e2ad2d467f0e6daecde0eb18ca2f036c2875c  config.json
6f803ff1b30822e0a3969c60cff52384d626a3039f74032106b2fb2dd2d316fa  commands.json

## matching
$ sha256sum calc.py tests/test_calc.py config.json commands.json
exit=0
b1a20a26bad303f0e94126b078e80082148e4f1122ea0b1f14463a695fa77d33  calc.py
a2c067e34698d73733e892e080eb82b0001c1d78de0513f8b9b7468804cf2d36  tests/test_calc.py
233c5a234b1bca8beb977a28773e2ad2d467f0e6daecde0eb18ca2f036c2875c  config.json
6f803ff1b30822e0a3969c60cff52384d626a3039f74032106b2fb2dd2d316fa  commands.json

## source-changed
$ sha256sum calc.py tests/test_calc.py config.json commands.json
exit=0
31c17039c0b3705d1816ae7f918560685f9b5e3fa4616a3fb7e0af5f90a96214  calc.py
a2c067e34698d73733e892e080eb82b0001c1d78de0513f8b9b7468804cf2d36  tests/test_calc.py
233c5a234b1bca8beb977a28773e2ad2d467f0e6daecde0eb18ca2f036c2875c  config.json
6f803ff1b30822e0a3969c60cff52384d626a3039f74032106b2fb2dd2d316fa  commands.json

## config-changed
$ sha256sum calc.py tests/test_calc.py config.json commands.json
exit=0
b1a20a26bad303f0e94126b078e80082148e4f1122ea0b1f14463a695fa77d33  calc.py
a2c067e34698d73733e892e080eb82b0001c1d78de0513f8b9b7468804cf2d36  tests/test_calc.py
7057efcbfd63ba4d3aba203488844ed033cd2fde8ad096275b0783345e983bf6  config.json
6f803ff1b30822e0a3969c60cff52384d626a3039f74032106b2fb2dd2d316fa  commands.json

## subset
$ python3 -m unittest -v tests.test_calc.FeeTests.test_negative
exit=0
test_negative (tests.test_calc.FeeTests.test_negative) ... ok

----------------------------------------------------------------------
Ran 1 test in 0.000s

OK

## staging-diff
$ python3 -c 'import json; c=json.load(open("config.json")); assert c["required_key"]; print("required test key present; staging delta is labeled and out of target scope")'
exit=0
required test key present; staging delta is labeled and out of target scope

## missing-prod
$ python3 -c 'import json; c=json.load(open("prod.json")); assert c["required_key"], "required prod key missing"'
exit=1
Traceback (most recent call last):
  File "<string>", line 1, in <module>
    import json; c=json.load(open("prod.json")); assert c["required_key"], "required prod key missing"
                                                        ~^^^^^^^^^^^^^^^^
AssertionError: required prod key missing

## blocked-integration
No command executed: no integration target or runner was supplied.

## browser
No screenshot or browser output was supplied; trace unavailable.

