# Available tool trace

## A
$ sed -n '1,120p' race.py incident.log
exit=0
def apply(key, store):
    if key not in store:
        store[key] = "applied"
2026-09-06T10:00:00Z request timeout
No key-level trace or branch execution is captured in this fixture.

## A
$ rg -n 'key|branch|apply|duplicate' incident.log
exit=0
2:No key-level trace or branch execution is captured in this fixture.

## B
$ python3 -c 'from source import fee; print(repr(fee(-1)))'
exit=0
-0.02

## C
$ sed -n '1,160p' synthetic-causal-runtime.log
exit=0
SYNTHETIC FIXTURE EVIDENCE — not a live-system claim
2026-09-06T10:00:01Z request_id=req-42 input_key=idem-7 config=prod-like build=abc123 branch=race.py:2
2026-09-06T10:00:01.010Z request_id=req-42 worker=1 observed key_absent=true
2026-09-06T10:00:01.011Z request_id=req-42 worker=2 observed key_absent=true
2026-09-06T10:00:01.020Z request_id=req-42 worker=1 applied_count=1
2026-09-06T10:00:01.021Z request_id=req-42 worker=2 applied_count=2
Competing timeout-only hypothesis refuted for this synthetic transcript: duplicate application occurred before timeout.

## C
$ sha256sum synthetic-causal-runtime.log race.py
exit=0
629a69220f548aef90bb51a766d86b850a16ad76cf8700b52782d961d9bab9e7  synthetic-causal-runtime.log
cffe8c8254a5a714a6dc90e521a560eae40f1cc88d1cd610f63651482479f5a9  race.py

