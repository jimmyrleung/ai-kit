# Available tool trace

$ rg -n 'fetch\\(' .
exit=2
rg: regex parse error:
    (?:fetch\\()
    ^
error: unclosed group

$ python3 -m pytest -q test_worker.py
exit=1
/usr/bin/python3: No module named pytest

$ python3 -c 'import test_worker; test_worker.test_run(); print("test_worker.test_run: PASS")'
exit=0
test_worker.test_run: PASS

$ python3 - <<'PY'
import worker
from dataclasses import dataclass
@dataclass
class Result:
    value: int
    error: object = None
worker.fetch=lambda: Result(4, None)
try:
    worker.run()
except Exception as e:
    print(type(e).__name__ + ': ' + str(e))
PY
exit=0
TypeError: unsupported operand type(s) for *: 'Result' and 'int'

