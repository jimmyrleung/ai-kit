# Rejecting negative amounts — analysis

Mode: integration. Resolved work name: rejecting_negative_amounts.

## Overview

The change lands in the existing fee calculation and its existing test module. README.md:1 defines ValueError for negative amounts, while calc.py:1-2 currently applies the percentage to every numeric amount.

## Confidence score

Confidence score: 97% — the requirement, implementation entry point, test home, and CI command are all present.
3% uncertainty — numeric type boundaries and exact error text are unspecified; they belong in design, not this map.

## Entry points and flow

- calc.py:1 is the only fee definition.
- Call flow in the fixture is tests/test_calc.py:2-5 → calc.py:1-2 → numeric result.
- Repository search found two fee( occurrences: the definition and the existing positive assertion.

## Similar patterns and reuse

- tests/test_calc.py:1-5 is the suitable test home and demonstrates unittest/assertEqual.
- AGENTS.md:1 explicitly says to extend suitable existing test files.
- README.md:1 and .github/workflows/test.yml:7 agree on unittest discovery, so the existing command is reusable.

## Change surface

| File | Purpose | Changes Needed |
| --- | --- | --- |
| calc.py | Fee entry point | Validation boundary around current calculation |
| tests/test_calc.py | Existing fee coverage | Negative case and preserved zero/positive behavior |

No new file, API, database, external service, or helper is indicated by current evidence.

## Risks and constraints

- Mid: changing zero handling would exceed the stated negative-only boundary; preserve current zero result.
- Low: ValueError is pinned by README; exact message is not.
- Test constraint: execute the repository's full unittest discovery command, including negative, zero, and positive cases.
- Rollback consideration: the surface is limited to calc.py and its existing test; a rollback must restore both together if callers reject the new exception.

## Needed references

Loaded analyze-work body, exact fixture prompt, AGENTS.md, calc.py, tests/test_calc.py, README.md, and CI workflow. The supplied body names no extra baseline reference required for this analysis.

## Confidence & unverified

Unverified: callers outside this complete five-file fixture, accepted numeric types, and caller exception handling. These do not block the reference map but must be resolved before design claims broader compatibility.
