condition: current
repeat: 1
batch_id: current-r1
execution_kind: supplied-body-procedure
reviewed_revision: aeec06bfa0a6b97402b17824d957f29635f40ba7
context: one shared worker context; no per-case independence
requested_model: gpt-5.6-sol
requested_reasoning: high
effective_model: unavailable
effective_reasoning: unavailable
