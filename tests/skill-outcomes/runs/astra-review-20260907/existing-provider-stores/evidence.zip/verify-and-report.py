from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess
R=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((R/'procedure-manifest.json').read_text())
checks=[];providers=[];gate_runs=[];trace_index=[]
for provider in ['claude','codex','cursor']:
    P=R/provider;W=P/'workspace';inv=json.loads((P/'invocation.json').read_text())
    for source in manifest:
        current=Path(source['source']).read_bytes();copy=(W/'procedure'/source['relative']).read_bytes()
        checks.append({'provider':provider,'source':source['source'],'snapshot':str(W/'procedure'/source['relative']),'before_sha256':source['sha256'],'current_source_sha256':sha(current),'snapshot_sha256':sha(copy),'unchanged':source['sha256']==sha(current)==sha(copy)})
    files=sorted(p for p in W.rglob('*') if p.is_file())
    obs=W/'store/.claude/observations/2026-09-07-gate-honesty.md';old=W/'store/.claude/observations/2026-09-06-existing.md';absent=W/'store/.claude/observations/intentionally-absent.md'
    resultpath=W/'result.json';result=json.loads(resultpath.read_text()) if resultpath.exists() else None
    sourceevent=W/'preflight-evidence.json';event=json.loads(sourceevent.read_text())
    for label,path in [('positive',obs),('enabled-missing',absent)]:
        if label=='positive' and not path.exists():continue
        argv=['node',str(W/'procedure/skills/close/scripts/check-observation-tags.mjs'),str(W/'procedure/docs/contracts/feedback.md'),str(path)]
        p=subprocess.run(argv,capture_output=True,text=True)
        gate_runs.append({'provider':provider,'case':label,'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'artifact_exists':path.exists(),'artifact_sha256':sha(path.read_bytes()) if path.exists() else None,'execution':'independent final-artifact check, not a native-model rerun'})
    native=[];usage=[];models=[]
    for name in ['stdout.jsonl','corrected-stdout.jsonl']:
        p=P/name
        if not p.exists():continue
        for n,line in enumerate(p.read_text().splitlines(),1):
            try:data=json.loads(line)
            except ValueError:continue
            if data.get('model'):models.append({'locator':str(p)+':'+str(n),'kind':'selected startup model','model':data['model']})
            if data.get('type')=='turn.completed':usage.append({'locator':str(p)+':'+str(n),'usage':data.get('usage'),'cost_usd':None})
            if data.get('type')=='result':usage.append({'locator':str(p)+':'+str(n),'usage':data.get('usage'),'cost_usd':data.get('total_cost_usd'),'terminal_reason':data.get('terminal_reason'),'is_error':data.get('is_error')})
            item=data.get('item',{})
            if data.get('type')=='item.completed' and item.get('type')=='command_execution':
                native.append({'locator':str(p)+':'+str(n),'command':item.get('command'),'exit_code':item.get('exit_code'),'output_sha256':sha(item.get('aggregated_output','').encode())})
    trace_index.extend(native)
    fields={}
    if obs.exists():fields=dict(re.findall(r'^- \*\*([^*]+):\*\*\s*(.*)$',obs.read_text(),re.M))
    required=['schema_version','record_id','recorded_at','record_kind','execution_id','producer','recorder','project','skill_or_workflow','phase_area','outcome','evidence_kind','source_record_ids','evidence_identity','validation','friction_observed','would_have_helped','principle']
    providers.append({'provider':provider,'authenticated':True,'auth_basis':'authentication-status.json parent native status','native_startup_attempts':2 if provider=='cursor' else 1,'runs':[json.loads((P/name).read_text()) for name in ['run.json','corrected-run.json'] if (P/name).exists()],'observation_exists':obs.exists(),'observation_path':str(obs),'observation_sha256':sha(obs.read_bytes()) if obs.exists() else None,'observation_fields_present':{k:k in fields for k in required},'source_evidence_identity_matches':fields.get('evidence_identity')=='sha256:'+sha(sourceevent.read_bytes()) if fields else None,'execution_identity_matches':fields.get('execution_id')==inv['provider'].join(['b17-existing-','-20260907']) if fields else None,'existing_record_sha256_before':inv['old_record_sha256'],'existing_record_sha256_after':sha(old.read_bytes()),'existing_record_preserved':inv['old_record_sha256']==sha(old.read_bytes()),'negative_record_absent':not absent.exists(),'native_result':result,'native_selected_models':models,'actual_executed_model':'unknown: Codex trace has no concrete model identifier' if provider=='codex' else 'none: API organization denial before model output' if provider=='claude' else 'none: workspace-trust failure before model output','measured_usage':usage,'actual_files':[{'path':str(p),'sha256':sha(p.read_bytes())} for p in files]})
verification={'captured_at':datetime.now(timezone.utc).isoformat(),'acceptance_id':'B17.AC3','acceptance_text':'Existing configured Claude stores remain usable from Claude, Codex, and Cursor; absent recording does not falsely pass an enabled gate.','overall':'partial','scope':'existing authenticated native CLIs against disposable configured Claude-layout emulations; no live historical/private content','requested_worker_model':'gpt-6-astra/high; distinct effective-host identity not established by this native probe','native_model_selection':'existing configured defaults; Claude/Codex effort high requested by CLI, actual effort metadata unavailable','provider_outcomes':{'claude':'unavailable: authenticated OAuth organization access denied (403 oauth_org_not_allowed)','codex':'observed-bounded: direct observation, positive validation and honest enabled-missing negative gate','cursor':'unavailable: first startup omitted trust; corrected --trust could not succeed with private host writes OS-denied'},'providers':providers,'procedure_invariance':checks,'independent_gate_runs':gate_runs,'native_command_trace_index':trace_index,'external_parent_records':['authentication-status.json','parent-source-invariance.json'],'confidence':95,'unverified':['Live pre-existing private store content and full close/harvest workflow were not exercised.','No fresh-home/discovery or other-host equivalence is inferred.','Claude and Cursor model workflows remain unexecuted for the exact recorded reasons.','Codex native model identifier and monetary cost are not exposed in captured trace.','Existing-host implicit instructions, built-ins, logs and auth runtime behavior are not a clean-room environment; no universal absence claim about implicit host reads.','No credential file was inspected or copied by this worker, and no model tool trace accesses one. Native CLI auth used existing state normally.']}
(R/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
counts={'procedure_copy_checks':len(checks),'procedure_copy_checks_unchanged':sum(x['unchanged'] for x in checks),'existing_store_records_preserved':sum(x['existing_record_preserved'] for x in providers),'new_native_observations':sum(x['observation_exists'] for x in providers),'native_startup_attempts':sum(x['native_startup_attempts'] for x in providers),'independent_positive_tag_passes':sum(x['case']=='positive' and x['exit_code']==0 for x in gate_runs),'independent_enabled_missing_exit2':sum(x['case']=='enabled-missing' and x['exit_code']==2 for x in gate_runs)}
report=f'''# B17.AC3 — existing authenticated provider store probe

**Partial.** Codex produced and validated a real observation in a configured disposable Claude-layout store. Claude was authenticated but denied model access by its organization. Cursor remained blocked at workspace trust under the required host-write boundary. Authentication availability is established separately from model/workflow execution.

Exact AC: “Existing configured Claude stores remain usable from Claude, Codex, and Cursor; absent recording does not falsely pass an enabled gate.” The stores here are explicit scratch emulations containing seeded legacy records, not live private stores or historical observation content. This is a minimal configured recording slice, not a full close/harvest or independent model comparison.

| Provider | Actual native outcome | Artifact / trace |
| --- | --- | --- |
| Claude Code 2.1.251 | One startup, exit 1 after 12.498 s. Native auth status was authenticated; model request returned 403 `oauth_org_not_allowed`: organization disabled subscription access for Claude Code. No observation. No retry. | `claude/stdout.jsonl:1` selected `claude-opus-5[1m]`; `:2` denial; `:3` error result and measured cost. `claude/run.json`. |
| Codex CLI 0.153.2 | One startup, exit 0 after 156.019 s. Wrote one observation and result.json; positive canonical tag check exit 0 and separate enabled absent-record check exit 2/ENOENT. Prior store bytes retained. No completion receipt. | `codex/workspace/store/.claude/observations/2026-09-07-gate-honesty.md`; `codex/workspace/result.json`; native gates `codex/stdout.jsonl:11` and `:13`; prior-byte proof `:16`. |
| Cursor Agent 2026.09.02-c22c1a3 | First startup exit 1 after 12.714 s: omitted `--trust`, a setup failure before model execution. One explicitly authorized correction added `--trust` plus an outer read-only-root bwrap boundary. It exited 1 after 11.532 s: “Failed to trust workspace … check permissions.” No observation/model output; no further attempt. | `cursor/stderr.txt`; `cursor/corrected-invocation.json`; `cursor/corrected-stderr.txt`; both run receipts retained. The failed corrected startup does not identify which trust-state path required writing. |

Current public sources were fully read before the probe: `docs/contracts/feedback.md`, `docs/contracts/change-evidence.md`, `docs/contracts/authorized-work.md`, `skills/close/SKILL.md`, and its `scripts/check-observation-tags.mjs`. `procedure-manifest.json` binds their exact source bytes; all {counts['procedure_copy_checks']}/{counts['procedure_copy_checks']} source/copy comparisons remain equal after execution. `docs/rules/skill-authoring.md` conventions were read. No source edits or commits occurred. Parent's separate authentication and full-source-invariance receipts are included by locator, not rewritten by this worker.

The exact native argv, prompt/stdin bytes, working roots, tool controls, requested effort and process handles are retained in each provider's `invocation.json`, `stdin.txt`, `process.json` and `run.json`; Cursor correction has parallel `corrected-*` files. `run-providers.py` and `cursor-corrected-startup.py` retain the actual runner implementation. The initial maximum was 240 seconds; every initial process finished below the parent's later 180-second target. Corrected Cursor used a 180-second maximum. There are {counts['native_startup_attempts']} startup attempts in total; no clean first-attempt claim for Cursor.

Claude used `--safe-mode --restricted --no-session-persistence`, exact working-directory file tools, no MCP servers and exact allowed tag-validator commands. This retains existing auth; `--bare` was not used. Codex used `--ignore-user-config --ignore-rules --ephemeral`, workspace-write, no writable general `/tmp` or TMPDIR, network-disabled model shell and `project_doc_max_bytes=0`. Cursor used native sandbox plus scratch project Read/Write allowlists and shell denial; its corrected startup additionally exposed the host root read-only, with only its scratch provider subtree writable. A `bwrap ... /usr/bin/true` preflight exited 0. The actual private home was never made writable for that correction. No credential files were read/copied by the worker; identity-bearing auth stdout was discarded by the parent. Stored process output redacts email/account/user/org identity fields.

`verification.json` contains the independent checks and actual file inventory: {counts['existing_store_records_preserved']} seeded records retain their original SHA-256; {counts['new_native_observations']} native observation exists; its required envelope fields, execution ID and preflight artifact identity match. The independent positive tag validation passes, and all {counts['independent_enabled_missing_exit2']} enabled missing-record checks return exit 2 with the files still absent. These independent negative checks do not imply Claude or Cursor ran the workflow. Codex itself recorded the enabled gate as failed, kept recording enabled, and issued no receipt. The canonical checker validates tag shape only; field/evidence identity and receipt posture were inspected separately.

Requested task worker: gpt-6-astra/high. Native processes used configured model defaults; no native model substitution was represented as Astra. Claude startup selected `claude-opus-5[1m]` but the only assistant message was a synthetic API error. Codex executed a model workflow, but its captured JSONL does not disclose the model identifier; result metadata honestly says unknown. Cursor exposed no model identity. Actual high-effort execution is also not independently shown merely by the requested CLI setting.

Measured cost only: Claude reports **$0**, zero input/output tokens and empty modelUsage for the denied request. Codex `stdout.jsonl:22` reports input_tokens=300392, cached_input_tokens=273152, output_tokens=2706 and reasoning_output_tokens=39; monetary cost is unavailable and no dollar estimate or savings claim is made. Cursor reports no usage/cost. Cumulative native usage must not be confused with observation count or invocation telemetry in the store.

Official control references checked 2026-09-07: [Claude CLI](https://code.claude.com/docs/en/cli-reference), [Codex configuration](https://learn.chatgpt.com/docs/config-file/config-reference), [Cursor CLI permissions](https://cursor.com/docs/cli/reference/permissions), and [Cursor sandbox](https://cursor.com/docs/reference/sandbox). Current local help/version captures are in the output root. CLI help establishes supported flags; actual process results establish whether this run worked.

Confidence: **95%** for this bounded disposition (documentation 29/30, patterns 24/25, dependencies 19/20, complexity 14/15, impact 9/10). Remaining 5%: implicit existing-host instructions/runtime behavior, unknown Codex model/cost, synthetic store/evidence content, and unexecuted Claude/Cursor workflows. This does not inspect live private stores, prove fresh-home isolation, or support another-host reliability. B17.AC3 remains partial because native Claude and Cursor execution did not complete; earlier unauthenticated fresh-home attempts remain historical within their original scopes.
'''
(R/'report.md').write_text(report)
artifact_manifest=[]
for p in sorted(R.rglob('*')):
    if not p.is_file() or p.name=='final-artifact-manifest.json':continue
    # Parent historical archives are outside this worker's evidence boundary.
    if any('before-provider' in part for part in p.parts):continue
    artifact_manifest.append({'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())})
(R/'final-artifact-manifest.json').write_text(json.dumps({'captured_at':verification['captured_at'],'files':artifact_manifest},indent=2)+'\n')
print(json.dumps(counts,indent=2));print(report)
