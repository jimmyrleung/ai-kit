"""One native provider attempt each. Existing native auth is used without inspecting it."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,re,subprocess,time
R=Path(__file__).parent
SOURCE=Path('<user-home>/ai-kit')
sha=lambda b:hashlib.sha256(b).hexdigest()
utc=lambda:datetime.now(timezone.utc).isoformat()
sourcepaths=['docs/contracts/feedback.md','docs/contracts/change-evidence.md','docs/contracts/authorized-work.md','skills/close/SKILL.md','skills/close/scripts/check-observation-tags.mjs']
source_manifest=[]
for rel in sourcepaths:
    p=SOURCE/rel;data=p.read_bytes();source_manifest.append({'source':str(p),'relative':rel,'sha256':sha(data)})
(R/'procedure-manifest.json').write_text(json.dumps(source_manifest,indent=2)+'\n')

def sanitize(s):
    s=re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}','[redacted-email]',s)
    s=re.sub(r'(?i)("(?:account_id|accountId|user_id|userId|organization_id|organizationId|org_id|email)"\s*:\s*)"[^"]*"',r'\1"[redacted-identity]"',s)
    return s

def prepare(provider):
    work=R/provider/'workspace';work.mkdir(parents=True,exist_ok=False)
    for row in source_manifest:
        p=work/'procedure'/row['relative'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((SOURCE/row['relative']).read_bytes())
    obs=work/'store/.claude/observations';obs.mkdir(parents=True)
    old=obs/'2026-09-06-existing.md';old.write_text('# Existing disposable store record\n\nThis is a seeded legacy record in a Claude-layout emulation. Keep these bytes unchanged. It contains no real historical private data.\n')
    execution='b17-existing-'+provider+'-20260907'
    profile={'profile':'claude-layout','schema_version':1,'root':str(work/'store/.claude'),'recording':'enabled','acceptance_gate':True,'paths':{'observation':str(obs)},'other_record_kinds':'disabled','execution_id':execution,'scope':'disposable emulation; not live home or historical private content'}
    (work/'store-profile.json').write_text(json.dumps(profile,indent=2)+'\n')
    checker=work/'procedure/skills/close/scripts/check-observation-tags.mjs';contract=work/'procedure/docs/contracts/feedback.md'
    absent=obs/'intentionally-absent.md';positive=obs/'2026-09-07-gate-honesty.md'
    negcmd=['node',str(checker),str(contract),str(absent)]
    pre=subprocess.run(negcmd,capture_output=True,text=True)
    event={'record_id':execution+'-preflight','record_kind':'verification','captured_at':utc(),'argv':negcmd,'exit_code':pre.returncode,'stdout':pre.stdout,'stderr':pre.stderr,'subject':'enabled tag gate given an actually absent observation path','synthetic_fixture':True}
    eventpath=work/'preflight-evidence.json';eventpath.write_text(json.dumps(event,indent=2)+'\n')
    shellgate=provider!='cursor'
    prompt=f'''Execute one bounded configured-store recording workflow for B17.AC3 in this scratch workspace: {work}.
This is explicitly authorized evidence work using a disposable existing Claude-layout emulation. Never access any actual home/private store, credentials, account details, source repository, external tools or network. No delegation, installs, Git changes, policy edits, deletions or other workflows. Use only the supplied public procedure copies and this workspace. Do not invoke global close or skills. Existing host instructions may be present; this explicit scratch store configuration wins over any default private path.

Read store-profile.json, preflight-evidence.json, procedure/docs/contracts/feedback.md, and the relevant observation/tag/receipt sections of procedure/skills/close/SKILL.md. Inspect the existing observation filename and bytes to preserve the existing record. This is a minimal recording slice, not a whole-session close ritual: memory, rules, skills, commits and SESSION_LOG are outside scope.

Produce one observation at {positive}. Ground it in the actual supplied preflight result: the enabled canonical tag validator received a nonexistent input and returned its observed error/exit. This is artifact-reconstructed evidence, not lived private history. Include the feedback common envelope and observation fields, source_record_ids=[{event['record_id']}], evidence_identity=sha256:{sha(eventpath.read_bytes())}, execution_id={execution}, producer={provider}-native, recorder=b17-probe-recorder, project=disposable-provider-store. Use one canonical tag at the end of friction_observed. Do not fabricate another observation or count this as instrumented invocation telemetry. Preserve the seeded legacy record byte-for-byte.

For this provider, shell validation is {'available only for the two exact node commands below' if shellgate else 'intentionally disabled; outer recorder will execute the canonical validator independently'}.
Positive validation argv: {json.dumps(['node',str(checker),str(contract),str(positive)])}
Negative validation argv: {json.dumps(negcmd)}
{'Execute both commands as separate checks. Use their actual exits. Record validation passed only after the positive gate passes.' if shellgate else 'Do not request a shell or attempt a bypass. Mark validation unavailable with reason awaiting outer-recorder canonical tag validation. Do not claim a completed recording receipt.'}

The negative scenario is a separate enabled-required-record gate: intentionally-absent.md must remain absent. Report its gate as failed/unavailable, never passed or recording disabled. Do not create the missing record, disable that requirement, or issue a negative-scenario completion receipt.

Write result.json in the workspace with producer, execution_id, actual observation path, positive validation result/reason, negative enabled=true/result/reason, prior_record_preserved, completion_receipt_issued=false or its exact positive-only scope if independently validated. Preserve unavailable results if a tool is blocked; do not retry or broaden permissions. Report actual model metadata only if available, otherwise unknown. No estimated cost. End with one concise result summary.
'''
    (R/provider/'stdin.txt').write_text(prompt)
    if provider=='claude':
        allow=['Read','Write']+['Bash('+ ' '.join(cmd)+')' for cmd in [['node',str(checker),str(contract),str(positive)],negcmd]]
        argv=['claude','--print','--safe-mode','--restricted','--no-session-persistence','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--no-chrome','--permission-mode','dontAsk','--tools','Read,Write,Bash','--allowedTools',','.join(allow),'--effort','high','--output-format','stream-json','--verbose']
    elif provider=='codex':
        argv=['codex','exec','--ignore-user-config','--ignore-rules','--ephemeral','--skip-git-repo-check','--sandbox','workspace-write','-C',str(work),'-c','approval_policy="never"','-c','sandbox_workspace_write.exclude_slash_tmp=true','-c','sandbox_workspace_write.exclude_tmpdir_env_var=true','-c','sandbox_workspace_write.network_access=false','-c','project_doc_max_bytes=0','-c','web_search="disabled"','-c','model_reasoning_effort="high"','--json','-']
    else:
        config=work/'.cursor';config.mkdir()
        (config/'cli.json').write_text(json.dumps({'permissions':{'allow':['Read('+str(work)+'/**)','Write('+str(obs)+'/*.md)','Write('+str(work/'result.json')+')'],'deny':['Shell(*)','Read(/home/**)','Write(/home/**)','Write('+str(work/'procedure')+'/**)','Write('+str(old)+')','Write('+str(work/'store-profile.json')+')']}},indent=2)+'\n')
        (config/'sandbox.json').write_text(json.dumps({'type':'workspace_readwrite','disableTmpWrite':True,'networkPolicy':{'default':'deny','allow':[],'deny':[]}},indent=2)+'\n')
        argv=['cursor-agent','--print','--output-format','stream-json','--sandbox','enabled','--workspace',str(work),prompt]
    config={'provider':provider,'argv':argv,'stdin_path':str(R/provider/'stdin.txt'),'stdin_sha256':sha(prompt.encode()),'prompt_transport':'argv for Cursor (stdin kept as exact reusable prompt); stdin for Claude/Codex','cwd':str(work),'timeout_seconds':240,'native_model_request':'configured native default; no substitution request; task worker requested gpt-6-astra/high separately','native_effort_request':'high' if shellgate else 'configured native default','existing_auth':'parent authenticated=true; no auth files inspected/copied','old_record_sha256':sha(old.read_bytes()),'procedure_manifest':source_manifest,'created_at':utc()}
    (R/provider/'invocation.json').write_text(json.dumps(config,indent=2)+'\n')
    return provider,work,argv,prompt,config

def execute(spec):
    provider,work,argv,prompt,config=spec;start=time.monotonic();started=utc()
    env=os.environ.copy()
    # Bash provider subprocesses receive no task-specific credential manipulation.
    # These flags only suppress unrelated host persistence/customization where supported.
    if provider=='claude':env['CLAUDE_CODE_SKIP_PROMPT_HISTORY']='1'
    p=subprocess.Popen(argv,cwd=work,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env)
    (R/provider/'process.json').write_text(json.dumps({'pid':p.pid,'started_at':started,'timeout_seconds':240},indent=2)+'\n')
    timedout=False
    try:stdout,stderr=p.communicate(None if provider=='cursor' else prompt,timeout=240)
    except subprocess.TimeoutExpired:
        timedout=True;p.terminate()
        try:stdout,stderr=p.communicate(timeout=10)
        except subprocess.TimeoutExpired:p.kill();stdout,stderr=p.communicate()
    (R/provider/'stdout.jsonl').write_text(sanitize(stdout));(R/provider/'stderr.txt').write_text(sanitize(stderr))
    result={'provider':provider,'started_at':started,'completed_at':utc(),'elapsed_seconds':round(time.monotonic()-start,3),'exit_code':p.returncode,'timed_out':timedout,'pid':p.pid,'stdout':'stdout.jsonl','stderr':'stderr.txt','sanitization':'Email and account/user/org identity fields redacted before storage; auth status not rerun. Opaque execution/session IDs retained.','attempts':1}
    (R/provider/'run.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    return result

specs=[prepare(p) for p in ['claude','codex','cursor']]
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(execute,specs))
(R/'provider-runs.json').write_text(json.dumps(results,indent=2)+'\n')
