from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,time
R=Path(__file__).parent;P=R/'cursor';W=P/'workspace'
original=json.loads((P/'invocation.json').read_text())
native=original['argv'][:-1]+['--trust',original['argv'][-1]]
argv=['bwrap','--ro-bind','/','/','--bind',str(P),str(P),'--dev','/dev','--proc','/proc','--chdir',str(W),'--die-with-parent']+native
record={'provider':'cursor','attempt':2,'model_workflow_attempt':1,'classification':'informed correction of pre-model omitted-trust startup','argv':argv,'stdin':'none; original exact prompt remains final argv element and stdin.txt','timeout_seconds':180,'native_permissions':'unchanged scratch cli.json; shell denied; native sandbox enabled','host_write_constraint':'bwrap root read-only; only cursor scratch subtree bind writable; native private policy writes are OS-denied','wrapper_preflight':{'argv':['bwrap','--ro-bind','/','/','--bind',str(P),str(P),'--dev','/dev','--proc','/proc','--chdir',str(W),'/usr/bin/true'],'observed_exit_code':0},'started_at':datetime.now(timezone.utc).isoformat()}
(P/'corrected-invocation.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic();p=subprocess.Popen(argv,cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
(P/'corrected-process.json').write_text(json.dumps({'pid':p.pid,'started_at':record['started_at']},indent=2)+'\n')
timedout=False
try:out,err=p.communicate(timeout=180)
except subprocess.TimeoutExpired:
 timedout=True;p.terminate()
 try:out,err=p.communicate(timeout=10)
 except subprocess.TimeoutExpired:p.kill();out,err=p.communicate()
def sanitize(s):
 s=re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}','[redacted-email]',s)
 return re.sub(r'(?i)("(?:account_id|accountId|user_id|userId|organization_id|organizationId|org_id|email)"\s*:\s*)"[^"]*"',r'\1"[redacted-identity]"',s)
(P/'corrected-stdout.jsonl').write_text(sanitize(out));(P/'corrected-stderr.txt').write_text(sanitize(err))
result={'provider':'cursor','attempt':2,'model_workflow_attempt':1,'started_at':record['started_at'],'completed_at':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':round(time.monotonic()-start,3),'exit_code':p.returncode,'timed_out':timedout,'pid':p.pid,'stdout':'corrected-stdout.jsonl','stderr':'corrected-stderr.txt'}
(P/'corrected-run.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
