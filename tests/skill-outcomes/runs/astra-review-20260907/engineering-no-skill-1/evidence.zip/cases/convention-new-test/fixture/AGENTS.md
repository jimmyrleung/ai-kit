Repository convention: validation failure scenarios belong in tests/test_calc_validation.py, separate from normal calculation tests.
