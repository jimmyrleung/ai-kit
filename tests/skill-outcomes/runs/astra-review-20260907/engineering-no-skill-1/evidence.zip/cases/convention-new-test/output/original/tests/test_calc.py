import unittest
from calc import fee
class FeeTests(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(fee(100), 2)
