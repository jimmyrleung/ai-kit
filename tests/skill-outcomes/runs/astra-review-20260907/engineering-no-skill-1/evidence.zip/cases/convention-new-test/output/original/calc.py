def fee(amount):
    return amount * 0.02
