def fee(amount):
    if amount < 0:
        raise ValueError("amount must be non-negative")
    return amount * 0.02
