Run python3 -m unittest discover -s tests. Reject negative amounts with ValueError.
