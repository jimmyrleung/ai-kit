Extend suitable existing test files.
