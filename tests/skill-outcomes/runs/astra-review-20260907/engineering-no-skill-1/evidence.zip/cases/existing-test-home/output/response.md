Implemented only the requested validation. `fee()` now raises `ValueError` for a negative amount and preserves the calculation for zero and positive amounts. I extended the suitable existing `tests/test_calc.py` with negative and zero cases; its existing positive case remains. The repository test command passed all 3 tests.

Confidence score: 99%. The source, local instructions, documentation, CI command, and executed tests agree. The remaining 1% reflects that only the small supplied fixture exists, so there are no broader integrations to inspect.
