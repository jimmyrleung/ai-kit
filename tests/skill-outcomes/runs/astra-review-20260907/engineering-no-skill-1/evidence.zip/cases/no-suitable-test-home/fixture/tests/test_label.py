import unittest
class LabelTests(unittest.TestCase):
    def test_label(self):
        self.assertEqual("receipt".upper(), "RECEIPT")
