Observed triage source: `<user-home>/ai-kit/skills/triage/SKILL.md`

> **Recommend:** `document-workflow handler.py:create` — confidence 99% — because this is a one-shot request to document an existing handler.
> (Run it when ready; redirect if this is wrong.)

1% uncertainty: the desired documentation depth and output location are unspecified.

Triage note — `route_picked: document-workflow` · `confidence: 99%` · `questions_asked: 0` · `signals: document, existing handler`

AI_KIT_LITERAL "$()" `quoted`
second-line