# Synthetic tasks

## Task 1
Status: Done

## Acceptance criteria
- returns 2
