# B12 T5 result

The run stopped after alpha's byte-identical relocation. Its manifest remains `raw-ready`; `sources/course/alpha.md` does not exist, no source is marked integrated, and no completed conversion log or digest exists.
