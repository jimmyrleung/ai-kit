# Close receipt outcomes

## A — `session-current`, no work after receipt

No-op. The existing completed receipt has the same `execution_id:session-current`, and the fixture supplies no later work. `a-noop/SESSION_LOG.md` remains byte-identical.

## B — `session-current`, one new in-session decision

Blocked/unavailable: the fixture says a decision occurred but does not supply the decision or rationale. Creating a decision summary or a superseding `close-current` receipt would manufacture the missing work boundary. `b-new-decision/SESSION_LOG.md` remains byte-identical; the intended next receipt would require `execution_id:session-current` and `supersedes:close-current` after the missing work is supplied and enabled recorders validate.

## C — `session-later`, same date

A different execution ID cannot adopt the top entry merely because the date matches. `c-later/SESSION_LOG.md` prepends a new entry and preserves the existing entries.

Recording is disabled in this isolated fixture. No completion receipt was written before that state was resolved.
