# B12 T3 result

Blocked. Both `legacy/alpha.md` and `raw/course/alpha.md` exist and have different SHA-256 identities. The manifest row requires owner disposition; neither file nor the manifest was changed.
