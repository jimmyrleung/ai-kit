# Documentation W2 freshness result

Each row is an independent Git fixture copy. Current docs were not rewritten.

| State | Bucket | Evidence locator |
| --- | --- | --- |
| unchanged | Current | `unchanged/docs/workflows/widgets-web/widgets-by-id-get.md`; all three recorded file hashes match and recorded revision is current/ancestor |
| unrelated untracked `notes.txt` | Current | `unrelated/source/notes.txt` is outside recorded source paths and boundary; doc hash before/after classification is `17427dc12b0ed0e73bbebd03db2c1419b3445386f22a60f18282a18efeb2f52e` |
| relevant unstaged handler edit | Stale | `unstaged/source/next/src/app/(ops)/api/widgets/[id]/route.ts`; Git ` M`, actual hash differs |
| relevant staged handler edit | Stale | same path under `staged/source`; Git `M `, actual hash differs |
| untracked route registration | Stale | `untracked/source/next/src/app/new/route.ts`; boundary `src/app/**/route.ts` gained a file at unchanged HEAD |
| moved entry/registration | Stale; scoped retrace required | recorded route deleted and `moved/source/next/src/app/(ops)/api/items/[id]/route.ts` added |
| inaccessible revision | Unverifiable | `nonancestor/.../widgets-by-id-get.md` records `ffffffffffffffffffffffffffffffffffffffff`, absent from the repo |
| readable sibling changed | Stale | `sibling-changed/sibling/module.txt` changed from recorded SHA `2d27...` to new bytes while primary HEAD stayed fixed |
| sibling unreadable | Unverifiable | recorded absolute `sibling-unreadable/sibling/module.txt` no longer resolves; preserved bytes are under `sibling-offline/` only for fixture recovery |
