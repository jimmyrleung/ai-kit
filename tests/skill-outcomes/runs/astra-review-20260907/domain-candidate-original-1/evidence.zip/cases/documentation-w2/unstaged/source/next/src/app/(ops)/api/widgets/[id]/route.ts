export const GET = async () => Response.json({ ok: true, changed: true })

export function POST() {
  return Response.json({ created: true })
}
