export const GET = async () => Response.json({ discovered: true })
