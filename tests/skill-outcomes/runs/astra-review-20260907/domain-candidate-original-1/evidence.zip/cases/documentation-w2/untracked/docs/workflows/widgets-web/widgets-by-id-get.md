# GET widget by ID

## Summary

| Field | Value |
| --- | --- |
| Created | 2026-09-07 |
| Last Updated | 2026-09-07 |
| Generated From | `7ff84e2` |
| Schema | v2 |
| Mode | Backend |
| Source Root | `/tmp/astra-backlog-5VdqNm/trials/domain/candidate/1/cases/documentation-w2/untracked/source/next` |
| Docs Root | `/tmp/astra-backlog-5VdqNm/trials/domain/candidate/1/cases/documentation-w2/untracked/docs` |

Handles `GET /api/widgets/[id]`. The supplied handler returns a JSON response containing `ok: true`; it does not read the route parameter.

## Sequence of Calls

```text
GET /api/widgets/[id]
└── route.ts:GET
    └── Response.json({ ok: true })
```

## Flow Description

1. Next.js dispatches a GET request matching `/api/widgets/[id]` to the exported `GET` constant.
2. The async function constructs a JSON response with `{ ok: true }`.
3. There are no branches or downstream calls in the supplied source.

## Data Inventory

| Kind | Name | Direction | Fields |
| --- | --- | --- | --- |
| Route parameter | `id` | Input | Present in route, unused by handler |
| JSON response | response | Output | `ok: boolean` |

## Business Rules

- Every dispatched request returns an affirmative JSON result.
- The route identifier does not affect the result in the supplied implementation.

## Configuration

- `next.config.mjs` exists and contains no workflow-specific configuration.

## Dependencies

- Next.js App Router dispatch.
- Web platform `Response.json`.

## Source Evidence

| Source ID | Revision | Ancestor | Trace boundary | Dirty paths | Manifest SHA-256 |
| --- | --- | --- | --- | --- | --- |
| `fixture-workflow` | `7ff84e2d04e3140a9575a5077b009ddf4dd4d348` | yes | `next.config.mjs`, `package.json`, `src/app/**/route.ts`; GET export at `src/app/(ops)/api/widgets/[id]/route.ts` | none | `72fffbb9594253032a8bd04be9cc80fb63d41b0781bf1b69b02a9132c3d48c3a` |

## Source Files

| Source ID | Path | Role | SHA-256 |
| --- | --- | --- | --- |
| `fixture-workflow` | `next.config.mjs` | App Router control | `fc00d19bc94e10c24f07bd9be1c2bb24d4978856963c5a68745338ecbf131dfc` |
| `fixture-workflow` | `package.json` | Framework and workspace identity | `ecba6a0f12f8c139d3948893dfef74547df674d848764358acafb6c2d5ef6c46` |
| `fixture-workflow` | `src/app/(ops)/api/widgets/[id]/route.ts` | Route registration and handler | `9d3566d988503f0573664176d4451ef73a79055616889a42e67ffc98390ae3b5` |

## Change Log

| Date | Change | Reason |
| --- | --- | --- |
| 2026-09-07 | Initial documentation pass | First version |
