export const GET = async () => Response.json({ ok: true, staged: true })

export function POST() {
  return Response.json({ created: true })
}
