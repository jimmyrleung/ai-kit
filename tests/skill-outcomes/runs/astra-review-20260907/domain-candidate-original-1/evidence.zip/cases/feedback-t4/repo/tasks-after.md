# Fixture tasks

<!-- close-tasks: harvested through abc123 @ 2026-09-06 -->

## Task 1 — repository change

**Status:** Done
**Lifecycle:** pre-merge

### Verify

- Gate 1: pass
- Gate 3: FAIL — accepted: fixture environment differs

## Task 2 — live rehearsal

**Status:** Todo
**Lifecycle:** live

<!-- evidence:begin harvest-feedback-t4-candidate-r1 -->
feedback-harvest:
  schema_version: 1
  record_id: harvest-feedback-t4-candidate-r1
  record_kind: feedback-harvest
  recorded_at: 2026-09-07T07:18:00-03:00
  execution_id: fixture-feedback-t4-candidate-r1
  producer: close-tasks
  recorder: close-tasks
  verdict: passed
  supersedes: none
  runner_attribution: verified
  repository_status: complete
  operational_status: pending
  artifact_manifest: tasks-after(subject)=58e5f321df4fa46c4dde3c0963c1a9fe13ba1b9964d3e9d384c88bb093f2a29f; qa=e632425f2ae8c938aea5658e3a682c127afea9e790980733e7492c382733fadc; matching-state=bdbfa6be682d163fc7b4ddc6d91b47f4b4bb6d8d6c9237558a1590407707501d; stale-state=c8d3a88944804337e621ee6111a13e32d4e44fadbc543729945c4caa7aa0191d
  observation_ids: disabled
  gaps: observations disabled; live rehearsal pending
<!-- evidence:end harvest-feedback-t4-candidate-r1 -->
