# Close-tasks harvest decision

- The legacy `harvested through abc123` line is commit-only and unverified. Stripping that line and evidence regions gives subject identities `tasks-before=9cf82436506ff21a953c160b189c8bc4bec0a0e0bdd4caeab69cdaccf695479d` and `tasks-after=58e5f321df4fa46c4dde3c0963c1a9fe13ba1b9964d3e9d384c88bb093f2a29f`; the changed Verify bytes require a new harvest at unchanged claimed HEAD.
- `matching-state.json` binds the canonical trial `tasks-after.md` path and reports Task 1 Done, attempt 1. `stale-state.json` points at `other-tasks.md`, uses an incompatible window, and is rejected.
- Observation recording is not configured, so zero observations were emitted (`at most one` satisfied) and no tag-validation PASS is claimed.
- Repository status is complete from pre-merge Task 1 plus QA recommendation `go`; operational status is pending because live Task 2 is Todo.
- The manifest-bound receipt is appended to `repo/tasks-after.md`; the legacy marker remains history.
