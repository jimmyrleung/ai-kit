# Observation tag validation

Contract loaded: frozen `docs/contracts/feedback.md`, `## Tags`. No record was written.

| Index | Exact decoded raw value | Result | Exact valid alternative |
| ---: | --- | --- | --- |
| 1 | `buggy_code` | valid portable baseline token; retained unchanged | `buggy_code` |
| 2 | `buggy-code` | invalid: hyphenated token is not listed | `buggy_code` |
| 3 | `` `buggy_code` `` | invalid: backticks are part of the value | `buggy_code` |
| 4 | `buggy_code,code_path_gap` | invalid: combines two tokens and `code_path_gap` is not in the portable baseline | Use one observation with `buggy_code`; if a second distinct finding exists, choose one listed token supported by its evidence. No exact substitute for `code_path_gap` can be chosen without that evidence. |
| 5 | `"buggy_code"` | invalid: quote characters are part of the value | `buggy_code` |
| 6 | `buggy_code<U+00A0>` | invalid: trailing non-breaking space changes the exact token | `buggy_code` |

The repeated appearance of `buggy_code` inside malformed candidates is neither silently normalized nor counted as an invocation. Invocation coverage remains unavailable because tags and observations are not invocation telemetry.
