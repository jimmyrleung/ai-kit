# B12 T1 result

The tracked alpha origin is deleted in the worktree and its byte-identical raw destination retains `intended_tracking=tracked`; the proposed relocation set is `legacy/alpha.md -> raw/course/alpha.md` plus the tracked manifest update. Beta's origin and destination are untracked and remain outside that proposed tracked relocation set. No index mutation, staging, or commit occurred during the procedure.
