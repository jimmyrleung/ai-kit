---
status: summarized
domains: [course]
themes: [idempotency]
date_consumed: 2026-09-07
source_type: markdown
original_filename: legacy/beta.md
raw: raw/course/beta.md
sha256_prefix: 532b49ac7ac2
---
# Beta

Idempotency keys support safe handling of repeated requests.

## Source Trail

- [[../../raw/course/beta]]
