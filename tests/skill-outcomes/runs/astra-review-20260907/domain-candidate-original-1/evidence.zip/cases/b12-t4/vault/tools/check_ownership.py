from pathlib import Path
import hashlib, json
raws = set(Path("raw").rglob("*.md"))
claimed = set()
for note in Path("sources").rglob("*.md"):
    fields = dict(line.split(": ", 1) for line in note.read_text().split("---")[1].splitlines() if ": " in line)
    raw = Path(fields["raw"])
    assert raw in raws, "missing or unsupported raw path"
    assert hashlib.sha256(raw.read_bytes()).hexdigest().startswith(fields["sha256_prefix"]), "hash drift"
    claimed.add(raw)
print(json.dumps({"raw": len(raws), "claimed": len(claimed), "unclaimed": sorted(str(p) for p in raws-claimed), "exhaust": [], "unresolved": []}))
