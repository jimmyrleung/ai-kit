# Vault schema
This vault is locally managed.
## Compile
archetype: synthesis-wiki
cadence: weekly
compile_targets: [wiki/topics, wiki/concepts, wiki/comparisons]
digest_dir: wiki/_compilations
synthesis_depth: moc+notes
## Ownership
Sources use a single vault-relative raw: frontmatter path and sha256_prefix of its bytes. The read-only checker is tools/check_ownership.py; run python3 tools/check_ownership.py from the vault root. No directory/glob/companion pointer forms occur in this fixture.
