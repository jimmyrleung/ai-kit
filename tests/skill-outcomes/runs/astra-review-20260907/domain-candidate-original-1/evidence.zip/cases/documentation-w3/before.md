# Documentation Tasks — Fixture

> Inventory Schema: v2

## Task 1 — Document `widgets.list`

**Status:** Done
**Workflow ID:** `widgets:http:get:/api/widgets`
<!-- inventory:begin -->
**Reference:** `src/routes.ts:listWidgets`
**Files affected:** `workflows/widgets/list.md`
**Trigger:** REST GET `/api/widgets`
<!-- inventory:end -->

Manual note: reviewed with the API owner.

### Verify — retained

- Evidence: passed at revision abc123.

## Task 2 — Document `widgets.old-event`

**Status:** In Progress
**Workflow ID:** `widgets:queue:widget-old`
<!-- inventory:begin -->
**Reference:** `src/handlers.ts:oldEvent`
**Files affected:** `workflows/widgets/old-event.md`
**Trigger:** Queue `widget-old`
<!-- inventory:end -->

Manual note: clarify retirement.

