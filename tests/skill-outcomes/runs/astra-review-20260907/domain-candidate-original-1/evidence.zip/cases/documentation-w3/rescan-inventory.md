# New scan (canonical execution boundaries)

- `widgets:http:get:/api/health` — `src/routes.ts:health`; alphabetically earlier addition.
- `widgets:http:get:/api/widgets` — `src/moved-routes.ts:listWidgets`; same external boundary,
  changed generated reference.
- `widgets:http:post:/api/widgets` — `src/routes.ts:createWidget`; independent flow in same
  physical file as health.
- `widgets:queue:widget-new` — `src/handlers.ts:newEvent`; possible rename of old event, not
  enough evidence to transfer status.

