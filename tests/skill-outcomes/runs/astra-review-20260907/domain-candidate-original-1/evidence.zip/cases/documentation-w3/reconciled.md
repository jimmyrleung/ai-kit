# Documentation Tasks — Fixture

> Inventory Schema: v2

## Task 3 — Document `health`

**Status:** Todo
**Workflow ID:** `widgets:http:get:/api/health`
<!-- inventory:begin -->
**Reference:** `src/routes.ts:health`
**Files affected:** `workflows/widgets/health.md`
**Trigger:** REST GET `/api/health`
<!-- inventory:end -->

## Task 1 — Document `widgets.list`

**Status:** Done
**Workflow ID:** `widgets:http:get:/api/widgets`
<!-- inventory:begin -->
**Reference:** `src/moved-routes.ts:listWidgets`
**Files affected:** `workflows/widgets/list.md`
**Trigger:** REST GET `/api/widgets`
<!-- inventory:end -->

Manual note: reviewed with the API owner.

### Verify — retained

- Evidence: passed at revision abc123.

## Task 4 — Document `widgets.create`

**Status:** Todo
**Workflow ID:** `widgets:http:post:/api/widgets`
<!-- inventory:begin -->
**Reference:** `src/routes.ts:createWidget`
**Files affected:** `workflows/widgets/create.md`
**Trigger:** REST POST `/api/widgets`
<!-- inventory:end -->

## Task 5 — Document `widgets.new-event`

**Status:** Todo
**Workflow ID:** `widgets:queue:widget-new`
<!-- inventory:begin -->
**Reference:** `src/handlers.ts:newEvent`
**Files affected:** `workflows/widgets/new-event.md`
**Trigger:** Queue `widget-new`
<!-- inventory:end -->

## Retired workflows — review required

Possible rename: `widgets:queue:widget-old` → `widgets:queue:widget-new`; evidence and status were not transferred.

## Task 2 — Document `widgets.old-event`

**Status:** Review retirement
**Workflow ID:** `widgets:queue:widget-old`
<!-- inventory:begin -->
**Reference:** `src/handlers.ts:oldEvent`
**Files affected:** `workflows/widgets/old-event.md`
**Trigger:** Queue `widget-old`
<!-- inventory:end -->

Manual note: clarify retirement.
