# Orders create

## Summary

Schema v2. Workspace `orders`; entry `handler.py:create`; input `id` is returned as `order_id`.

## Sequence of Calls

`create` → input `id` → output `order_id`.

## Flow Description

Maps the input ID to an order ID.

## Data Inventory

Input `id`; output `order_id`.

## Business Rules

Output order ID equals input ID.

## Configuration

None.

## Dependencies

None beyond Python.

## Source Evidence

Workspace boundary `orders/handler.py:create`.

## Source Files

`orders/handler.py` SHA-256 is verified in the result manifest.

## Change Log

2026-09-07 initial pass.
