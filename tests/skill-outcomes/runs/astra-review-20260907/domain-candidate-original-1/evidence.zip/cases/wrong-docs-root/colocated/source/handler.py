def create(request):
    return {"id": request["id"]}
