# Create

## Summary

Schema v2. Source and docs roots are both the containing `source/` directory. Entry: `handler.py:create`.

## Sequence of Calls

`create(request)` → read input `id` → return output `id`.

## Flow Description

The handler returns the supplied ID.

## Data Inventory

Input/output field: `id`.

## Business Rules

- Output ID equals input ID.

## Configuration

None.

## Dependencies

Python mapping access only.

## Source Evidence

Boundary `handler.py:create`; actual byte identity is in Source Files.

## Source Files

| Source ID | Path | Role | SHA-256 |
| --- | --- | --- | --- |
| `billing-source` | `handler.py` | entry and complete flow | `864072a7c0c1baa5b3f51c0354722af3c6a15168cef6d66c2eb771d5342b6a32` |

## Change Log

| Date | Change |
| --- | --- |
| 2026-09-07 | Initial documentation pass |
