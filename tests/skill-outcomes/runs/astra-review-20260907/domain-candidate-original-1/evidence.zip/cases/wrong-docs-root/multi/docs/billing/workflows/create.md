# Billing create

## Summary

Schema v2. Workspace `billing`; entry `handler.py:create`; input `id` is returned as `id`.

## Sequence of Calls

`create` → input `id` → output `id`.

## Flow Description

Copies the input ID.

## Data Inventory

`id` input/output.

## Business Rules

Output equals input.

## Configuration

None.

## Dependencies

None beyond Python.

## Source Evidence

Workspace boundary `billing/handler.py:create`.

## Source Files

`billing/handler.py` SHA-256 is verified in the result manifest.

## Change Log

2026-09-07 initial pass.
