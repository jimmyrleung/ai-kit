# Documentation tasks
Task create: source_root=source; docs_root=docs; workspace=billing; entry=handler.py:create; resolved_output=docs/workflows/create.md
Acceptance: docs/workflows/create.md exists and names the input id.
