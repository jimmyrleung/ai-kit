# Create

## Summary

| Field | Value |
| --- | --- |
| Schema | v2 |
| Source root | `/tmp/astra-backlog-5VdqNm/trials/domain/candidate/1/cases/wrong-docs-root/separate/source` |
| Docs root | `/tmp/astra-backlog-5VdqNm/trials/domain/candidate/1/cases/wrong-docs-root/separate/docs` |
| Workspace root | `/tmp/astra-backlog-5VdqNm/trials/domain/candidate/1/cases/wrong-docs-root/separate/source` |
| Entry | `handler.py:create` |

## Sequence of Calls

`create(request)` → read `request["id"]` → return `{ "id": value }`.

## Flow Description

The handler copies the required input field `id` to the output object. A missing `id` raises the language's key lookup error.

## Data Inventory

Input and output both contain `id`.

## Business Rules

- The input must contain `id`.
- The returned ID equals the supplied ID.

## Configuration

None observed.

## Dependencies

Python mapping access only.

## Source Evidence

| Source ID | Boundary | Dirty | Manifest |
| --- | --- | --- | --- |
| `billing-source` | `handler.py:create` | none | handler byte hash recorded below |

## Source Files

| Source ID | Path | Role | SHA-256 |
| --- | --- | --- | --- |
| `billing-source` | `handler.py` | entry and complete flow | `864072a7c0c1baa5b3f51c0354722af3c6a15168cef6d66c2eb771d5342b6a32` |

## Change Log

| Date | Change |
| --- | --- |
| 2026-09-07 | Initial documentation pass |
