# Wrong-docs-root result

- Separate roots: the promised artifact exists exactly at `separate/docs/workflows/create.md`; no doc was written under `separate/source/`.
- Co-located roots: the derived artifact exists at `colocated/source/workflows/create.md` and `handler.py` remains byte-identical.
- Multi-workspace: billing and orders resolve to distinct destinations under `multi/docs/<workspace>/workflows/create.md`; neither overwrites the other.
- Refresh resolution: `handler.py:create` resolves from each declared workspace/source root. It is never resolved relative to the docs root or current working directory.
