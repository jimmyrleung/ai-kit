# Documentation W1 result

- Next.js: `separate/docs/next/_docs-tasks.md` contains GET and POST `/api/widgets/[id]` from the root/src route, omits `(ops)`, supports const/async and sync function exports, captures `archiveWidget`, and leaves the unresolved re-export as a Partial coverage boundary in `project-overview.md`.
- ASP.NET: `separate/docs/dotnet-web/_docs-tasks.md` captures composed `/api/widgets/{id}` from the Web SDK project; its overview marks the runtime-prefix health route Partial.
- Functions: `separate/docs/functions/_docs-tasks.md` keeps `[Function] QueueIngest` and `[FunctionName] LegacyTimer` as separate IDs despite one physical file.
- Every task records Source root, Docs root, Workspace root, Reference, Resolved output, and Workflow ID. One task was executed at exactly `separate/docs/next/workflows/widgets-web/widgets-by-id-get.md`; it is schema v2 with Source Evidence and actual Source Files hashes.
- Co-located artifacts are under each `colocated/source/<workspace>/_docs/`; multi-workspace artifacts are distinct under `multi/docs/{next,dotnet-web,functions}`.
- Source code bytes match the supplied fixture. The frozen candidate did not include the referenced `references/detectors.md` or `references/output-template.md`; no live copy was substituted. The output is therefore grounded in the body, fixture source, and fixture expected contract, with the missing references recorded as a limitation.
