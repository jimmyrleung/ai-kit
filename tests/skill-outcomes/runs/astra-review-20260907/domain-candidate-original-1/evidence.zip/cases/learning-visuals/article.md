# Queue ordering
The diagram distinguishes acknowledgement before storage from acknowledgement after storage. Which side loses data is visible only in the arrows.
![ordering](ordering.svg)
Caption: Two orderings.
