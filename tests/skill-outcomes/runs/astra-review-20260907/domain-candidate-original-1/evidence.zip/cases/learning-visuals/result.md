# Interactive result

🎧 TTS + visual review — confidence 98%
The prose names the comparison, but the decisive failure/retention mapping lives in the diagram's arrows. Audio can carry the setup; inspect the single ordering diagram before accepting the causal conclusion.
Before listening: Track whether acknowledgement happens before or after durable storage.
Review visually: `ordering.svg` — compare A (`acknowledge → crash → store`, data lost) with B (`store → acknowledge → crash`, data retained).
Audio 62 · Visual 72 · Density 38 · Visual review ~35%
Listening @1×: 1 min

# Structured consumer

```json
{
  "contentType": "article",
  "mode": "TTS_PLUS_REVIEW",
  "confidence": 98,
  "audioSuitability": 62,
  "visualDependency": 72,
  "cognitiveDensity": 38,
  "estimatedVisualReviewPercentage": 35,
  "estimatedListeningMinutes": 1,
  "reason": "The causal outcome is encoded in the inspected arrow order, while the surrounding prose is linear and brief.",
  "briefing": {
    "summary": "Track when acknowledgement occurs relative to durable storage.",
    "focus": ["Compare the event order rather than relying on the caption."]
  },
  "reviewSections": [
    {
      "heading": "ordering.svg",
      "reason": "A shows acknowledgement before crash and storage with data loss; B stores before acknowledgement and retains data after the crash."
    }
  ]
}
```

Visual evidence: `ordering.png`, rendered locally from the supplied SVG with network disabled and inspected. The direct SVG image viewer failed as unsupported; that failed probe is preserved in the tool trace before the browser fallback.
