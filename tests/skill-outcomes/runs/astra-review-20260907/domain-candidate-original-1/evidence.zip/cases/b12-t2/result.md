# B12 T2 result

Alpha resumed from verified `raw-ready` bytes to one `source-ready` note without relocating again. Beta was processed independently despite the existing `raw/course/` directory. Exactly one source note exists per item.
