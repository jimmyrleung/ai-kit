# Terraform fixture overview

## On-ramp

The single Terraform root declares two root `null_resource` instances in separate provider configurations and calls four child modules. One local child is readable and adds a third `null_resource`. Two Git subdirectories share one package repository and ref but their bodies are unavailable. One registry module is available only as a source declaration, so it contributes no invented resource rows.

Component roles: the root evaluates the environment-specific name and owns two independent trigger records; `local_leaf` receives that name through its parent argument and owns one trigger record. The other module roles are unknown without their bodies.

## Summary

| Field | Value |
| --- | --- |
| Created | 2026-09-07 |
| Last Updated | 2026-09-07 |
| Generated From | `43f3cc7` |
| Schema | v4 |
| Scope | overview |
| Source Root | `/tmp/astra-backlog-5VdqNm/trials/domain/candidate/1/cases/documentation-t1/source` |
| Docs Root | `/tmp/astra-backlog-5VdqNm/trials/domain/candidate/1/cases/documentation-t1/docs` |

## Source Evidence

| Source ID | Source/package and subdirectory | Full revision | Trace boundary | Dirty paths | Manifest SHA-256 | State |
| --- | --- | --- | --- | --- | --- | --- |
| `fixture-root` | local root | `43f3cc769f7e706f22e3497d5066413ebc17f85d` | all `.tf`, `.tfvars`, provider/backend/module declarations | none | `95ae93e99d0ab33b523ef79e534b29f7f415827e37903bf6ad08667833c458c3` | readable |
| `platform-network` | `https://example.invalid/platform-modules.git//modules/network` | ref `v1.2.3`; content revision unavailable | module source body | unavailable | unavailable | Unverifiable |
| `platform-logs` | `https://example.invalid/platform-modules.git//modules/logs` | ref `v1.2.3`; content revision unavailable | module source body | unavailable | unavailable | Unverifiable |
| `registry-consul` | `hashicorp/consul/aws` | version `0.11.0`; body unavailable | semantics only | unavailable | unavailable | Unverifiable |

## Q1 — Declared topology

| Root | Environments | Dependency order | Backend | Evidence |
| --- | --- | --- | --- | --- |
| `.` | `production` (`environment=prod`, `region=south`) | one root; no cross-root edge | local backend | no backend block in `main.tf`; `orchestration/unrelated-stack.yaml` targets `../some-other-root` and does not map this root |

Counts: 1 root, 1 environment, 4 child module addresses/subdirectories, 2 remote package repositories, 2 remote source@version pairs, and 4 readable Terraform files. The platform package contributes two subdirectories but only one package repository and one shared source@version pair; the local leaf has no invented version.

## Module resolution

| Module | Package/subdirectory | Version/ref | Resolution |
| --- | --- | --- | --- |
| `local_leaf` | `./modules/local-leaf` | local; no version | source-resolved |
| `network` | `platform-modules.git//modules/network` | `v1.2.3` | unresolved-pending-user |
| `logs` | `platform-modules.git//modules/logs` | `v1.2.3` | unresolved-pending-user |
| `registry_semantics_only` | `hashicorp/consul/aws` | `0.11.0` | semantics-only; no inventory rows |

## Q3 — Outside Terraform summary

- The remote module bodies are `indeterminate`, confidence 100%: their source addresses are declared but the supplied snapshot contains no readable bodies.
- No external or cross-stack resource can be proven from the readable HCL.

## Source Files

| Source ID | Role | Path | SHA-256 |
| --- | --- | --- | --- |
| `fixture-root` | root declarations | `main.tf` | `f12825155f232a7764e246e2159925bd34a1ab714af6cb7694927433d64795c8` |
| `fixture-root` | local child resource | `modules/local-leaf/main.tf` | `14a6b5c6ecc53eac2470833123fd7dc22014d3109e99e2df353e24129b90f5fb` |
| `fixture-root` | local child input | `modules/local-leaf/variables.tf` | `74b3fe9a884cfe559ff3e1d2cfa639a8a672a1c9e4e4ea3cf68927d3b09193c7` |
| `fixture-root` | environment values | `production.auto.tfvars` | `452be631aaede015ccb7a3b3a5f25e4710e597ae89a984ed191891b6027e740e` |
| `fixture-orchestration` | negative backend control | `orchestration/unrelated-stack.yaml` | `b148fb2be0de1d3819d4b60258f3e078617ba2787f0a4655eda845acd24cc701` |

## Change Log

| Date | Change | Reason |
| --- | --- | --- |
| 2026-09-07 | Initial documentation pass | First v4 inventory |
