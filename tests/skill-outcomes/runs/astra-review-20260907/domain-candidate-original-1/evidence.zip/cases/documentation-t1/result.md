# Documentation T1 result

The actual v4 artifacts are `docs/overview.md` and `docs/root/production.md`. They resolve `environment=prod` from `production.auto.tfvars`, `region=south` from the root default, and child `var.name` only through the parent argument. Default local backend is recorded; the unrelated orchestration stack is explicit negative evidence.

The two root `null_resource` blocks remain separate producer rows because default and `null.secondary` provider configurations differ. The local leaf is source-resolved without an invented version. Network and logs are distinct subdirectories/source identities in one package/ref; registry semantics create no resource rows without body bytes. With no cloud CLI/state, Deployment and Effective are `unknown`.

`freshness/source/main.tf` is dirty at unchanged HEAD and changes `region`; the original v4 doc is Stale based on actual bytes. The supplied fixture contains no readable sibling module body, so the requested changed-readable-sibling probe is unavailable; the docs show each unreadable remote source as its own Unverifiable identity. No HCL source was changed during generation.
