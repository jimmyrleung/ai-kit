# Root / production

## Summary

| Field | Value |
| --- | --- |
| Created | 2026-09-07 |
| Last Updated | 2026-09-07 |
| Generated From | `43f3cc7` |
| Schema | v4 |
| Scope | `root/production` |
| Source Root | `/tmp/astra-backlog-5VdqNm/trials/domain/candidate/1/cases/documentation-t1/source` |
| Docs Root | `/tmp/astra-backlog-5VdqNm/trials/domain/candidate/1/cases/documentation-t1/docs` |

## Source Evidence

| Source ID | Source/package and subdirectory | Full revision | Trace boundary | Dirty paths | Manifest SHA-256 | State |
| --- | --- | --- | --- | --- | --- | --- |
| `fixture-root` | local root and `modules/local-leaf` | `43f3cc769f7e706f22e3497d5066413ebc17f85d` | `main.tf`, `production.auto.tfvars`, local child `.tf` | none | `95ae93e99d0ab33b523ef79e534b29f7f415827e37903bf6ad08667833c458c3` | readable |
| `platform-network` | `platform-modules.git//modules/network` | ref `v1.2.3`; content unavailable | module body | unavailable | unavailable | Unverifiable |
| `platform-logs` | `platform-modules.git//modules/logs` | ref `v1.2.3`; content unavailable | module body | unavailable | unavailable | Unverifiable |
| `registry-consul` | `hashicorp/consul/aws` | version `0.11.0`; content unavailable | semantics only | unavailable | unavailable | Unverifiable |

## Entrypoint and inputs

`production.auto.tfvars` wins over the root default for `environment`, so it resolves to `prod`; `region` retains the root default `south`. `local.name` is `widget-prod-south`. The child receives this value via `module.local_leaf.name`; the root tfvars value is not applied directly in the child scope.

## Module-provenance tree

```text
main.tf [entry] (fixture-root@43f3cc7)
├── null_resource.primary [entry]
├── null_resource.same_name_other_context [entry] (provider=null.secondary)
├── module.local_leaf [entry] source=./modules/local-leaf, local content identity
│   └── null_resource.leaf [local leaf]
├── module.network [entry] source=git::platform-modules.git//modules/network?ref=v1.2.3 (unresolved)
├── module.logs [entry] source=git::platform-modules.git//modules/logs?ref=v1.2.3 (unresolved)
└── module.registry_semantics_only [entry] source=hashicorp/consul/aws@0.11.0 (semantics-only)
```

## Declared resources

| Logical address | Origin | Provider context | Name/template | Resolution | Provider-level role | Source |
| --- | --- | --- | --- | --- | --- | --- |
| `null_resource.primary` | `[entry]` | default `null` | `local.name` → `widget-prod-south` | 100% | lifecycle placeholder with trigger state; provider semantics not re-fetched in this supplied-body-only trial | `main.tf:13` |
| `null_resource.same_name_other_context` | `[entry]` | `null.secondary` | `local.name` → `widget-prod-south` | 100% | lifecycle placeholder with trigger state; separate producer key because provider configuration differs | `main.tf:17` |
| `module.local_leaf.null_resource.leaf` | local leaf | default child `null` | `var.name` ← parent `local.name` → `widget-prod-south` | 100% | lifecycle placeholder with trigger state | `modules/local-leaf/main.tf:1` |

No resource rows are inferred from the unreadable Git or registry modules.

## Role in this architecture

```text
Provides: three readable null-resource trigger records carrying widget-prod-south.
Consumes: local_leaf consumes the root-computed name through the module argument (main.tf:24-27).
Blast radius: no functional downstream consumer is present in the supplied HCL, so impact is unknown.
Posture: production environment name from production.auto.tfvars:1; region south from main.tf:8.
```

## Integration & permissioning (incident-triage)

| link/grant | mechanism | identity | target | exact role/perm | Declared | Deployment | Effective | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| none observed | none | none | none | none | none | unknown | unknown | No authorization resources in readable HCL; `az`, `gcloud`, and `aws` executables absent |

## Q3 — External / cross-stack / indeterminate

| Item | Classification | Reason | Confidence | Evidence |
| --- | --- | --- | --- | --- |
| `module.network` | indeterminate | pinned Git subdirectory body unavailable; producer inventory impossible | 100% | `main.tf:29` |
| `module.logs` | indeterminate | pinned Git subdirectory body unavailable; producer inventory impossible | 100% | `main.tf:34` |
| `module.registry_semantics_only` | indeterminate | registry declaration gives semantics only; body not supplied | 100% | `main.tf:39` |

## Secrets

No secret-bearing keys or values appear in the readable fixture HCL.

## Live verification

Unavailable: no supported cloud CLI executable was present. Deployment and Effective remain `unknown`; this is not evidence of failure.

## Source Files

| Source ID | Role | Path | SHA-256 |
| --- | --- | --- | --- |
| `fixture-root` | root declarations | `main.tf` | `f12825155f232a7764e246e2159925bd34a1ab714af6cb7694927433d64795c8` |
| `fixture-root` | local child resource | `modules/local-leaf/main.tf` | `14a6b5c6ecc53eac2470833123fd7dc22014d3109e99e2df353e24129b90f5fb` |
| `fixture-root` | local child input | `modules/local-leaf/variables.tf` | `74b3fe9a884cfe559ff3e1d2cfa639a8a672a1c9e4e4ea3cf68927d3b09193c7` |
| `fixture-root` | environment values | `production.auto.tfvars` | `452be631aaede015ccb7a3b3a5f25e4710e597ae89a984ed191891b6027e740e` |

## Change Log

| Date | Change | Reason |
| --- | --- | --- |
| 2026-09-07 | Initial documentation pass | First v4 inventory |
