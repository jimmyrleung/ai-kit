# Mission: Retry-safe service operations

## Why
Learn to choose retry-safe operations in a small service.

## Success looks like
- Choose whether an operation may be retried safely.
- Explain when a stable idempotency key is needed.

## Constraints
- Five-minute lesson.
- No next-topic assumptions.

## Out of scope
- Distributed consensus and provider-specific implementations.
