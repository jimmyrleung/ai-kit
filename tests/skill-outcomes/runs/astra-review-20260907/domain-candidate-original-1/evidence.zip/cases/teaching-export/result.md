# Teaching export result

The default deliverable is the portable workspace bundle at `workspace/`: lesson HTML, `assets/course.css`, mission, resources, and the unpromoted glossary. Copy the whole directory because its lesson uses a relative shared asset.

The separately requested single-file export is `export/idempotency-offline.html`; all required CSS and JavaScript are inline, there are no runtime imports/fetches, and the only external URL is an optional citation. The relocation/render probe is recorded under `render/`.

`GLOSSARY.md` is discoverable from the loaded `GLOSSARY-FORMAT.md`, but it has no promoted entries because the learner has not demonstrated knowledge. Candidate definitions remain lesson material.

Invocation was explicit in the user prompt. The frozen skill's `disable-model-invocation: true` policy remains unchanged.
