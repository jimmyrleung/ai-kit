# Retry-safe operations Resources

## Knowledge

- [HTTP Semantics: Idempotent Methods — RFC 9110 §9.2.2](https://www.rfc-editor.org/rfc/rfc9110.html#section-9.2.2)
  Primary protocol definition. Use to distinguish an idempotent request method from an implementation that merely hopes retries are safe. Optional network link; the lesson works without opening it.

## Gaps

- No service-specific datastore or atomicity contract was supplied.
