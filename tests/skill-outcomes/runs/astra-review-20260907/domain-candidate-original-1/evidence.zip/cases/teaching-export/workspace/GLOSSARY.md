# Retry-safe operations Glossary

This glossary records only terms the learner has demonstrated they understand.

## Terms

No terms promoted yet. The lesson's candidate definitions remain teaching material until the learner demonstrates correct use.
