# Decision capture result

Created `decisions/0004-use-sqlite.md` as active and unreviewed. Its rationale is preserved verbatim as `human-supplied`; consequences are visibly `ai-drafted` and `«AI-reconstructed — verify/rewrite»`, so review ownership is not implied.

The existing ADR-0003 remains intact except for an appended `superseded_by: ADR-0004` relationship and `lifecycle: superseded`. Its creation date is missing, so its age is `unknown`; file metadata was not used to infer it.
