# ADR-0004: Use SQLite for the local catalog

<!-- decision-record:v1
schema_version: 1
record_id: ADR-0004
record_kind: decision
recorded_at: 2026-09-07T07:18:00-03:00
execution_id: fixture-feedback-t6-candidate-r1
producer: record-decision
recorder: record-decision
project: fixture-repository
source_record_ids: ADR-0003
evidence_identity: explicitly supplied synthetic user decision and rationale
validation: passed
created_at: 2026-09-07T07:18:00-03:00
provenance: fixture-feedback-t6-candidate-r1
lifecycle: active
review_state: unreviewed
rationale_state: human-supplied
consequences_state: ai-drafted
supersedes: ADR-0003
superseded_by: none
-->

> **review: UNREVIEWED** — verify or rewrite every section marked «AI-reconstructed» before changing its field state to `human-confirmed`.

## Context

The local catalog has one writer, must work offline, and should remain simple to deploy.

## Decision

Use SQLite for the local catalog.

## Alternatives considered

Not supplied. No rejected alternative is invented in this capture.

## Rationale

One writer, offline use, and simpler deployment.

Authorship: `human-supplied`.

## Consequences «AI-reconstructed — verify/rewrite»

The local catalog will be stored in a SQLite database. The application will carry SQLite's write-concurrency constraints and will need a migration and backup approach appropriate to a local file.

Authorship: `ai-drafted`; this section remains unreviewed.
