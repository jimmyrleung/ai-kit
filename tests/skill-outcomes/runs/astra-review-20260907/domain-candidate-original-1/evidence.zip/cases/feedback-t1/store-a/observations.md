### Observation 1: Gate retry exposed stale setup

- **schema_version:** 1
- **record_id:** obs-a
- **recorded_at:** 2026-09-05T10:00:00Z
- **execution_id:** run-1
- **producer:** verify-task
- **recorder:** close
- **project:** fixture-repo
- **skill_or_workflow:** verify-task
- **phase/area:** gate-1
- **outcome:** partial
- **evidence_kind:** lived
- **evidence_identity:** review-record-1
- **friction_observed:** Setup had to be corrected before the required suite ran. — tag: wrong_approach
- **would_have_helped:** A readiness probe.
- **principle:** Verify prerequisites before interpreting failures.

### Observation 2: Two gate failures shared one execution

- **schema_version:** 1
- **record_id:** obs-b
- **recorded_at:** 2026-09-05T10:01:00Z
- **execution_id:** run-1
- **producer:** verify-task
- **recorder:** close
- **project:** fixture-repo
- **skill_or_workflow:** verify-task
- **phase/area:** gate-3
- **outcome:** partial
- **evidence_kind:** lived
- **evidence_identity:** review-record-1
- **friction_observed:** A configured version differed from the required version. — tag: sdk_version_drift
- **would_have_helped:** An early version check.
- **principle:** One execution may yield several observations but remains one execution.

