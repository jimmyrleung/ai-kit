# Improve result — verify-task fitness

Replica deduplication used stable `record_id`: the two byte-identical stores contain four physical copies but two distinct observations (`obs-a`, `obs-b`). No invocation telemetry source is configured.

| skill_or_workflow | observations | observed outcomes | measured invocations | invocation coverage | flags |
| --- | ---: | --- | --- | --- | --- |
| verify-task | 2 | partial: 2 | unavailable | unavailable — no instrumented invocation source | Selective observation evidence only; no non-use, invocation count, failure rate, or retirement inference is supported. The two observations share `execution_id: run-1`, but that does not manufacture one measured invocation. |

No proposal is staged: each tag/area cluster occurs once, below the procedure's three-observation threshold.
