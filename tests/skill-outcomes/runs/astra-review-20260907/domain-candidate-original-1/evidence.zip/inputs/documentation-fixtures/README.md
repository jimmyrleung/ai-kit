# Documentation outcome fixtures

These anonymized fixtures exercise backlog B07–B11 and B26. Run the named skill from a
fresh context, compare its artifact to `expected.md`, and record deviations. These are
procedure/outcome fixtures; repository lint alone does not pass them.

## Trial W1 — roots, detector coverage, and exact output

Run `docs-tasks-creator` against each directory under `workflow/`, with a new temporary docs
root outside the source tree. Then execute one emitted task with `document-workflow`.

Pass when:

- Next root/src forms, sync/async/const exports, route-group removal, ASP.NET Web SDK,
  literal MapGroup composition, and Function/FunctionName are captured as `expected.md` says.
- every task carries Source root, Docs root, Workspace root, Reference, Resolved output, and
  Workflow ID; document-workflow writes exactly Resolved output and changes no source byte;
- every activated detector has a bounded coverage row; unsupported/dynamic forms are Partial,
  not silently absent or complete; and
- the generated workflow doc is schema v2 with Source Evidence and hashed Source Files.

Repeat once with Docs root inside Source root (co-located). Repeat on `workflow/` as a
multi-workspace source, selecting all three workspaces; each workspace gets its own Docs root.

## Trial W2 — freshness

Use W1's generated document in a disposable git copy. Check these states independently:

1. unchanged source → Current and the doc's bytes/dates do not change;
2. unrelated code outside the recorded boundary → Current;
3. relevant unstaged, staged, and untracked registration changes at unchanged HEAD → Stale;
4. entry move or changed route registration → Stale with scoped retrace;
5. unknown or non-ancestor recorded revision → Unverifiable;
6. a separately versioned/readable sibling source changes → Stale even if primary HEAD is
   unchanged; if unreadable → Unverifiable.

## Trial W3 — stable task refresh

Use `refresh/existing-docs-tasks.md` as the existing tasks doc and
`refresh/rescan-inventory.md` as the new scan. Pass when the result matches
`refresh/expected-reconciled.md`: exact IDs retain progress/numbers/notes/evidence, the earlier
addition gets a new monotonic number, retirement and possible rename remain reviewable, and
independent same-file flows stay separate. Repeating the identical refresh is a byte-for-byte
no-op.

## Trial T1 — Terraform semantics/evidence

Run `document-terraform` on `terraform/root`, with output outside the source root and no cloud
credentials. Pass when the result matches `terraform/expected.md`, changes no HCL, and uses
schema v4 Source Evidence. In a disposable git copy, dirty `main.tf`; freshness must not rely
on unchanged HEAD. Treat a changed readable sibling module as its own source identity.

