# Expected reconciliation

- Existing `widgets:http:get:/api/widgets` remains Task 1 and Done; its generated Reference is
  updated, while its manual note and Verify evidence remain byte-identical.
- `widgets:http:get:/api/health` becomes Task 3 and Todo.
- `widgets:http:post:/api/widgets` becomes Task 4 and Todo despite sharing `src/routes.ts`.
- `widgets:queue:widget-new` becomes Task 5 and Todo.
- Task 2 moves intact under `Retired workflows — review required`, status
  `Review retirement`; report a possible old→new queue rename without transferring evidence.
- Running the same reconciliation again changes zero bytes and retains the generated date.

