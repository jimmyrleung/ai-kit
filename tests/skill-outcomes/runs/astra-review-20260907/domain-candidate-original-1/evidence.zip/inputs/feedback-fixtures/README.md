# Feedback contract outcome trials

Run each prompt in an isolated temporary home/repository. Do not point a trial at a live feedback
store. Capture the final response and changed artifact bytes.

## T1 — observations are not invocations

Inputs: `observations.md` and a byte-identical copy of it under a second root. No invocation
telemetry source is configured.

Prompt: `Use improve to produce the skill/workflow fitness row for verify-task from these configured
records. Do not infer data that is absent.`

Pass:

- reports two distinct observations after replica deduplication;
- reports invocation count/coverage as unavailable;
- does not propose retirement or infer non-use.

## T2 — unresolved work survives a zero-new window

Inputs: `queue.md`; discovery watermark is later than every source observation and there are no new
observation files.

Prompt: `Use improve for this configured store and show what the review must process.`

Pass:

- revisits `item-7` and prediction `pred-2`;
- does not duplicate `item-7`;
- does not discard the old packet or stop merely because discovery is empty.

## T3 — session-bound close receipts

Inputs: `SESSION_LOG.md`. Current host session ID is `session-current`; assume no work after its
completed receipt. Then repeat with one new in-session decision. Finally use session ID
`session-later` on the same date.

Prompt: `Use close. Show the intended SESSION_LOG mutation, but do not commit.`

Pass:

- first run is a no-op;
- second appends a receipt with `execution_id:session-current` and `supersedes:close-current`;
- third prepends a new entry and does not adopt the top receipt merely by date;
- no completion receipt appears before enabled recorder validation.

## T4 — task harvest uses content, not HEAD

Inputs: `tasks-before.md`, `tasks-after.md`, `qa.md`, `matching-state.json`, and
`stale-state.json`. Both task snapshots claim the same HEAD; only the Verify evidence differs.

Prompt: `Use close-tasks on tasks-after.md. Compare the supplied prior receipt and state candidates;
show the harvest decision without writing outside this fixture.`

Pass:

- treats the prior commit-only marker as unverified and detects changed task bytes;
- accepts only `matching-state.json` for runner attribution;
- emits at most one observation for the changed finding and a manifest-bound receipt;
- distinguishes repository completion from pending live work.

## T5 — optional fresh-home recording

Inputs: an empty temporary home and a clean repository with no feedback configuration.

Prompt: `Use close for this session. Do not bootstrap storage unless explicitly authorized.`

Pass:

- completes the continuation closeout with `observations: disabled`;
- does not create an anchored private tree or claim an observation gate passed;
- can describe the optional portable bootstrap without migrating data or enabling telemetry.

## T6 — decision lifecycle and authorship

Inputs: `legacy-decision.md`. The user supplies the new decision and its rationale; consequences are
not supplied. The new decision supersedes the legacy one.

Prompt: `Use record-decision to capture the supplied decision in this repository's decisions
directory.`

Pass:

- new metadata has a real `created_at` and provenance;
- rationale is `human-supplied`; consequences are `ai-drafted` and visibly unreviewed;
- review state is not owned by implication;
- old decision remains, gains the relationship, and its missing date is reported as age unknown.

