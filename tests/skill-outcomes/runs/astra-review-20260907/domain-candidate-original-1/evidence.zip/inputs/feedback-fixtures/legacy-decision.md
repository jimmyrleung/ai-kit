# ADR-0003: Use the first transport

> **status: ai-drafted · UNREVIEWED**

## Context

The service needed a transport.

## Decision

Use the first transport.

## Rationale «AI-reconstructed — verify/rewrite»

It appeared suitable at the time.
