import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const here = path.dirname(new URL(import.meta.url).pathname);
const read = (name) => fs.readFileSync(path.join(here, name), "utf8");
const assert = (condition, message) => {
  if (!condition) throw new Error(message);
};

const observations = read("observations.md");
const ids = [...observations.matchAll(/^- \*\*record_id:\*\* (\S+)$/gm)].map((m) => m[1]);
assert(ids.length === 2, "fixture must contain two observation records");
assert(new Set([...ids, ...ids]).size === 2, "replica dedupe must use stable record IDs");

const stripEvidence = (text) => text
  .replace(/^<!-- close-tasks:.*-->\r?\n?/gm, "")
  .replace(/<!-- evidence:begin ([^ ]+) -->[\s\S]*?<!-- evidence:end \1 -->\r?\n?/g, "");
const digest = (text) => crypto.createHash("sha256").update(stripEvidence(text)).digest("hex");
assert(digest(read("tasks-before.md")) !== digest(read("tasks-after.md")),
  "changed task evidence at unchanged legacy marker must change content identity");

const matching = JSON.parse(read("matching-state.json"));
const stale = JSON.parse(read("stale-state.json"));
const target = path.join(here, "tasks-after.md");
assert(path.resolve(matching.tasksPath) === path.resolve(target), "matching state path must bind target");
assert(path.resolve(stale.tasksPath) !== path.resolve(target), "stale state must not bind target");

const queue = read("queue.md");
assert(/item_id: item-7[\s\S]*?disposition: deferred/.test(queue), "deferred item must remain open");
assert(/prediction_id: pred-2[\s\S]*?prediction_state: no-evidence/.test(queue),
  "open prediction must survive a zero-new window");

const log = read("SESSION_LOG.md");
assert((log.match(/execution_id:session-current/g) ?? []).length === 1,
  "current session fixture must have one completed receipt");
assert(log.includes("execution_id:session-old"), "earlier boundary must remain distinct");

process.stdout.write("feedback fixtures: pass\n");
