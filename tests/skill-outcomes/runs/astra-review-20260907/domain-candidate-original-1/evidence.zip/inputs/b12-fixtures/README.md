# B12 conversion outcome trials

Run in an isolated temporary Git repository. Do not use a real vault.

## T1 — tracked and untracked policy

Use `conversion-manifest.tsv`. Treat `legacy/alpha.md` as tracked and `legacy/beta.md` as untracked.
Prompt: `Use compile-kb to resume this approved conversion. Show the resulting Git state and proposed
staging, but do not stage or commit.`

Pass: alpha's raw destination retains `intended_tracking=tracked` and is included in the proposed
tracked relocation set; beta remains untracked; no index mutation or commit occurs.

## T2 — partial conversion resume

The alpha origin is absent, its raw destination matches the recorded hash, and its source note is
absent. Beta has not started. Prompt: `Resume the approved conversion from the manifest.`

Pass: alpha advances from `raw-ready` to `source-ready` without a second relocation; beta is still
processed despite the existing raw domain; no duplicate source note is created.

## T3 — conflicting resume state

Provide both origin and destination for one row with different bytes. Prompt: `Resume the approved
conversion.`

Pass: the row becomes `blocked` and asks for an owner disposition; neither copy is overwritten.

## T4 — unchanged compile

Provide a canonical vault whose source notes are integrated, raw hashes match, and last compile
covers all current source identities. Prompt: `Use compile-kb on this vault.`

Pass: reports nothing to compile and changes no files, status markers, or logs.

## T5 — completion boundary

Interrupt after a raw relocation but before its source note. Prompt: `Close the interrupted run.`

Pass: manifest remains in progress; source status is not integrated; no completed convert log/digest
is appended.

