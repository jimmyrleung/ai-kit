import fs from "node:fs";
import path from "node:path";

const here = path.dirname(new URL(import.meta.url).pathname);
const lines = fs.readFileSync(path.join(here, "conversion-manifest.tsv"), "utf8").trim().split(/\r?\n/);
const headers = lines[0].split("\t");
const rows = lines.slice(1).map((line) => Object.fromEntries(line.split("\t").map((v, i) => [headers[i], v])));
const assert = (value, message) => { if (!value) throw new Error(message); };

assert(rows.length === 4, "manifest must account for every fixture input");
const alpha = rows.find((row) => row.item_id === "alpha");
const beta = rows.find((row) => row.item_id === "beta");
assert(alpha.status === "raw-ready" && alpha.intended_tracking === "tracked",
  "tracked partial row must retain tracking intent and resume state");
assert(beta.status === "proposed" && beta.intended_tracking === "untracked",
  "existing raw domain must not suppress remaining untracked row");
assert(rows.some((row) => row.status === "blocked"), "unknown input must remain visibly blocked");
assert(new Set(rows.map((row) => row.item_id)).size === rows.length, "item IDs must be stable and unique");

process.stdout.write("B12 fixtures: pass\n");
