# Setup commands

All setup targets were under this trial root. Scratch repositories used `git init`, local fixture identity, explicit `git add` of fixture baselines, and `git commit -m fixture-base`; no ai-kit index or commit mutation occurred.

Key setup operations:

```text
cp -a inputs/documentation-fixtures/workflow/. cases/documentation-w1/{separate,colocated,multi}/source/
git init <each disposable source>; git add .; git commit -m fixture-base
cp fixture source/docs into independent documentation-W2 state directories; initialize and baseline-commit each source
copy feedback fixtures into feedback-T1..T6; adjust matching-state.json tasksPath to the canonical trial copy
materialize exact B12 bytes under cases/b12-resolved-base/bytes; sha256sum each; preserve placeholder and resolved manifests
initialize B12 scratch repositories; baseline-track only alpha and manifest where the recipe requires tracking intent
copy the canonical no-op vault into cases/clean-no-op/vault
copy export/idempotency-offline.html to relocated/idempotency-offline.html
```

The original B12 manifest placeholders were replaced only in the separately preserved resolved fixture. Exact resolved identities and bytes are in `cases/b12-resolved-base/`.
