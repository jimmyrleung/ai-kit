# Available tool trace

The host does not expose a downloadable native tool trace, so this records the available commands, outputs, and preserved failures. The conversation tool log remains the exact native trace.

- Read frozen supplied bodies/references with `cat`/`sed`; hashes and sizes are in `source-manifest.json`. No installed/live skill was opened.
- Used `git init`, `git status --short`, `git rev-parse HEAD`, `sha256sum`, `find`, `rg`, and bounded Node hash scripts for setup and verification.
- Terraform cloud probes: `command -v az`, `gcloud`, and `aws` each exited 1 with empty output; live axes stayed unknown.
- Ownership checker output for B12-T4 and clean-no-op: `{"raw":1,"claimed":1,"unclaimed":[],"exhaust":[],"unresolved":[]}`.
- Teaching render: Playwright from `/tmp/astra-backlog-5VdqNm/browser-probe/node_modules/playwright`, Chromium `/usr/bin/chromium`, `--disable-network`; relocated `file://` export; zero HTTP requests; three quiz buttons; second click returned `Correct — the same key lets the service return the recorded result.` Screenshot `cases/teaching-export/render/desktop.png` was inspected with the image viewer.
- Learning visual: direct SVG image-viewer probe failed as unsupported. Chromium rendered it to `ordering.png`; the image viewer then confirmed A says acknowledgement→crash→store/data lost and B says store→acknowledgement→crash/data retained.
- Feedback-T4 subject digest after excluding the legacy marker and exact evidence region: `58e5f321df4fa46c4dde3c0963c1a9fe13ba1b9964d3e9d384c88bb093f2a29f`; matching state bound true, stale state bound false.
- Artifact manifest: 260 files, 31,416 manifest bytes, SHA-256 `767be209f9c12a90602abaa1e721e03980efa23ae46d0857be8a40becb8bfffd`.

Preserved setup/tool failures (no outcome was rerun until green):

1. A B12 setup shell variable was declared as a literal string, causing copy/commit/move failures. No outcome action had run. The same empty scratch dirs were populated with explicit absolute paths; the first procedure trial then ran once.
2. The supplied feedback fixture checker was invoked from its original copied input directory after the trial state path was adjusted elsewhere; it failed its path-binding assertion. It was not rerun as an outcome. The bound trial paths were later checked directly (`matching=true`, `stale=false`).
3. The first clean-no-op checker command specified a workdir before its copy existed and failed to spawn. The directory was then created; the actual procedure checker ran once.
4. Direct SVG viewing was unsupported; the authorized standalone Chromium fallback produced a PNG that was inspected.
5. A final fresh-home verification used `home` from the cases parent and failed because that relative path was one level too high. It was rerun from `cases/feedback-t5`; empty output confirmed the fixture home stayed empty.

Unnecessary user interruptions: 0. Required blocking fixture gaps: 1 (feedback T3-B missing decision content). Outcome reruns: 0.
