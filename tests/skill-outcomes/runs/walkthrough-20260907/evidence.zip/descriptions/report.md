# WB02 description draft — 2026-09-07

Drafted concise candidates for 30 of 31 canonical skills; retained teach because its 61-character description is already concise and its explicit-invocation metadata controls selection. All canonical descriptions and every proposed skill body were inspected. No repository files were modified during the draft phase.

## Inputs and ownership

- Read the authorized walkthrough backlog, skill-authoring rules, maintained skill policy, and write-skills guidance. Canonical directory entries were enumerated with fs.readdirSync, using readable SKILL.md files and realpath for supported links; the observed linked-entry count is recorded below.
- The parent owns repository application and independent review. Proposals bind to the exact original description string and SHA-256; body-only changes by other workers do not authorize replacing their content.
- Apply only the description scalar after verifying old_description_sha256. Preserve every other frontmatter field and all body/reference content. teach’s disable-model-invocation and argument-hint remain unchanged. docs-tasks-creator, document-terraform, and compile-kb retain their arguments metadata.
- Procedural details displaced from descriptions already have body homes; each proposal records those details. No new body addition is required by these drafts. Historical retired-workflow/name explanations are intentionally absent from candidate discovery text.

## Measurements

Provenance: draft.cjs enumerated 31 skill directories (0 supported linked entries observed) and parsed each frontmatter with js-yaml at 2026-09-07T15:00:11.820Z. It separately parsed the parent-provided baseline copy. Counts use JavaScript string length, not tokens. Frontmatter includes delimiters and the trailing newline; body excludes that envelope.

| Measure | Baseline | Current read | Candidate | Candidate vs baseline |
|---|---:|---:|---:|---:|
| Description characters | 16694 | 16694 | 10733 | -35.71% |
| Complete frontmatter characters | 18232 | 18232 | 12287 | -32.61% |
| Body characters, excluding frontmatter | 401717 | 400327 | 400327 | -0.35% |

The largest candidate description is 440 characters. No arbitrary reduction target was applied. The improve candidate grows from 272 to 300 characters to add natural friction-review triggers and the audit-skills distinction. Body differences reflect concurrent parent-owned work; this worker changed none. Reference sizes are outside this measurement and must be reported separately by the parent. These figures establish catalog text size only, not lower effective runtime context or cost savings.

## Per-skill disposition

| Skill | Before | Candidate | Rationale |
|---|---:|---:|---|
| analyze-work | 531 | 367 | Compresses mode detail while preserving defined-change, greenfield, and design boundaries. |
| audit-skills | 550 | 316 | Replaces the checklist inventory with recognizable quality categories and explicit audit/lint triggers. |
| breakout-session | 572 | 344 | Keeps retrieval-practice triggers and the reversed teacher/student roles; timeboxing is procedure. |
| bug-investigation | 583 | 366 | Retains failure and incident signals while distinguishing diagnosis from applying a fix. |
| close | 356 | 284 | Drops configured private-store history and adds the session-versus-run distinction already taught in the body. |
| close-tasks | 345 | 302 | Preserves artifact reconstruction and duplicate-close boundary; receipt plumbing is body detail. |
| compile-kb | 714 | 385 | Keeps all domain and conversion triggers, ownership exclusion, and ingestion/query boundaries; drops implementation-head terminology. |
| docs-tasks-creator | 598 | 440 | Keeps framework-specific discoverability and inventory outputs while moving handoff mechanics to the body. |
| document-terraform | 633 | 366 | Keeps Terraform-specific unit of work and evidence-axis boundary; replaces detailed provenance syntax with a recognizable outcome. |
| document-workflow | 655 | 409 | Preserves named inputs, single-operation scope, opt-in full-stack mode, and neighboring documentation boundaries. |
| find-skills | 365 | 325 | Keeps explicit discovery intent and installation scope; source/compatibility vetting is procedure. |
| implement-task | 752 | 371 | Preserves every named target form and reviewed-fix boundary while moving workflow steps to the body. |
| improve | 272 | 300 | Adds natural recurring-friction triggers and the structural-audit boundary while keeping suggestion-only purpose. |
| lay-of-the-land | 604 | 333 | Drops retired-name history and workflow-chain detail; restores natural reconnaissance triggers. |
| onboard-me | 595 | 365 | Keeps the unfamiliar-code and conversational teaching boundary; removes recording mechanics from discovery text. |
| orchestrate | 438 | 342 | Keeps multi-agent triggers and prior failure symptoms; dispatch/persistence internals belong in the body. |
| post-mortem | 558 | 363 | Retains resolved-incident timing and all common retrospective triggers without carrying the workflow chain. |
| qa-gates | 555 | 386 | Keeps the five gate categories and prefix-versus-task-versus-code-review distinctions; skips procedural pass-line detail. |
| record-decision | 396 | 290 | Keeps decision capture, no-duplicate-home boundary, and authorship distinction; lifecycle mechanics stay in the body. |
| review-artifact | 707 | 380 | Retains all four named document types and the before-next-phase boundary; removes fan-out and record-format plumbing. |
| review-implementation | 661 | 346 | Keeps prefix/batch/mid-run timing and all relevant neighboring review boundaries; drops retired workflow history. |
| tasks-breakdown | 664 | 366 | Keeps decomposition inputs, modes, filename, and deliberate spec-carrying boundary; sizing exploration is body detail. |
| teach | 61 | 61 | Retained: already concise; explicit invocation is controlled by provider metadata, which remains unchanged. |
| techspec | 575 | 397 | Keeps design-phase triggers, work types, input types, and downstream distinction while shortening the section list. |
| triage | 654 | 404 | Keeps routing purpose, recurrence, current-intent state, and recommendation-only authorization boundary; avoids duplicating the chain. |
| triage-learning-content | 559 | 357 | Preserves machine mode names, structured-output use, input types, and summary/TTS-generation exclusions. |
| update-workflow-docs | 595 | 373 | Keeps freshness maintenance and scope forms; moves hashing, classification, and preservation implementation to the body. |
| verify-task | 639 | 376 | Keeps narrow verification inputs and per-task gate boundary; removes nested-record and feedback plumbing. |
| walkthrough | 400 | 355 | Keeps one-item decision cadence and list input while distinguishing implementation tours. |
| walkthrough-implementation | 560 | 365 | Preserves owned-work/requested-tour boundary and reflects the body’s already-committed-but-unshipped case. |
| write-skills | 547 | 299 | Keeps authoring and trigger-repair phrases; moves process inventory and house-style history to the body. |

## Selection-boundary checks prepared

routing-cases.json contains 100 realistic independent requests. The separate routing-expected.json contains the expected answers, reasons, and subject-skill coverage. Every changed skill has a positive, near-neighbor, and distractor case. Extra cases cover tasks-doc-less reviewed fixes, investigation review, committed-but-unshipped owned work, populated-vault conversion, Hermes exclusion, full-stack documentation, deliberate spec-carrying tasks, greenfield analysis, and explicit-only teach.

- Give fresh reviewers only one competing catalog and routing-cases.json; never the answer key, this report, proposals, or source bodies. catalog-baseline.json and catalog-candidate.json carry comparable name/description rosters and explicit-only metadata.
- Preserve each trial’s effective host/model/settings, raw answers, and exact catalog/fixture bytes. Grade after answers return. Alternate selections and ambiguous cases need human adjudication; do not silently rewrite the expected key to improve results.
- This is a description-roster simulation. It is not native discovery, body execution, a calibrated success rate, or evidence that another provider exposes the same catalog.

## Identity changes and remaining work

26 current skill files differ from the baseline by whole-file SHA-256 at proposal capture; zero descriptions differ from baseline. measurements.json lists each changed file and its baseline/current identities. That is expected parent-owned body/reference work. Further changes between capture and this report: none observed. Original-description hash matching remains the application gate.

- Parent: independently review candidate wording, apply scalar-only edits, remeasure final body/reference sizes, run final strict metadata/portability and repository checks, then run fresh routing reviewers and record actual results.
- This worker ran YAML round-trip checks on every proposed envelope, retained metadata in proposals/catalogs, checked fixture IDs/key completeness, and verified positive/neighbor/distractor coverage for every changed skill. No native discovery, model routing trial, build/test suite, or shipping portability command was run by this worker.

## Approved application — 2026-09-07T15:02:42.842Z

The parent independently reviewed all candidate descriptions and authorized scalar-only application plus the neutral find-skills checksum refresh. Applied 30 description changes across 31 enumerated skills; teach remains byte-for-byte unchanged. Every target was synchronously full-read immediately before its guarded edit. The original description SHA-256 matched for every target; all non-description bytes, parsed metadata, and body hashes were preserved across each write. This retains concurrent confidence/body changes.

- Final applied description characters: 16694 → 10733.
- Final applied complete-frontmatter characters: 18232 → 12287.
- Body characters at application: 406542, unchanged by this pass; the difference from draft capture reflects concurrent authorized work.
- Checker change: only FIND_SKILLS_SHA256, 3ee292cb91829547beb2ab8834f5f6bba7002beebc28c44d633edaf297034591 → de0e3cc9f7bd63d0d6f97d0f27d0bcc6318330c8124987c680980bf2cb75ef15. The entire checker was inspected before editing; all other bytes were verified unchanged.
- Exact per-file before/after, body, and non-description SHA-256 records: application-evidence.json.
- Reproducible application implementation: apply-approved.cjs (one-shot, guarded against repeat application).
- No reference generation, commits, or other repository changes were performed. Shipping tests and portability checks remain with the parent; per-edit YAML round-trip and preservation checks passed here.

## Confidence & unverified

Confidence: 97% in these reviewable wording proposals. Heuristic calculation: documentation clarity 98×0.30 + neighboring-pattern fit 97×0.25 + input/dependency understanding 96×0.20 + change simplicity 99×0.15 + impact confidence 92×0.10 = 96.9%, rounded to 97%. Source bodies and current metadata ground the drafts; the proposed changes affect description scalars only.

3% uncertainty: no fresh routing trial has run, and host-native discovery may shorten/filter this catalog differently. Those checks remain necessary before claiming preserved selection behavior. Body/reference edits are concurrent; the parent must verify the final tree. This score is not a measured probability of correct routing and does not waive any acceptance check.
