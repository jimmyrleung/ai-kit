# WB03 confidence guidance — proposed integration packet

The draft restores explicit portable arithmetic, reporting and advancement rules while
retaining the current evidence and authorization safeguards. It is a proposal in scratch
storage; this worker changed no repository file and ran no agent behavior trial.

## Deliverables and exact scope

- Contract source candidate: `<run>/confidence/confidence.md`.
  Intended maintained destination: `docs/contracts/confidence.md`; each affected skill's
  generated destination: `references/shared/confidence.md`, as selected by the parent.
- Narrow body edits: `<run>/confidence/changes.json`.
  The generator's executed result counted **31 exact replacements across 9 consumers**.
  Each replacement carries original full-file SHA-256, original line, exact old/new text,
  and purpose. Frontmatter and path-resolution boilerplate are outside this proposal.
- Preview copies: `<run>/confidence/proposed-skills/<name>/SKILL.md`.
  These are confidence-only previews over the captured baseline, **not files to copy over
  the repository**, because that would overwrite the parent's packaging/description edits.
- Scenarios and expected assertions: `<run>/confidence/scenarios.json`.
- Read provenance and byte identities: `<run>/confidence/read-manifest.json`.
- Last integration drift probe: `<run>/confidence/drift-check.json`.
- Reproducible proposal generation: `<run>/confidence/prepare.py`.

The exact consumer list, enumerated from the generated replacement file, is:

| Consumer | Proposed behavior change |
|---|---|
| analyze-work | Restore analysis 40/40/20 rubric; replace undefined loaded format; distinguish partial mapping from advancement. |
| techspec | Restore design 30/25/20/15/10 rubric and explicit gate/report; retain causal policy and owner boundaries. |
| tasks-breakdown | Supply decomposition 35/25/25/15 rubric; tie gaps to affected task starts and checks. |
| implement-task | Resolve and assess readiness before a dependent edit; refresh at verification; pass the actual full policy. |
| verify-task | Define standalone defaults and receive/reassess full policy; pass full policy plus numeric compatibility threshold. |
| qa-gates | Replace score-as-pass wording; resolve explicit policy and assess confidence separately from actual gate results. |
| review-artifact | Use producing artifact rubric; give workers complete policy; prevent below-threshold Approved verdicts. |
| review-implementation | Require scoped worker assessments and full policy; record post-review confidence/advancement without score averaging. |
| bug-investigation | Restore diagnosis 40/30/15/15 rubric; keep inherited active-P1 policy; replace surviving consensus-weighting language. |

This proposal excludes other skills and existing shared contracts from confidence-specific
edits. `authorized-work.md` says confidence reporting is requested-dependent; each
mandatory consumer hook now explicitly requests it. Linking confidence from that general
contract would force unrelated consumers to load this stage-specific policy, so the draft
uses direct required hooks instead. Parent packaging owns other shared-link changes.

## Grounding and preserved rationale

All named current skill files, the complete walkthrough backlog and all current shared
contracts were read. Immediately before proposal generation, an executed byte comparison
confirmed each skill matched the captured baseline. Full baseline hashes and line counts
are in `read-manifest.json`. Historical `aeec06b` files were retrieved into scratch; only
their confidence/gate excerpts and surrounding context were read, not entire historical files.

| Inspected source / original lines | Finding and retained or changed rationale |
|---|---|
| aeec06b analyze-work:144–157 | Explicit 40/40/20 factors and normal 90 gate are useful and restored. Its generic pre-write confirmation and blanket questioning stop are not restored: current authorization permits useful partial drafts and independent checks. |
| aeec06b techspec:134–148 | Explicit 30/25/20/15/10 factors are restored. “Ship-ready” from 95 and routine confirm-before-draft are not restored; numerical support cannot imply executed tests, review or owner GO. |
| aeec06b tasks-breakdown:86 | “Loaded confidence factor breakdown” never supplied portable weights. A decomposition-specific rubric is now explicit, grounded in current requirement/dependency/test-ownership obligations. |
| aeec06b bug-investigation:44,60 | Preserve streamlined P1 urgency and diagnosis 40/30/15/15 weights. Historical local normal 90 gate could shadow the incident 70 rule; one inherited effective policy prevents that. |
| aeec06b qa-gates:27; baseline qa-gates:42 | “Min confidence to count as pass without review” is ambiguous and insufficient. Replace it with an effective minimum that cannot substitute for the gate's actual evidence/result. |
| baseline analyze-work:157–163; techspec:151–158; tasks-breakdown:105 | Preserve explicit evidence-dependent blocking, stricter user gates and useful authorized drafting. The gap was absent arithmetic/default output, not a reason to reintroduce approval friction. |
| baseline bug-investigation:52–59 and process steps 3–7 | Preserve SOURCE/OBSERVED/INFERRED, causal linkage, falsifier/next probe, mitigation distinction, active-P1 threshold 70, stricter policy and remediation permission. |
| baseline review-artifact:116 onward | Preserve content-bound review and evidence gate. A high number or heading alone does not authorize reuse. |
| baseline change-evidence.md and authorized-work.md | Preserve current scoped byte identity, executed-check reuse, BLOCKED/FAIL distinction, actual accepted limitations, lifecycle boundaries and existing authorization. |

The old analysis/design/diagnosis factor weights are preserved intentionally. Task decomposition
and delivery weights are new proposed heuristics matched to their current responsibilities,
not empirically established predictors. Explicit normalization, factor evidence and critical-gap
blocking make their interpretation reviewable. The report format avoids requiring private
instructions while preserving “Why N%” and “100−N% uncertainty”; the latter is explicitly
the score remainder, not an observed error probability.

The effective policy travels as `confidence_policy`; the existing `confidence_gate` name
remains a numeric compatibility minimum. Workers inherit the caller's rubric and full
policy. Downstream stages switch to their own rubric unless overridden but retain threshold,
causal requirements and authorization. Scores are reassessed, never copied or averaged.
Active-P1 depth/threshold persist while the incident is active; an explicit resolved-state
change restores normal defaults for new work. A stricter applicable 90/95/98 minimum still wins.

## Verification performed and integration caution

Executed local checks parsed both proposal JSON files, asserted each exact old anchor occurred
once in its baseline, applied all replacements in scratch, verified a mandatory local confidence
link in every proposed consumer, and verified the undefined “loaded confidence format” phrase
was absent from those previews. Arithmetic checks independently recomputed all **3** illustrative
factor calculations in `scenarios.json` and confirmed their contributions and rounded results.
These are structural/proposal checks, not repository QA or model outcome evidence.

The final drift probe found the parent's packaging edits had changed all **9** current skill
hashes; every one of the **31** old replacement anchors still occurred exactly once in the
current content. See `drift-check.json` for the current hashes. Apply narrow old/new replacements
only after checking each anchor again; do not assert a full-file baseline match or install the
preview copies wholesale. Subsequent edits can invalidate this probe.

The contract was reread after its final scratch amendment. At that check its SHA-256 was
`070c1dbdf7a17e4c7088c8783ab0da93e2cd88f7c1666f0a134e9264dd33460b`.

## Confidence & unverified

**Confidence score: 95%** in this proposal satisfying the authorized WB03 intent, based on
full current-source inspection and narrow, byte-keyed replacements.

| Factor | Weight | Rating | Contribution | Evidence / remaining gap |
|---|---:|---:|---:|---|
| Requirements/docs clarity | 30 | 100 | 30 | WB03 explicitly authorizes portable scores, factors, inheritance and evidence safeguards. |
| Inspected precedent patterns | 25 | 95 | 23.75 | Historical analysis/design/diagnosis rubrics verified; task/delivery weights are proposed. |
| Dependency/data-flow understanding | 20 | 95 | 19 | Every named core consumer read; parent packaging integration remains separate. |
| Complexity controlled | 15 | 90 | 13.5 | One maintained contract and exact replacements; full behavior trials pending. |
| Cross-system impact bounded | 10 | 90 | 9 | No repository or private writes; host/provider behavior remains untested. |

Calculation: 95.25 → 95%. **5% uncertainty:** no fresh-context task trial, native host trial,
repository validation or independent integration review was executed by this worker. The custom
decomposition/delivery weights are heuristic policy choices, not calibrated evidence. These
gaps block calling the integrated implementation verified; they do not block the parent's
authorized integration and tests. The next checks are the actual scenarios, stale-copy/isolated
packaging validation, final repository suite, independent review and final QA owned by the parent.

**Advancement:** ready for parent review and narrow integration within the already authorized
WB01/WB03 work. No commit, publish, deployment, owner GO, or passing model-trial claim is implied.


## Accepted integration — 2026-09-07T15:02:19.216735+00:00

The parent accepted the contract and all narrow replacements, then authorized repository integration. The earlier proposal-only status describes the initial delivery; this appended record describes the subsequent authorized edits.

Applied 31 exact replacements across 9 current skill files after full current-file reads. Created `docs/contracts/confidence.md` byte-identical to the accepted scratch contract. All old anchors matched uniquely, all existing Markdown references and frontmatter were preserved, and each resulting skill had zero `loaded confidence format` echoes. No generated files were written.

| Path | Replacements | Before SHA-256 | After SHA-256 |
|---|---:|---|---|
| skills/analyze-work/SKILL.md | 3 | bef5dedc5393d3a81038c935e6e0c94157ee05bd3fcc4b0ac9349332adf393aa | 993c7ec42dc59b387c388af4999944a9c5480f7c54fc79088109e890cfb5256e |
| skills/techspec/SKILL.md | 3 | d3d2f6011b5e0a6c3e0cfd3452ec1b6f00243fc34b9a189b8134f665b6ff5cf6 | b33e8ca86b74242d7f59a24175f3beaf26a9eb27f28056f272c9afeb0002080f |
| skills/tasks-breakdown/SKILL.md | 3 | a9a4af5d57d9e9f25a0fd71f6d01c6977c6c73bffb0276d3bd8a677beb378945 | ee0aa137b7cc587957f26690ed448d6f936a7d9d193856a45f35c3662e6617e4 |
| skills/implement-task/SKILL.md | 3 | 608a9b6657b8b0702a023e3656275bb4bc840a5447439e134445cb089121d8bc | cbf28a73c22e685d43df33c4fcfd97342db010dd4d861211b9d75b5562e1ddf1 |
| skills/verify-task/SKILL.md | 3 | d025749b4ee07310d650407b8086ee7f94b931a550bc9fd2532f9ac3a6aec003 | 4362d97fb48a77556337b362d9a03c8a74f99ba989ac928fe432495c7b3e7fa4 |
| skills/qa-gates/SKILL.md | 3 | e89b3fb15f839574c67b9e82d7bb9b6466cc240598f924f2eb824d9ab09eb4d8 | c9d406e3b9d6878220be2f2a750a3617940faf348a3947d148525acae82817af |
| skills/review-artifact/SKILL.md | 4 | 2d5929a77e13827731af84cdc6647c404c63445690141e3b54d04fc6b41cc131 | 77f1e46ef25c65e0f304c1c698f7bf0572fa7299607919e422e11b2a75201ada |
| skills/review-implementation/SKILL.md | 3 | a21c5ec8c22a755fb94678356951427ea64e65fd0845871f69041f9c337687ff | 1db47054fa848d342d4d30caba2b52a2eb50ee33e10211823cce9ac4ab027daa |
| skills/bug-investigation/SKILL.md | 6 | 5867a2eabe46fa1551a4713f16c742cc38e48579c4ae238faba0622ea7a00cda | f517f67310530e88b8c4c6f8db333701eb0acb9a221c2c21286a5992ad3d8b02 |
| docs/contracts/confidence.md | 0 | new | 070c1dbdf7a17e4c7088c8783ab0da93e2cd88f7c1666f0a134e9264dd33460b |

Exact before/after scope and reference inventories: `integration.json`. Confidence-only diff: `integration.diff`. Pre-edit bytes: `integration-before/`. Each written file was read back and compared with its computed intended result. Parent still owns generation, behavioral trials, repository validation and final QA; no PASS for those checks is claimed here.
