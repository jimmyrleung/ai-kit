Blocked by the fixture runtime: every local process launch fails with `Permission denied`, including `true` and `/bin/ls`. Therefore I could not inspect `procedure/SKILL.md`, source, or tests, and did not invent or write an ungrounded task document.

Output path: `<run>/native/tasks/negative_fee_tasks.md` — not created.