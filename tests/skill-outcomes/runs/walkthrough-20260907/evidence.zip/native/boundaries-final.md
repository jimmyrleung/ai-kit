Completed all three policy checks. JSON validation passed; fixture unit test passed 1/1. Confidence: 99%—only uncertainty is judgment-based ratings where none were prescribed.

[boundaries.json](<run>/native/boundaries/boundaries.json)