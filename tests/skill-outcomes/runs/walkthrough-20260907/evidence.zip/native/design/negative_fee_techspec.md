# Negative fee validation techspec

## Summary

Modify `calc.py` so `total_price` raises `ValueError` when `fee < 0`, before performing the existing addition. Extend `tests/test_calc.py` to cover negative integer and fractional fees while retaining explicit positive- and zero-fee regression coverage; the blast radius is one production file and one test file in a single module layer.

## Approach

Add one guard at the start of `total_price`, then leave `return price + fee` unchanged. This is the smallest production delta that implements the owner-approved rule and preserves current behavior for zero and positive fees. The existing public function name, parameters, arithmetic, standard-library-only setup, and `unittest` test home are reused.

No helper, new exception type, dependency, module, configuration switch, compatibility shim, or rollback tooling will be added. The exception message may be a short implementation-chosen description because `approved-plan.md → Owner-approved bounded plan` explicitly leaves its wording unlocked; tests must assert the exception type, not its text.

### Production delta and reuse decision

| Surface | Decision | Smallest required delta |
|---|---|---|
| `total_price` | Modify | Insert `if fee < 0: raise ValueError(...)` before the existing addition. |
| Existing addition | Reuse | Keep `return price + fee` as the zero/positive path. |
| Test structure | Reuse and extend | Add methods to the existing `PriceTests` class in `tests/test_calc.py`. |
| New mechanisms | Add none | The requirement is fully expressed by a local guard and existing exception type. |

## Scope

In scope:

- Reject every `fee` value for which Python evaluates `fee < 0` as true, using `ValueError` before addition.
- Preserve the existing result for zero and positive fees.
- Add negative integer, fractional negative boundary, zero, and positive scenarios to the existing unittest suite.
- Validate with `python -m unittest discover -s tests -v`.

Out of scope:

| Item | Why out of scope | Where to revisit |
|---|---|---|
| Validation of `price` | The approved plan constrains only negative `fee`. | A separate owner-approved requirement. |
| Type coercion or custom handling for non-comparable inputs | The plan does not change the function's existing Python operand semantics. | A future public API contract change. |
| Exception-message contract | The owner explicitly leaves wording to implementation. | Only if callers later depend on stable text. |
| Deployment or external checks | The authorized scope is repository-local documentation and the plan excludes deployment. | The consuming release process. |

## Patterns reused

| Pattern | Source | Usage here |
|---|---|---|
| Preserve direct arithmetic in the public helper | `calc.py → total_price` (≈:1) | Keep the current addition as the successful path after validation. |
| Keep behavioral tests in the existing stdlib suite | `tests/test_calc.py → PriceTests` (≈:4) | Add focused test methods to the same class and continue using `unittest` assertions. |
| Explicit positive and zero examples | `tests/test_calc.py → test_positive_fee / test_zero_fee` (≈:5, ≈:7) | Retain these regression cases rather than replacing them with only rejection tests. |
| Repository validation command | `README.md → Validation` (≈:3) and `approved-plan.md → Owner-approved bounded plan` (≈:3) | Run unittest discovery from the repository root. |

## Implementation map

### `calc.py` — Modify

Add the negative-fee guard directly inside `total_price`, before the current return statement, because the rejection must occur before addition and no reusable validation layer exists or is needed. Follow the direct-function pattern in §4.

Before:

```python
def total_price(price, fee):
    return price + fee
```

After shape:

```python
def total_price(price, fee):
    if fee < 0:
        raise ValueError("fee must not be negative")
    return price + fee
```

The exact message is not contractual. Do not catch comparison or addition errors: inputs outside the locked fee rule retain normal Python behavior.

### `tests/test_calc.py` — Modify

Extend the existing `PriceTests(unittest.TestCase)` class; this is the verified and owner-required test location. Keep the current positive and zero tests, and add:

```python
def test_negative_fee_is_rejected(self):
    with self.assertRaises(ValueError):
        total_price(10, -1)

def test_fractional_negative_fee_is_rejected(self):
    with self.assertRaises(ValueError):
        total_price(10, -0.01)
```

The existing `test_positive_fee` and `test_zero_fee` remain the preservation checks. Assertions intentionally do not bind the unlocked exception text.

## Test plan

The QA-scenario pass was performed as a separate main-thread pass because the owner explicitly disabled fan-out. Every committed behavior maps to a scenario below.

| # | Scenario | Inputs | Expected | Priority | Automatable |
|---|---|---|---|---|---|
| 1 | Negative integer fee is rejected before addition | `total_price(10, -1)` | Raises `ValueError`. | High | Yes |
| 2 | Fractional negative fee near zero is rejected | `total_price(10, -0.01)` | Raises `ValueError`. | High | Yes |
| 3 | Positive fee preserves addition | `total_price(10, 2)` | Returns `12`. | High | Yes |
| 4 | Zero fee remains accepted | `total_price(10, 0)` | Returns `10`. | High | Yes |

Run from the repository root:

```text
python -m unittest discover -s tests -v
```

Baseline evidence: this command passed before implementation with two tests (`test_positive_fee` and `test_zero_fee`). Post-change verification must pass all four scenarios. Integration, deployment, database, and UI tests are not needed because the change is confined to a dependency-free Python function with no external callers in the supplied workspace.

## Files changed summary

| Path | Change type | Purpose |
|---|---|---|
| `calc.py` | Modify | Reject negative fees before addition. |
| `tests/test_calc.py` | Modify | Add rejection coverage and retain zero/positive regression coverage. |

1 production file, 1 test file. No new files, dependencies, database migration, DI changes, configuration changes, or public API changes beyond the specified rejection.

## Rollback

Revert the guard in `calc.py` and the two negative-fee tests in `tests/test_calc.py`, then rerun the repository unittest command. No data or external-system rollback is required.

## Confidence score

**Confidence score: 98% —** the implementation blueprint is directly supported by the locked plan, the complete current function and test suite, repository documentation, call-site search, and a passing baseline test run.

**Effective policy:** `design` rubric from `procedure/references/shared/confidence.md`; normal advancement threshold 90%; required evidence is the approved requirement, inspected production/test patterns, dependency and caller closure, and relevant baseline checks. The authorization boundary permits this local specification only, not implementation, deployment, commits, or external work.

| Factor | Weight | Rating | Contribution | Evidence / gap |
|---|---:|---:|---:|---|
| API/docs and requirements clarity | 30% | 100 | 30.00 | `approved-plan.md → Owner-approved bounded plan` locks behavior, files, tests, and exclusions; `README.md → Price helper` agrees. |
| Suitable inspected patterns | 25% | 100 | 25.00 | Entire `calc.py` and `tests/test_calc.py` inspected; existing direct function and `PriceTests` are sufficient. |
| Data-flow/dependency understanding | 20% | 100 | 20.00 | Workspace search found the single definition and only supplied caller/import in `tests/test_calc.py`; Python stdlib only. |
| Complexity understood and controlled | 15% | 100 | 15.00 | One local guard plus two focused tests; production delta and excluded mechanisms are explicit. |
| Cross-system impact understood and bounded | 10% | 80 | 8.00 | Supplied repository states there are no external callers and excludes deployment; no external systems were checked by scope. |
| **Total** | **100%** |  | **98.00** | `round(98.00) = 98%`. |

**Why 98%:** all repository-local, load-bearing design facts were inspected, the exact validation command passed at baseline, and each committed behavior has an automated scenario in the verified test home.

**2% uncertainty:** external consumers and deployment environments were intentionally outside the supplied workspace and authorization. This does not block the repository-local implementation design because the owner explicitly states there are no external callers and excludes external checks; the next check, if that scope changes, is consumer compatibility validation by the release owner.

**Advancement:** proceed within the bounded repository implementation described here once implementation is separately authorized. This artifact does not authorize production/test edits, deployment, commits, or external checks.
