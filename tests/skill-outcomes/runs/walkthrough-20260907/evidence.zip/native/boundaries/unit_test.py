import unittest
class Fixture(unittest.TestCase):
    def test_observed_unit(self): self.assertEqual(2+2,4)
if __name__ == "__main__": unittest.main()
