Created [negative_fee_tasks.md](<run>/native/tasks/negative_fee_tasks.md).

Scoped conclusion: one atomic pre-merge task covers the validation and tests in spec-carrying mode. The existing baseline suite passes 2/2 tests. No production code was modified.