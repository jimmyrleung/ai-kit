# Negative-fee analysis

## Overview

This integration adds one behavior boundary to the existing public `total_price` helper: negative fees must raise `ValueError`, while zero and positive fees retain their current addition behavior. The approved plan defines the bounded scope and validation target, but this document does not adopt its implementation choices as a committed design.

## Confidence score

**Confidence score: 99% —** the negative-fee requirement and repository-local change surface are directly supported by the complete fixture, with only out-of-scope runtime/type semantics left unspecified.

**Effective policy:** `analysis` rubric; 90% advancement threshold; source: `procedure/references/shared/confidence.md`; required evidence is the supplied requirement, complete local source/test inspection, caller closure, and baseline test result. Authorization is limited to local inspection, existing test execution, and this analysis document; production edits, deployment, external checks, and design commitment are excluded.

| Factor | Weight | Rating | Contribution | Evidence / gap |
| --- | ---: | ---: | ---: | --- |
| Requirements clarity | 40% | 100 | 40.0 | `README.md:3` defines the exception type, preserved behavior, dependencies, test home, validation command, caller scope, and unlocked message wording. |
| Codebase-or-constraint understanding | 40% | 100 | 40.0 | Complete fixture inventory inspected; `calc.py:1-2`, `tests/test_calc.py:1-8`, and the repository-only baseline test run are direct evidence. |
| Change-path clarity at reference-map altitude | 20% | 95 | 19.0 | The production and test locations are unambiguous; broader input-type semantics are not defined and are not needed to locate the bounded work. |
| **Total** | **100%** |  | **99.0** | Rounded result: **99%**. |

**Why 99%:** all named files were inspected, caller closure was checked across the complete fixture, and the prescribed baseline validation passed both existing tests.

**1% uncertainty:** behavior for fee values outside the demonstrated numeric inputs is not specified. This does not block the scoped negative/zero/positive fee analysis; a later design or implementation step should avoid broadening input-type semantics unless the owner supplies another requirement.

**Advancement:** proceed within reference-map analysis only. A later design step has enough evidence for this bounded requirement, but no design or production change is authorized here.

## Entry points

- `calc.py:1-2` — public `total_price(price, fee)` function and the complete current production behavior.
- `tests/test_calc.py:2` — the sole repository consumer import found by whole-fixture search.
- `tests/test_calc.py:5-8` — current positive-fee and zero-fee behavior checks.
- `README.md:3` — authoritative requirement, constraints, intended test home, and validation command.

## Similar features / examples

- `tests/test_calc.py:5-8` is the only local behavior-test pattern. It uses Python `unittest`, direct helper calls, and exact outcome assertions.
- No existing local rejection/exception example exists in the supplied production or test files. This is a bounded absence: the full fixture file inventory and all source/test contents were inspected.

## Execution flow

Current flow: a caller imports `total_price`, passes `price` and `fee`, and `calc.py:2` immediately evaluates `price + fee`; the result or Python's native operation error returns to the caller. The requested behavior introduces a negative-fee contract before the existing successful outcome, while zero and positive inputs remain on the currently tested path.

## Key components & responsibilities

- `calc.py` owns the public price calculation and therefore the negative-fee contract boundary.
- `tests/test_calc.py` owns repository-local behavior verification and is explicitly named as the intended home for added coverage.
- `README.md` owns the requirement boundary: `ValueError` is fixed, message text is not fixed, stdlib-only is required, and deployment is excluded.
- `approved-plan.md` narrows analysis scope and names useful cases, but remains plan input rather than committed implementation design.

## Architecture insights

The fixture is a single-module helper with direct unit tests and no internal service, configuration, persistence, or integration layers. Pattern consistency and architectural clarity are high within this small scope; documentation is concise but sufficient for the requested behavior. No unrelated architectural cleanup is indicated.

## Dependencies

### Internal

- `tests/test_calc.py:2` imports `total_price` from `calc.py`.
- Caller-closure command: `rg -n --glob '!procedure/**' --glob '!approved-plan.md' --glob '!README.md' --glob '!negative_fee_analysis.md' '\btotal_price\b' .`
- Result: four symbol occurrences across two files — one definition (`calc.py:1`), one import (`tests/test_calc.py:2`), and two call sites (`tests/test_calc.py:6,8`). No other repository consumers were found.

### External / libraries

- Python standard library only, as required by `README.md:3`.
- `unittest` is the existing test framework (`tests/test_calc.py:1`).
- No external service, API, database, or third-party package is present in the supplied fixture.

## Change surface

### Files to Modify

| File | Purpose | Changes Needed |
| ---- | ------- | -------------- |
| `calc.py` | Public price helper | Represent the required negative-fee rejection while preserving the existing valid-fee result contract. |
| `tests/test_calc.py` | Existing behavior test home | Cover the rejection boundary and retain explicit evidence for zero and positive behavior; the approved plan also identifies a fractional-negative boundary case for scope consideration. |

No production file needs to be created. There are no HTTP/API endpoints or database objects in this fixture, so the Files to Create, APIs Affected, and Database Changes tables are omitted.

## Observations

### Strengths

- The behavior boundary and exception class are explicit in `README.md:3`.
- Existing zero and positive paths already have focused tests (`tests/test_calc.py:5-8`).
- The stated absence of external callers agrees with the complete local caller search.

### Issues

- `calc.py:1-2` currently has no negative-fee rejection; addition is unconditional.
- `tests/test_calc.py:5-8` has no negative input or exception assertion, so the new requirement is not protected by the current suite.

### Opportunities

- The current test class and validation command provide a direct, repository-consistent verification home without new modules or dependencies.

## Side effects / impact

- Negative-fee calls change from ordinary addition to a raised `ValueError`, as explicitly required.
- Zero and positive calls must continue to return the same values demonstrated in `tests/test_calc.py:5-8`.
- Impact is confined to `total_price` and its supplied tests based on the complete fixture search and the caller constraint in `README.md:3`.
- No deployment, persistence, network, configuration, or external integration impact is in scope.

## Risks & considerations

| Severity | Risk / consideration | Evidence and boundary |
| --- | --- | --- |
| Mid | A boundary check could unintentionally reject zero or alter positive-fee results. | These are preserved contracts in `README.md:3` and existing checks at `tests/test_calc.py:5-8`. |
| Mid | Coverage limited to an integer negative value could miss behavior immediately below zero. | `approved-plan.md:3` names fractional-negative coverage as part of the approved scope; the exact test design remains a later-phase choice. |
| Low | Tests could lock an error message that the requirement intentionally leaves open. | `README.md:3` fixes `ValueError` but not wording. |
| Low | Work could expand into type validation or new abstractions not requested by the owner. | The fixture specifies only negative-fee rejection, preserved valid behavior, stdlib-only use, and no new production modules. |

## Baseline validation

Executed `python -m unittest discover -s tests -v` before any production change. Result: PASS — 2 tests ran (`test_positive_fee`, `test_zero_fee`), both passed. This establishes the current valid-fee baseline; it does not verify the missing negative-fee behavior.

## Essential files

- `README.md:3` — requirement and explicit constraints.
- `calc.py:1-2` — complete production change location.
- `tests/test_calc.py:1-8` — sole consumer and intended test home.
- `approved-plan.md:1-3` — approved scope input only; not a committed design.

The next phase, if separately authorized, is design/implementation planning grounded in these locations and boundaries. This analysis does not prescribe the condition placement, exact assertion form, or error text.
