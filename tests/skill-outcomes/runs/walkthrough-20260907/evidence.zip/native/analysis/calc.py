def total_price(price, fee):
    return price + fee
