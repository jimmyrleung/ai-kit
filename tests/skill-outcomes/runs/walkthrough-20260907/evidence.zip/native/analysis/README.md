# Price helper

Public function total_price(price, fee) adds a fee. Requirement: reject a negative fee with ValueError; preserve zero and positive fee behavior. No external callers beyond the supplied test file. Python stdlib only. Validation: python -m unittest discover -s tests -v. Existing tests are the intended test home. Error message wording is not locked. No deployment work is requested.
