import unittest
from calc import total_price

class PriceTests(unittest.TestCase):
    def test_positive_fee(self):
        self.assertEqual(total_price(10, 2), 12)
    def test_zero_fee(self):
        self.assertEqual(total_price(10, 0), 10)
