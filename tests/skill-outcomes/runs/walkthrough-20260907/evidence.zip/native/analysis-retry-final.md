Created [negative_fee_analysis.md](<run>/native/analysis/negative_fee_analysis.md).

Scoped conclusion: the change is confined to `calc.py` and `tests/test_calc.py`; negative fees must raise `ValueError`, while zero and positive behavior remains unchanged. Baseline: 2 existing tests passed. No design or production changes were made.