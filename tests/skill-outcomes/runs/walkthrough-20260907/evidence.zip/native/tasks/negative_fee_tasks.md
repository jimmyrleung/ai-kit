# Negative fee rejection — implementation tasks

**Authoritative input:** [approved-plan.md](approved-plan.md) (owner-approved exploration and locked design for all technical detail)

**Companion context:** [README.md](README.md)

**Mode:** Integration, spec-carrying

**Approach:** Balanced (1 task, atomic mid-size grouping)

## Tasks overview

| Task | Title | Complexity | Est. Time | Depends On | Lifecycle | Status |
|---|---|---:|---:|---|---|---|
| 1 | Reject negative fees and lock behavior with tests | S | 0.5–1h | None | pre-merge | Not Started |

**Overall Progress**: 0/1 tasks completed (0%)  
**Last Updated**: 2026-09-07

The source edit and its regression tests form one mergeable behavior change, so there is no safe parallel implementation work.

## Detailed tasks

### Task 1: Reject negative fees and lock behavior with tests

**Description:** Add the approved validation immediately before the existing addition and extend the existing unittest class with rejection and preservation cases. Production and test edits stay together because neither should land as an independently complete change.

- **Complexity:** S
- **Estimated time:** 0.5–1h
- **Depends on:** None
- **Lifecycle boundary:** pre-merge
- **Write and shared-resource set:** `calc.py`, `tests/test_calc.py`; no database, service, generated artifact, or external mutable state
- **Can run in parallel with:** None

**Files involved:**

- `calc.py` — modify `total_price` at `calc.py:1-2`
- `tests/test_calc.py` — modify the existing `PriceTests` suite at `tests/test_calc.py:4-8`

**Implementation steps:**

1. In `total_price`, insert the locked `fee < 0` guard before the current `price + fee` expression (`calc.py:1-2`; Locked decisions 1–2). Keep the implementation local to this function and raise `ValueError`; choose a concise message without making its text part of the public contract.
2. Extend `PriceTests` in `tests/test_calc.py` rather than creating a new test module (`tests/test_calc.py:4-8`; Locked decision 3). Add explicit cases proving:
   - a representative negative fee raises `ValueError`;
   - a fractional fee just below zero, such as `-0.01`, raises `ValueError`;
   - representative positive and zero fees still return their existing sums.
3. Run `python -m unittest discover -s tests -v` from the workspace root and retain the command output for task verification (Locked decision 4). The pre-change baseline was run on 2026-09-07 and passed 2/2 existing tests; this is context only, not post-change proof.

**Testing requirements:**

- Test implementation owner: Task 1, `tests/test_calc.py`.
- Rejection scenarios: negative integer fee and fractional negative boundary each raise `ValueError`.
- Preservation scenarios: positive fee returns `12` for `total_price(10, 2)` and zero fee returns `10` for `total_price(10, 0)`.
- Executable check and environment: run `python -m unittest discover -s tests -v` from the workspace root with the supplied Python standard-library environment. No external service or deployed state is required.

**Acceptance criteria:**

- AC1: `total_price(10, -1)` raises `ValueError`, verified by the corresponding assertion in `tests/test_calc.py` and the passing unittest command.
- AC2: `total_price(10, -0.01)` raises `ValueError`, verified by the corresponding assertion in `tests/test_calc.py` and the passing unittest command.
- AC3: `total_price(10, 2) == 12` and `total_price(10, 0) == 10`, verified by explicit assertions in `tests/test_calc.py` and the passing unittest command.
- AC4: The guard executes before the addition and no production module or dependency is added, verified by inspecting the final `calc.py`, the workspace file inventory, and the final change scope.
- AC5: `python -m unittest discover -s tests -v` exits successfully after the edits; its output is the completion evidence for AC1–AC3.

**Completion-dependency closure:** AC1–AC5, all four numbered behavior scenarios, their implementation, and their executable evidence are owned by Task 1. The task has no later, parallel, deploy, or live producer; no dependency cycle exists. The post-change unittest run is required before completion. A failure of any rejection or preservation assertion is the earliest rollback trigger; restore the two edited files to their pre-task content and rerun the suite.

**Reference:** `approved-plan.md:3`; Locked decisions 1–4; existing implementation at `calc.py:1-2`; existing test convention at `tests/test_calc.py:1-8`

**Status:** Not Started

## Locked decisions

1. `total_price` rejects every `fee < 0` by raising `ValueError` before evaluating its existing addition. Grounding: the function is a direct addition at `calc.py:1-2`, and the approved behavior is stated at `approved-plan.md:3`.
2. Zero and positive fee behavior remains unchanged, and the function name/signature remains `total_price(price, fee)`. Grounding: `calc.py:1-2`, existing preservation assertions at `tests/test_calc.py:5-8`, and `approved-plan.md:3`.
3. All new coverage extends `tests/test_calc.py` and its unittest-based `PriceTests` class; no test or production module and no dependency is added. Grounding: `tests/test_calc.py:1-8`, `README.md:3`, and `approved-plan.md:3`.
4. The repository-only validation command is `python -m unittest discover -s tests -v`; deployment and external checks are out of scope. Grounding: `README.md:3` and `approved-plan.md:3`.

## Notes & decisions

- 2026-09-07 — The owner explicitly selected spec-carrying mode and locked the plan, so this document embeds the four implementation decisions instead of introducing a separate techspec.
- 2026-09-07 — Balanced sizing resolves to one task because `calc.py` and `tests/test_calc.py` implement and prove one small contract change and should land in the same PR.
- 2026-09-07 — Foundation-first/TDD sequencing is unnecessary at task granularity; within the atomic task, add the guard and its tests, then run the complete supplied suite.
- 2026-09-07 — Error message wording remains an implementation choice and tests must assert the exception type, not exact text.
- 2026-09-07 — There are no operational tasks. Repository progress is the overall progress; deployment, publishing, external checks, commits, and production changes are excluded.

## Confidence score

**Confidence score: 98% —** the one-task decomposition covers every locked behavior, file, test scenario, dependency, and repository-only lifecycle boundary with direct source evidence.

**Effective policy:** Decomposition rubric; 90% advancement threshold; source is `procedure/references/shared/confidence.md`; required evidence is the approved plan plus inspected production code, tests, repository context, and baseline check. Authorization is limited to this task document and local inspection/test execution; production edits, commits, deployment, external stores, and network actions remain unauthorized.

| Factor | Weight | Rating | Contribution | Evidence / gap |
|---|---:|---:|---:|---|
| Fidelity to locked decisions and requirement coverage | 35% | 100 | 35.00 | All requirements in `approved-plan.md:3` map to Task 1 steps and AC1–AC5. |
| Dependency, lifecycle, and resource closure | 25% | 100 | 25.00 | One pre-merge task owns both files and all evidence; no external or later producer exists (`README.md:3`). |
| Test/AC ownership and executable checks | 25% | 98 | 24.50 | Each scenario has an assertion owner and the exact unittest command; post-change results necessarily remain future implementation evidence. |
| Task boundaries, sizing, and path grounding | 15% | 97 | 14.55 | Both paths and symbols were inspected; the time estimate is planning judgment rather than measured implementation time. |
| **Total** | **100%** |  | **98.05 → 98%** |  |

**Why 98%:** The approved plan, README, complete two-line implementation, complete existing test file, workspace inventory, and passing 2-test baseline were inspected directly. The atomic boundary prevents hidden cross-task dependencies and gives every expected outcome one owner and one executable check.

**2% uncertainty:** The post-change tests have not been implemented or run because production edits are outside this authorized task. This does not block starting Task 1, but it blocks marking AC1–AC5 and Task 1 complete; the next check is the specified unittest command after implementation. The estimate may vary with the local implementer, which does not affect readiness or scope.

**Advancement:** Proceed within Task 1 implementation readiness only. This artifact does not authorize implementation, commit, deployment, external checks, or production changes.
