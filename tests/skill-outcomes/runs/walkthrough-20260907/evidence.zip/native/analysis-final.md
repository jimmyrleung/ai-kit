Unable to complete the artifact safely: the fixture runtime denied all local process launches with `EACCES`, so I could not read `procedure/SKILL.md`, its references, or `README.md`. No `negative_fee_analysis.md` was created because its scoped conclusion would be ungrounded.

Output path: not created — `<run>/native/analysis/negative_fee_analysis.md`