Created [negative_fee_tasks.md](<run>/native/tasks-corrected/negative_fee_tasks.md).

Scoped conclusion: one atomic pre-merge task covers the `calc.py` guard and existing unittest updates. Baseline validation passed both current tests. No production code, dependencies, deployment assets, or external systems were changed.