Created [negative_fee_techspec.md](<run>/native/design/negative_fee_techspec.md).

Scoped conclusion: the locked change requires modifying one production file and one existing test file. Baseline tests pass; no implementation, dependency, deployment, or production changes were made.