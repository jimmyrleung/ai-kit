# Negative fee rejection — implementation tasks

**Authoritative input:** [approved-plan.md](approved-plan.md) (owner-approved exploration artifact; authoritative for the locked design and scope)

**Companion context:** [README.md](README.md)

**Mode:** Integration, spec-carrying

**Approach:** Balanced (1 task, one atomic mid-size grouping)

## Tasks overview

| Task | Title | Complexity | Est. Time | Depends On | Lifecycle | Status |
|---|---|---:|---:|---|---|---|
| 1 | Reject negative fees and preserve accepted fee behavior | S | 0.5–1h | None | pre-merge | Not Started |

**Overall Progress**: 0/1 tasks completed (0%)

**Last Updated**: 2026-09-07

## Detailed tasks

### Task 1: Reject negative fees and preserve accepted fee behavior

**Description:** Add the approved guard to `total_price` and extend its existing unit-test home with rejection and regression cases. Production and test edits form one task because the changed contract must remain executable and reviewable in one atomic change.

- **Complexity:** S
- **Estimated time:** 0.5–1h
- **Depends on:** None
- **Lifecycle boundary:** pre-merge
- **Write and shared-resource set:** `calc.py`, `tests/test_calc.py`; no external mutable resources
- **Can run in parallel with:** None

**Files involved:**

- `calc.py` — modify the existing `total_price` implementation.
- `tests/test_calc.py` — modify the existing `PriceTests` suite; this is the repository's intended test home (`README.md:3`, `tests/test_calc.py:1-8`).

**Implementation steps:**

1. In `calc.py:1-2`, put the negative-fee check before the existing addition, per Locked decision 1. The intended code shape is:

   ```python
   def total_price(price, fee):
       if fee < 0:
           raise ValueError
       return price + fee
   ```

   An explanatory error message may be added, but no caller or test may depend on its wording (Locked decision 4).
2. In the existing `PriceTests` class at `tests/test_calc.py:4-8`, add `test_negative_fee` using `assertRaises(ValueError)` for a negative integer fee and `test_fractional_negative_fee` for a value immediately below zero such as `-0.01`.
3. Keep the existing `test_positive_fee` and `test_zero_fee` cases as preservation coverage; do not weaken or replace their result assertions.
4. Run `python -m unittest discover -s tests -v`. The repository prerequisite is Python with the standard library only (`README.md:3`); no service, deployment, fixture, or environment setup is required.

**Testing requirements:**

- `tests/test_calc.py::PriceTests.test_negative_fee`: `total_price(10, -2)` raises `ValueError`. Implementation owner: Task 1; verification command: `python -m unittest discover -s tests -v`.
- `tests/test_calc.py::PriceTests.test_fractional_negative_fee`: `total_price(10, -0.01)` raises `ValueError`, covering the fractional boundary below zero. Implementation owner: Task 1; verification command: the full unittest discovery command.
- `tests/test_calc.py::PriceTests.test_positive_fee`: the existing positive-fee result remains `12`. Implementation owner: Task 1 for preservation of the changed runtime contract; verification command: the full unittest discovery command.
- `tests/test_calc.py::PriceTests.test_zero_fee`: the existing zero-fee result remains `10`. Implementation owner: Task 1 for preservation of the changed runtime contract; verification command: the full unittest discovery command.
- Baseline evidence: `python -m unittest discover -s tests -v` passed the two existing tests on 2026-09-07 before implementation.

**Acceptance criteria:**

- [ ] A negative integer fee raises `ValueError` before addition. Primary owner: Task 1. Check: the named negative-fee unittest passes and direct inspection of `calc.py` shows the guard precedes `return price + fee`.
- [ ] A fractional fee below zero raises `ValueError`. Primary owner: Task 1. Check: the named fractional-negative unittest passes under the full discovery command.
- [ ] Zero and positive fees return their current totals unchanged. Primary owner: Task 1. Check: the existing zero- and positive-fee tests pass under the full discovery command.
- [ ] No production module or dependency is added, and the public surface changes only by rejecting negative `fee` values. Primary owner: Task 1. Check: inspect the final workspace file inventory and `calc.py`, then confirm the full test command passes.
- [ ] `python -m unittest discover -s tests -v` exits successfully with all four behavior scenarios passing. Primary owner: Task 1. Required environment: local Python standard library. Evidence producer: Task 1's command output.

**Reference:** Locked decisions 1–4; `approved-plan.md:3`; production precedent `calc.py:1-2`; test precedent `tests/test_calc.py:1-8`.

**Status:** Not Started

**Completion-dependency closure:** Passed. Every acceptance criterion and test scenario is owned and evidenced by Task 1; the task has no later, parallel, deploy, or live dependency. The test implementation and verification scopes are both explicit, and no rollback artifact must precede the edit.

## Locked decisions

1. `total_price` rejects every `fee < 0` with `ValueError`, and the guard executes before the existing addition. Grounding: `approved-plan.md:3`; current function shape: `calc.py:1-2`.
2. Zero and positive fees retain the current addition behavior. Grounding: `approved-plan.md:3`, `README.md:3`; current executable examples: `tests/test_calc.py:5-8`.
3. Coverage stays in `tests/test_calc.py` and includes negative-integer rejection, fractional-negative rejection, and positive/zero preservation. No production module or dependency is added. Grounding: `approved-plan.md:3`, `README.md:3`; existing suite: `tests/test_calc.py:1-8`.
4. Error wording is not part of the contract. Validation is repository-local with `python -m unittest discover -s tests -v`; deployment and external checks are excluded. Grounding: `approved-plan.md:3`, `README.md:3`.

## Notes & decisions

- 2026-09-07: The owner explicitly selected spec-carrying mode and locked the design in `approved-plan.md`.
- 2026-09-07: Balanced sizing resolves to one task because the two touched files implement and verify one small runtime-contract change and should land in one PR.
- 2026-09-07: Foundation-first ordering is implicit: add the guard and its tests in the same atomic task, then run the repository validation command.
- 2026-09-07: No operational tasks are present; all work is pre-merge and repository-only. A small source revert is sufficient if the behavior must be rolled back.

## Confidence score

**Confidence score: 100% —** the one-task decomposition fully covers the locked design, verified source/test paths, dependencies, lifecycle, and executable checks within this documentation-only scope.

**Effective policy:** Decomposition rubric; 90% advancement threshold; source is `procedure/references/shared/confidence.md`; required evidence is the approved plan, repository source/tests/context, dependency/resource closure, and test/acceptance-criterion ownership. Authorized action is limited to local inspection, existing-test execution, and writing this task document; production edits, deployment, external checks, installs, and commits remain unauthorized.

| Factor | Weight | Rating | Contribution | Evidence / gap |
|---|---:|---:|---:|---|
| Fidelity to locked decisions and requirement coverage | 35% | 100 | 35 | All requirements in `approved-plan.md:3` map to Task 1, its tests, or explicit exclusions. |
| Dependency, lifecycle, and resource closure | 25% | 100 | 25 | One pre-merge task owns both write paths; no external resources or operational lifecycle work exists (`README.md:3`). |
| Test/AC ownership and executable checks | 25% | 100 | 25 | All four scenarios and five ACs name Task 1, their checks, environment, and evidence producer; the baseline command passed. |
| Task boundaries, sizing, and path grounding | 15% | 100 | 15 | `calc.py:1-2` and `tests/test_calc.py:1-8` were inspected end-to-end; the atomic S task matches the two-file change. |
| **Total** | **100%** |  | **100** | Checked calculation: `35 + 25 + 25 + 15 = 100`. |

**Why 100%:** The approved design is explicit and small, every named path and current behavior was verified, the baseline tests pass, and the closure trace found no hidden producer, lifecycle, resource, or evidence dependency.

**0% uncertainty:** No known remaining gap affects this decomposition. This score does not claim that the future implementation or post-change tests have passed; those outcomes must be produced by Task 1.

**Advancement:** Proceed within the authorized boundary to artifact review or later owner-authorized implementation. This document does not authorize production edits, deployment, external checks, installs, commits, or production changes.
