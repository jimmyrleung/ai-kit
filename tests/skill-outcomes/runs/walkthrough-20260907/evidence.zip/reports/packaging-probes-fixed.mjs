import fs from 'node:fs';
import path from 'node:path';
import {bundleSkillReferences} from '<ai-kit>/scripts/bundle-skill-references.mjs';
import {checkRepository} from '<ai-kit>/scripts/check-skill-portability.mjs';
const work='<run>';
const fixture=(name)=>{let root=fs.mkdtempSync(path.join(work,name+'-')); for(const p of ['skills','docs','README.md','INVENTORY.md'])fs.cpSync('<ai-kit>/'+p,path.join(root,p),{recursive:true}); return root};
const reports=[];
{
 const root=fixture('reference-link');
 const source=path.join(root,'docs/contracts/authorized-work.md');
 fs.appendFileSync(source,'\nRequired packaging probe: follow [extra rules][extra].\n\n[extra]: reference-probe.md\n');
 fs.writeFileSync(path.join(root,'docs/contracts/reference-probe.md'),'# Extra rules\nRequired instruction.\n');
 const write=bundleSkillReferences(root,{write:true});
 const check=checkRepository(root,'final');
 const dest=path.join(root,'skills/analyze-work/references/shared');
 reports.push({name:'reference-style transitive dependency',root,findings:write.findings,checkerErrors:check.errors,referencePresent:fs.readFileSync(path.join(dest,'authorized-work.md'),'utf8').includes('[extra]: reference-probe.md'),targetExists:fs.existsSync(path.join(dest,'reference-probe.md'))});
}
{
 const root=fixture('direct-reference-link');
 const source=path.join(root,'skills/onboard-me/SKILL.md');
 let txt=fs.readFileSync(source,'utf8').replaceAll('(references/shared/feedback.md)','[feedback-rules]');
 fs.writeFileSync(source,txt+'\n[feedback-rules]: references/shared/feedback.md\n');
 const write=bundleSkillReferences(root,{write:true});
 reports.push({name:'direct reference-style request',root,findings:write.findings,retired:write.retired,checkerErrors:checkRepository(root,'final').errors,feedbackExists:fs.existsSync(path.join(root,'skills/onboard-me/references/shared/feedback.md'))});
}
{
 const root=fixture('symlink-output'); const dir=path.join(root,'skills/analyze-work/references/shared');
 const held=path.join(root,'held-shared');fs.renameSync(dir,held);fs.symlinkSync(held,dir,'dir');
 reports.push({name:'linked output folder',root,result:bundleSkillReferences(root,{write:true})});
}
{
 const root=fixture('external-skill');const source=path.join(root,'skills/onboard-me'); const target=fs.mkdtempSync(path.join(work,'external-skill-target-'));fs.renameSync(source,path.join(target,'onboard-me'));fs.symlinkSync(path.join(target,'onboard-me'),source,'dir');
 reports.push({name:'external skill root',root,result:bundleSkillReferences(root,{write:true})});
}
{
 const root=fixture('unknown-inline'); fs.appendFileSync(path.join(root,'docs/contracts/authorized-work.md'),'\n[missing](no-such-source.md)\n');reports.push({name:'unknown inline source',root,result:bundleSkillReferences(root,{write:true})});
}
fs.writeFileSync(path.join(work,'packaging-probes-fixed.json'),JSON.stringify(reports,null,2)+'\n');
console.log(JSON.stringify(reports.map(x=>({...x,result:x.result?{findings:x.result.findings,written:x.result.written,retired:x.result.retired}:undefined})),null,2));
