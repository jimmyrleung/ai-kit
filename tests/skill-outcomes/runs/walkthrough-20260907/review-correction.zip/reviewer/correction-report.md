# F1 targeted independent correction review — 2026-09-07

**Disposition: F1 fixed; no supported actionable defect remains in the inspected correction.** This is a targeted review of the generator/parser correction and its regression tests, not another broad WB review or owner GO. Original `<review-run>/Report.md` and its probes remain unchanged.

## Exact reviewed source

| File | SHA-256 |
|---|---|
| `scripts/bundle-skill-references.mjs` | `2a2e629da86f006f20188e017edbec7c1deb85291745cb825abd901832e6a61c` |
| `tests/test_skill_portability.mjs` | `af5083b353c91800ddf61f7667760161a21b835ebfe63776b4884b73d0b6eec4` |

Both files were read end-to-end. The parent's subsequent test-only newline correction was separately diffed and inspected; no generator change occurred during review. Initial and final snapshots/hashes are retained. Scope excludes documentation/evidence edits owned by the parent, all earlier WB/Astra work, private stores, provider trials and deployment.

## Finding closure and executed evidence

**Original F1: Medium severity; 99% certainty in the single-title defect. Fixed — SOURCE and OBSERVED evidence.** `scripts/bundle-skill-references.mjs:10` now explicitly collects destination prefixes without depending on optional title syntax and accepts next-line destinations. `tests/test_skill_portability.mjs:410` adds six direct/transitive forms, asserts required files independently, checks rewritten destinations, catches missing generated targets, and verifies unknown-source preflight rejection.

New disposable fixtures in `final-reproductions.json`, executed by `reproduce-final.mjs`, establish:

- Original single-quoted-title form retains `feedback.md` and `change-evidence.md`, with no retirement and a clean final checker.
- The newline-terminated intended-path reference definition does the same.
- Both forms correctly include and rewrite a transitive `../output-filename-contract.md#contract` dependency.
- A deliberately unused owned copy retires; still-required copies remain. Unchanged generation writes nothing.
- Unknown direct and transitive destinations reject before writes or retirements, and a full generated-byte snapshot remains unchanged. The final direct-unknown probe first restores the valid transitive source, so the two error paths are independently exercised.

Fresh `npm test`, `npm run check:portability`, and `npm run check:skill-references` all exit zero; exact commands and outputs are in `checks.json` and `check-*.log`. The final checks report 31 skills and 79 references, with zero errors/findings and no generator writes. No native model trials were run.

## Correction to the original multiline reproduction

The exact original in-prose replacement inherited the sentence's following period, making its destination `references/shared/feedback.md.`. It was therefore **not** proof about preserving the intended `feedback.md` destination. The new parser correctly rejects that actual unknown target instead of silently omitting it. `original-exact-multiline-outcome.json` and the failed fixture preserve this result. The independent single-title finding remains valid, and a separately newline-terminated definition verifies the intended multiline case. This is a correction to evidence attribution, not a new source defect.

The intermediate direct-unknown probe also retained an invalid transitive source, so that particular result was confounded. Its script and JSON remain; `reproduce-final.mjs` isolates the direct path and asserts its actual diagnostic. Only the final isolated results support the direct-unknown claim.

## Confidence and limits

**Confidence score: 96%** in this targeted correction. Owner's effective rubric and threshold 90 apply; authority is read-only review and disposable probes. Executed Decimal arithmetic in `confidence.json` verifies:

| Factor | Weight | Rating | Contribution | Evidence / gap |
|---|---:|---:|---:|---|
| Documentation clarity | 30 | 98 | 29.40 | Original failure and bounded correction are explicit |
| Inspected suitable patterns | 25 | 97 | 24.25 | Existing generator and fixture/test structure retained |
| Dependencies/data flow | 20 | 97 | 19.40 | Direct/transitive retention, rewriting and rejection executed |
| Complexity understood | 15 | 96 | 14.40 | Destination recognition is independent of optional titles |
| Cross-system impact | 10 | 90 | 9.00 | Local Linux checks; prior platform/provider limits unchanged |
| Total | 100 | | **96.45 → 96** | Threshold 90 |

**4% uncertainty:** extraction is deliberately conservative and is not a full Markdown validator; this review does not certify every Markdown construct or native provider/platform behavior. The existing deferred environments remain deferred. The parent plans to preserve routing dispatch information as an explicitly labeled conversation reconstruction; that evidence was not re-reviewed in this two-file correction task and must not be represented as original raw runtime receipts.

**Advancement:** proceed to parent consolidation and owner review within existing authorization. No critical evidence is missing for closing the reproduced single-title defect or the corrected intended-path multiline case. This targeted disposition does not supply aggregate release approval, owner GO, commit or deployment permission.
