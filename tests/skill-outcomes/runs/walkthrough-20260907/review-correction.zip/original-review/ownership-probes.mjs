import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import {bundleSkillReferences} from '~/ai-kit/scripts/bundle-skill-references.mjs';
const repo='~/ai-kit',out='<review-run>';const hash=x=>crypto.createHash('sha256').update(fs.readFileSync(x)).digest('hex');const results=[];
for(const id of ['output-link','external-skill','outside-source']){
 const root=path.join(out,`ownership-${id}`);fs.mkdirSync(root);for(const n of ['skills','docs'])fs.cpSync(path.join(repo,n),path.join(root,n),{recursive:true});let saved,target;
 if(id==='output-link'){target=path.join(root,'skills/analyze-work/references/shared');saved=path.join(root,'saved-shared');fs.renameSync(target,saved);fs.symlinkSync(saved,target,'dir')}
 if(id==='external-skill'){target=path.join(root,'skills/analyze-work');saved=path.join(out,'external-analyze-work');fs.renameSync(target,saved);fs.symlinkSync(saved,target,'dir')}
 if(id==='outside-source'){target=path.join(root,'docs/contracts/authorized-work.md');saved=path.join(out,'outside-authorized-work.md');fs.renameSync(target,saved);fs.symlinkSync(saved,target,'file')}
 const sentinel=id==='output-link'?path.join(saved,'confidence.md'):id==='external-skill'?path.join(saved,'SKILL.md'):saved;const before=hash(sentinel),result=bundleSkillReferences(root,{write:true});results.push({id,root,result,externalOrLinkedBytesUnchanged:before===hash(sentinel)});
}
fs.writeFileSync(path.join(out,'ownership-probes.json'),JSON.stringify(results,null,2));console.log(results.map(r=>({id:r.id,findings:r.result.findings,writes:r.result.written.length,retirements:r.result.retired.length,unchanged:r.externalOrLinkedBytesUnchanged})));
