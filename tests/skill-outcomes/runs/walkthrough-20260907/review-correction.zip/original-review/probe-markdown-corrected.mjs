import fs from 'node:fs'; import path from 'node:path';
import {bundleSkillReferences} from '~/ai-kit/scripts/bundle-skill-references.mjs';
import {checkRepository} from '~/ai-kit/scripts/check-skill-portability.mjs';
const repo='~/ai-kit', out='<review-run>';const results=[];
for (const [id,render] of [['single-title-corrected', '[feedback](references/shared/feedback.md \'Feedback rules\')'],['multiline-definition-corrected','[feedback][rules]\n\n[rules]:\n  references/shared/feedback.md'],['encoded-path-corrected','[feedback](references/shared/%66eedback.md)']]) {
 const root=path.join(out,id);fs.mkdirSync(root);
 for(const name of ['skills','docs','README.md','INVENTORY.md'])fs.cpSync(path.join(repo,name),path.join(root,name),{recursive:true});
 const file=path.join(root,'skills/onboard-me/SKILL.md');let text=fs.readFileSync(file,'utf8');text=text.replace('[the feedback contract](references/shared/feedback.md)',render);fs.writeFileSync(file,text);
 const before=bundleSkillReferences(root);const write=bundleSkillReferences(root,{write:true});const final=checkRepository(root,'final');
 results.push({id,root,before,write,finalErrors:final.errors,requiredExists:fs.existsSync(path.join(root,'skills/onboard-me/references/shared/feedback.md'))});
}
fs.writeFileSync(path.join(out,'probe-markdown-corrected.json'),JSON.stringify(results,null,2));console.log(results.map(x=>({id:x.id,retired:x.write.retired,errors:x.finalErrors,requiredExists:x.requiredExists})));
