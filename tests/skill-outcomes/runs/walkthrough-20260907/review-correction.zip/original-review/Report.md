# WB01–WB03 fresh independent review — 2026-09-07

**Verdict: Needs revision.** One introduced, reproduced Medium packaging defect remains. The current generated corpus is complete for its current link syntax, and the executed repository suites pass. No supported WB02 or WB03 source defect was found. This review does not supply owner GO.

Record: `WB01-WB03-fresh-review-20260907`. Reviewer: fresh delegated agent `/root/walkthrough_fresh_review`; no workers spawned, source edits, staging, commits, publication, live-home synchronization or private-store access. Evidence and probes are under this directory only.

## F1 — Valid Markdown can silently discard required supporting documents

**Medium severity; 99% certainty; introduced by WB01.** Primary location: `scripts/bundle-skill-references.mjs:11`; graph collection at `:80`, retirement at `:126`/`:143`; incomplete detached test at `tests/test_skill_portability.mjs:318`.

Expected: valid links to required shared references contribute to the dependency graph, or unsupported syntax fails validation before generation retires anything. Actual: the parser accepts only double-quoted inline titles and same-line reference destinations. Changing onboard-me's sole feedback link to either form below makes generation retire both `feedback.md` and its transitive `change-evidence.md`, after which the final portability checker reports **zero errors**:

```markdown
[feedback](references/shared/feedback.md 'Feedback rules')
```

```markdown
[feedback][rules]

[rules]:
  references/shared/feedback.md
```

These are valid [CommonMark link-title](https://spec.commonmark.org/0.31.2/#link-title) and [reference-definition](https://spec.commonmark.org/0.31.2/#link-reference-definitions) forms. The defect can ship a detached skill whose required procedure references no longer exist after an ordinary Markdown edit. Existing source files currently use supported forms; this is a reproduced generator/validator failure, not a claim that today's copies are already missing.

- **SOURCE:** the shared `LINK` regex determines both what generation considers required and what final checking expects. Retirement treats everything outside that incomplete graph as unused.
- **OBSERVED:** `node probe-markdown-corrected.mjs` executed against copied full skills/docs fixtures. Both variants retired the two required files; `checkRepository(root, 'final').errors` was empty and `requiredExists` was false. Exact fixtures and `probe-markdown-corrected.json` remain available. The first no-op probe targeted the wrong display text; it is preserved separately and does not support the finding.
- **INFERRED consequence:** a maintainer using either form could distribute incomplete supporting instructions because the shipping check gives a clean result.
- **Fix/next check:** make dependency extraction handle these valid forms or explicitly reject unsupported required-link syntax before writes/retirements. Add direct and transitive regression fixtures with independently asserted expected files. Check dependencies from SKILL/local source documents as well as generated outputs; the current detached test enumerates only files that already survived generation and repeats a limited regex. Re-run the original reproductions, shipping checks, and generated identity check. No unrelated packaging framework or analyzer rewrite is requested.

## Scope, identity and coverage

The comparison base is the captured pre-WB snapshot, **not Git HEAD**. HEAD `aeec06bfa0a6b97402b17824d957f29635f40ba7` is informational. The capture contains selected paths; an absent capture entry was not classified as an addition merely because it exists today. `manifest.json` records exact current/baseline hashes, modes, dependencies and each exclusion. It contains 122 incremental subject files, including the generated copies and two WB documents; 154 dependency records include the 151 archived final-source files and the evidence package/index. No staged transition, rename or source drift during this review was found. Earlier Astra edits and owner `SESSION_LOG.md` are excluded.

Inspected generator and checker end-to-end, all changed test code and its existing fixture structure, all 31 description pairs and retained metadata, all nine main confidence consumer bodies, maintained contracts and installation/update guidance. Reviewed remaining changed hunks and generated source/target identities. Earlier reviews were read **after initial independent findings**, then treated as claims and evidence to audit. Exactly one deliberate final pass covered initially skipped/truncated hunks, remaining AC/evaluation records, teach's overlay, full test context, ownership probes and source identities. There was no autonomous review loop.

The generator is a focused Node module integrated into the existing checker and test home; its allowlisted shared-source catalog, graph cycle guard and preflight plan fit this repository. Generated duplication serves detached distribution. The concrete complexity concern is the undocumented partial Markdown grammar governing destructive retirement; fewer lines do not compensate for silent dependency loss. No broader refactor is warranted by this review.

## Acceptance audit

| AC | Fresh review result |
|---|---|
| WB01.1 detached files plus representative task | Current graph and existing copied analysis/design/tasks executions support the current corpus; F1 limits packaging robustness. Model traces use local procedure copies. Physical checkout absence was not established. |
| WB01.2 propagation/idempotence | Executed Node fixtures pass source fan-out and unchanged-byte/mtime assertions. |
| WB01.3 stale/missing detection | **Needs revision: F1.** Supported-syntax fixtures pass; valid alternate forms produce a false clean result. |
| WB01.4 install/update support | Fresh sync suite passes; root/adapter/authoring instructions agree on complete-folder replacement, generation and linked updates. Earlier isolated-home records preserve their failed setup attempt and corrected preview/apply/check. |
| WB02.1 purpose/triggers/neighbors | All pairs inspected; analysis/recon/design, docs inventory/single/update, review/QA/verification, learning/tour/disposition, discovery and incident boundaries remain explicit. No supported regression found. |
| WB02.2 all descriptions/metadata | 31 inspected, 30 scalar edits, teach retained; parsed other metadata unchanged. Teach explicit-only overlay matches baseline. |
| WB02.3 measurements | Independently reproduced 16,694→10,733 description characters; 18,232→12,287 frontmatter; body 401,717→406,972. Character counts do not establish token, cost or invocation-load savings. |
| WB02.4 fresh routing trials | Regraded retained arrays: baseline 99/100, candidate 100/100, one baseline miss R093. Catalogs/cases/key/answers exist. Fresh/blind worker context is claimed but dispatch receipts are absent from the archive; see provenance limit below. |
| WB02.5 final checks/scope | Fresh shipping checks pass; checker integration is narrow and no broad analyzer rewrite occurred. |
| WB03.1 explicit assessment | Nine consumers link the complete contract; three actual document outputs contain score, factors, evidence, uncertainty, next checks and authority boundary. |
| WB03.2 rubrics/overrides | Source reconciles stage rubrics and stricter policy. Retained stricter slice calculates 94 against 98 and blocks. |
| WB03.3 thresholds/handoffs/evidence | Source preserves effective thresholds and QA depth. Slice blocks unrun required migration integration despite previous 97. Policy-only P1 selects streamlined QA. Fixed full mode in per-task verify is not a separate defect: its selected gates exclude docs. |
| WB03.4 severity/causality/authorization | Source keeps these separate; synthetic P1 slice retains candidate diagnosis and a discriminating probe, without remediation authority. It does not establish real incident causality. |
| WB03.5 portable/default/boundary outcomes | Public copied procedures and no private confidence addendum in exact prompts; native trace reads support representative task behavior. Reporting slices and provider limits are clearly qualified. |

## Checks and evidence quality

Fresh executed checks (`checks.json`, `check-*.log`): `npm test`, `npm run check:portability`, `npm run check:skill-references`, and Python unittest discovery for `test_sync_skills.py` all exit zero. Python reports 41 tests, one Windows-only skip. Environment: Linux, Node 24.20.0, Python 3.14.7. No compiled application build applies. Dependency installation and Python compilation were not rerun; their original records are preserved rather than relabeled fresh. No expensive native provider test was replayed.

`ownership-probes.json` independently confirms output-directory links, externally owned skill roots with generated content, and outside-docs source links fail preflight with zero writes/retirements and unchanged sentinel bytes. `identity-graph-audit.json` verifies all 377 archive entries, all 151 final-source byte matches, 79 generated header source identities and 33 generated local targets without mismatch. This establishes integrity/currentness, not correctness by itself.

The native traces show actual copied-skill reads, fixture tests and document writes; failed Git probes in non-Git fixtures remain visible. The original tasks arithmetic failure is retained. Independent recalculation confirms analysis 99, design 98 and corrected tasks 100; the corrected trace actually executes `awk`. Analysis/design and boundary runs predate the arithmetic instruction refinement, as the execution record discloses. The all-100 corrected fixture is weak evidence for heterogeneous fractional arithmetic reliability, but it does demonstrate executing the required calculation. No broad reliability claim follows.

Routing prompts closely mirror skill descriptions and the task fixture is a two-line helper with a locked plan. The boundary cases explicitly supply missing evidence and desired policy concerns. They meaningfully test instructed behavior, but provide little evidence about ambiguous real requests, unprompted detection, full pipeline handoffs or calibrated scores. The archived answer arrays can be regraded; fresh/blind context and exact worker dispatch cannot independently be established from them. Preserve original dispatch receipts/briefs if those claims are required for final WB02.4 acceptance. This is an evidence limitation, not an allegation of contamination or fabricated execution.

Hosted Windows/macOS/Python 3.12 checks and Claude/Cursor native proof remain the previously accepted deferrals. They are not newly introduced defects and are not PASS. Successful retries lack a physical source-absence boundary, which the execution record also states. The manifest/source checks do not prove authentication configuration or resolved model identity; the record appropriately distinguishes requested model from independently unknown resolved identity.

## Confidence and advancement

**Confidence score: 94%** in this scoped review and its findings. Effective policy: owner's rubric 30/25/20/15/10, threshold 90; evidence and authorization gates apply independently. Scope is review/disposable probes only.

| Factor | Weight | Rating | Contribution | Evidence / gap |
|---|---:|---:|---:|---|
| Documentation clarity | 30 | 97 | 29.10 | WB outcomes and boundaries explicit; routing provenance limitation |
| Inspected suitable patterns | 25 | 95 | 23.75 | Existing checker/test structure and semantic neighbors inspected |
| Dependencies/data flow | 20 | 94 | 18.80 | Graph/handoffs/identities checked; native coverage representative |
| Complexity understood | 15 | 92 | 13.80 | Parser defect reproduced; syntax coverage remains nonexhaustive |
| Cross-system impact | 10 | 90 | 9.00 | Linux executed; accepted platform/provider deferrals remain |
| Total | 100 | | **94.45→94** | Decimal arithmetic executed in `arithmetic-audit.py` |

**6% uncertainty:** nonexhaustive syntax/agent behavior, missing routing dispatch provenance, and deferred native environments limit broader conclusions. F1 blocks a clean WB01/aggregate implementation review regardless of the score. Next action is a focused parser correction and regression verification; independently authorized WB02/WB03 review can continue. Owner GO, commit, deployment and all other external actions remain outside this review.
