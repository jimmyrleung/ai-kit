# Preserved failed/confounded review probes

- Initial `probe-markdown.mjs` searched for `[feedback contract]` instead of the actual `[the feedback contract]`; all variants were no-ops. Its script, fixtures and JSON remain. Corrected reproduction checks actual changed bytes and produces the finding.
- First description measurement used `import yaml from 'js-yaml'`; Node 24.20.0 exited 1: module does not provide a default export. Corrected namespace import produced descriptions.json and the reported measurements. No repository mutation occurred.
- First arithmetic audit attempted Path + string and exited 1 with TypeError before artifact output. The next script incorrectly expected six cells rather than five in the native factor table; it exited 1 with AttributeError on an empty integer sum. `arithmetic-audit-failed.py` preserves that version. Corrected script parses five cells and writes checked calculations in arithmetic-audit.json. Neither failed attempt is passing arithmetic evidence.
- Local independent Markdown renderer availability probe found no mistune, markdown_it, markdown, cmark or pandoc. No installation occurred. Syntax legitimacy was checked against the primary CommonMark 0.31.2 specification instead.

- First final-integrity assertion counted any `| WB` text and also matched the confidence table evidence cell, yielding 15 instead of 14. Anchored AC-row matching corrected that report-check probe; source/archive/staging checks were already clean.
