# Initial independent source findings

Written before inspecting prior review/evaluation records.

- F1 (Medium; OBSERVED): `scripts/bundle-skill-references.mjs:11` misses valid single-quoted inline link titles and next-line reference-definition destinations. In disposable complete skill/docs fixtures, changing onboard-me's sole feedback link into either form makes generation retire both feedback.md and its transitive change-evidence.md; checkRepository(final) then reports zero errors. Expected either correct graph or fail closed before retirement. Introduced by WB01. Raw `probe-markdown-corrected.json`; initial no-op probe retained separately and not counted as evidence.
- Potential F2 (source lead, no runtime claim): verify-task still passes mode full, whereas the new QA policy-only fix retains inherited streamlined depth only when an explicit caller does not require full. Check actual effect: selected per-task gates 1–3 make this mode difference operationally irrelevant there; likely no finding unless a meaningful downstream consequence is demonstrated.
- No supported WB02 description regression yet; paired descriptions and metadata measurements remain to inspect. Nine WB03 consumers read; scoring evidence/permission safeguards are coherent in scope. Full scores alone are intentionally unable to pass missing required evidence.

Remaining initial scope: complete description pair inspection, non-main9 changed hunks and retained procedure context, current suites, generated graph ownership edge probes, and archived evaluation provenance. Exactly one final deliberate skipped-scope pass will follow initial completion.
